// Local demo service for when Supabase is not available
export interface User {
  id: string;
  email: string;
  fullName: string;
  interfaceType: 'student' | 'faculty' | 'hod' | 'principal';
  employeeId?: string;
  className?: string;
  department?: string;
}

export interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  departmentCode: string;
  className: string;
  year: number;
  semester: number;
  guardianName: string;
  guardianPhone: string;
  isActive: boolean;
  currentStatus: 'in_class' | 'left_class' | 'on_timeout' | 'absent';
  lastActivity: string;
  timeoutStart: string | null;
  timeoutDuration: number;
  alertsSent: boolean;
  createdAt: string;
  updatedAt: string;
}

class LocalDemoService {
  private users: Map<string, User> = new Map();
  private students: Map<string, Student> = new Map();
  private timeoutStudents: Map<string, Student> = new Map();
  private alerts: any[] = [];
  private initialized = false;

  constructor() {
    this.initializeDemoData();
  }

  private initializeDemoData() {
    if (this.initialized) return;
    
    // Initialize demo users with Indian names
    const demoUsers: User[] = [
      {
        id: 'demo-student-1',
        email: 'rahul.sharma@student.edu',
        fullName: 'Rahul Sharma',
        interfaceType: 'student',
        className: 'CSE-4A',
        department: 'Computer Science'
      },
      {
        id: 'demo-faculty-1',
        email: 'priya.singh@college.edu',
        fullName: 'Dr. Priya Singh',
        interfaceType: 'faculty',
        employeeId: 'FAC001',
        department: 'Computer Science'
      },
      {
        id: 'demo-hod-1',
        email: 'rajesh.kumar@college.edu',
        fullName: 'Dr. Rajesh Kumar',
        interfaceType: 'hod',
        employeeId: 'HOD001',
        department: 'Computer Science'
      },
      {
        id: 'demo-principal-1',
        email: 'sunita.agarwal@college.edu',
        fullName: 'Dr. Sunita Agarwal',
        interfaceType: 'principal',
        employeeId: 'PRIN001',
        department: 'Administration'
      }
    ];

    demoUsers.forEach(user => {
      this.users.set(user.email, user);
    });

    // Generate demo students
    this.generateDemoStudents();
    this.initialized = true;
  }

  private generateDemoStudents() {
    const departments = [
      { name: 'Computer Science', code: 'CSE', years: 4, classesPerYear: 3 },
      { name: 'Computer Science & Machine Learning', code: 'CSM', years: 4, classesPerYear: 3 },
      { name: 'Computer Science & Data Science', code: 'CSD', years: 4, classesPerYear: 3 },
      { name: 'Information Technology', code: 'IT', years: 4, classesPerYear: 3 },
      { name: 'Internet of Things', code: 'IoT', years: 4, classesPerYear: 3 },
      { name: 'Electronics & Communication Engineering', code: 'ECE', years: 4, classesPerYear: 3 },
      { name: 'Electrical & Electronics Engineering', code: 'EEE', years: 4, classesPerYear: 3 },
      { name: 'Mechanical Engineering', code: 'ME', years: 4, classesPerYear: 3 },
      { name: 'Civil Engineering', code: 'CE', years: 4, classesPerYear: 3 },
      { name: 'Chemical Engineering', code: 'CH', years: 4, classesPerYear: 3 },
      { name: 'Biotechnology', code: 'BT', years: 6, classesPerYear: 2 },
      { name: 'Computer Applications', code: 'CA', years: 5, classesPerYear: 1 }
    ];

    const firstNames = [
      'Aarav', 'Aditya', 'Arjun', 'Aryan', 'Dhruv', 'Ishaan', 'Karan', 'Krishna',
      'Pranav', 'Reyansh', 'Siddharth', 'Vaibhav', 'Vivaan', 'Yash', 'Rohit', 'Rahul',
      'Ankit', 'Amit', 'Vikash', 'Suresh', 'Rajesh', 'Mahesh', 'Nitesh', 'Harish',
      'Aditi', 'Aisha', 'Ananya', 'Anoushka', 'Diya', 'Ishika', 'Kavya', 'Kiara', 
      'Prisha', 'Riya', 'Sneha', 'Pooja', 'Priya', 'Divya', 'Neha', 'Shreya',
      'Tanvi', 'Sakshi', 'Nisha', 'Meera', 'Swati', 'Deepika', 'Anjali', 'Simran',
      'Akash', 'Ashish', 'Deepak', 'Gaurav', 'Hemant', 'Jatin', 'Kunal', 'Lalit',
      'Manish', 'Naveen', 'Pankaj', 'Ravi', 'Sachin', 'Tarun', 'Umesh', 'Vinod',
      'Bhavna', 'Chitra', 'Geeta', 'Jyoti', 'Kiran', 'Lata', 'Madhuri', 'Nidhi',
      'Preeti', 'Rachna', 'Sunita', 'Tara', 'Usha', 'Vandana', 'Yamini', 'Zarina'
    ];

    const lastNames = [
      'Sharma', 'Verma', 'Gupta', 'Kumar', 'Singh', 'Agarwal', 'Jain', 'Patel',
      'Yadav', 'Mishra', 'Tripathi', 'Pandey', 'Tiwari', 'Srivastava', 'Dubey',
      'Chaurasia', 'Shukla', 'Pathak', 'Saxena', 'Bansal', 'Goyal', 'Mittal',
      'Rastogi', 'Khandelwal', 'Maheshwari', 'Agrawal', 'Chopra', 'Kapoor',
      'Bhardwaj', 'Chandra', 'Dixit', 'Garg', 'Joshi', 'Khan', 'Lal', 'Mohan',
      'Nair', 'Prasad', 'Rai', 'Reddy', 'Shah', 'Thakur', 'Upadhyay', 'Vyas'
    ];

    let rollNumberCounter = 1;

    departments.forEach(dept => {
      for (let year = 1; year <= Math.min(dept.years, 4); year++) { // Generate up to 4 years for demo
        for (let classNum = 1; classNum <= dept.classesPerYear; classNum++) {
          const classCode = dept.classesPerYear === 1 ? 
            `${dept.code}-${year}` : 
            `${dept.code}-${year}${String.fromCharCode(64 + classNum)}`;
          
          // Generate 60 students per class to reach 300+ total students
          for (let i = 1; i <= 60; i++) {
            const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
            const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
            const fullName = `${firstName} ${lastName}`;
            
            const rollNumber = `${dept.code}${String(rollNumberCounter).padStart(4, '0')}`;
            rollNumberCounter++;
            
            const student: Student = {
              id: `student:${rollNumber}`,
              rollNumber,
              name: fullName,
              email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@student.edu`,
              phone: `+91${Math.floor(Math.random() * 9000000000) + 1000000000}`,
              department: dept.name,
              departmentCode: dept.code,
              className: classCode,
              year: year,
              semester: (year - 1) * 2 + 1,
              guardianName: `${lastName} ${firstName.charAt(0).toUpperCase()}. (Father)`,
              guardianPhone: `+91${Math.floor(Math.random() * 9000000000) + 1000000000}`,
              isActive: true,
              currentStatus: Math.random() > 0.9 ? 'left_class' : 'in_class',
              lastActivity: new Date().toISOString(),
              timeoutStart: Math.random() > 0.95 ? new Date(Date.now() - 8 * 60 * 1000).toISOString() : null,
              timeoutDuration: 7 * 60 * 1000,
              alertsSent: false,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            
            this.students.set(student.id, student);
            
            // Add some students to timeout for demo
            if (student.currentStatus === 'left_class' && student.timeoutStart) {
              this.timeoutStudents.set(student.id, student);
            }
          }
        }
      }
    });
  }

  async signIn(email: string, password: string) {
    if (password !== 'password123') {
      return { data: null, error: { message: 'Invalid credentials' } };
    }

    const user = this.users.get(email);
    if (!user) {
      return { data: null, error: { message: 'User not found' } };
    }

    return {
      data: {
        session: { access_token: 'demo-token' },
        user: user
      },
      error: null
    };
  }

  async getAllStudents() {
    return {
      data: Array.from(this.students.values()),
      error: null
    };
  }

  async getTimeoutStudents() {
    const now = new Date();
    const timeoutStudents = Array.from(this.students.values())
      .filter(student => {
        if (student.currentStatus === 'left_class' && student.timeoutStart) {
          const timeoutStartTime = new Date(student.timeoutStart);
          const timeDiff = now.getTime() - timeoutStartTime.getTime();
          return timeDiff >= student.timeoutDuration;
        }
        return false;
      })
      .map(student => {
        const timeoutStartTime = new Date(student.timeoutStart!);
        const timeDiff = now.getTime() - timeoutStartTime.getTime();
        return {
          ...student,
          timeoutDurationPassed: timeDiff,
          needsAlert: !student.alertsSent && timeDiff >= student.timeoutDuration
        };
      });

    return {
      data: timeoutStudents,
      error: null
    };
  }

  async sendStudentAlert(studentId: string, alertType: string = 'timeout') {
    const student = this.students.get(studentId);
    if (!student) {
      return { data: null, error: 'Student not found' };
    }

    const facultyMessage = `ALERT: Student ${student.name} (${student.rollNumber}) from ${student.className} has been absent from class for more than 7 minutes. Please verify attendance.`;
    const parentMessage = `ALERT: Your child ${student.name} (${student.rollNumber}) has been marked absent from ${student.className}. Please contact the college if this is unexpected.`;

    const alertLog = {
      id: `alert:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`,
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      className: student.className,
      alertType: alertType,
      facultyMessage: facultyMessage,
      parentMessage: parentMessage,
      parentPhone: student.guardianPhone,
      timestamp: new Date().toISOString(),
      sentBy: 'demo-user'
    };

    this.alerts.unshift(alertLog);

    // Update student
    const updatedStudent = {
      ...student,
      alertsSent: true,
      updatedAt: new Date().toISOString()
    };
    this.students.set(studentId, updatedStudent);

    return {
      data: {
        message: 'SMS alerts sent successfully',
        alertLog: alertLog,
        student: updatedStudent
      },
      error: null
    };
  }

  async getAlertLogs() {
    return {
      data: this.alerts,
      error: null
    };
  }

  async updateStudentStatus(studentId: string, status: string, timeoutStart?: string) {
    const student = this.students.get(studentId);
    if (!student) {
      return { data: null, error: 'Student not found' };
    }

    const updatedStudent = {
      ...student,
      currentStatus: status as any,
      lastActivity: new Date().toISOString(),
      timeoutStart: timeoutStart || (status === 'left_class' ? new Date().toISOString() : null),
      alertsSent: status === 'in_class' ? false : student.alertsSent,
      updatedAt: new Date().toISOString()
    };

    this.students.set(studentId, updatedStudent);

    return {
      data: updatedStudent,
      error: null
    };
  }

  async initializeDemoUsers() {
    return {
      data: {
        message: 'Demo data loaded successfully (local mode)',
        userCount: this.users.size,
        studentCount: this.students.size
      },
      error: null
    };
  }
}

export const localDemoService = new LocalDemoService();