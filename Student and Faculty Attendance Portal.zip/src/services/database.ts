// Database Service using IndexedDB for robust local storage
// This can be easily migrated to any backend database later

export interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  class: string;
  year: number;
  semester: number;
  profileImage?: string;
  faceEmbedding?: number[]; // For face recognition
  isActive: boolean;
  enrolledDate: string;
  guardianName?: string;
  guardianPhone?: string;
}

export interface Faculty {
  id: string;
  employeeId: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  subjects: string[];
  classes: string[];
  profileImage?: string;
  faceEmbedding?: number[];
  isActive: boolean;
  joinedDate: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userType: 'student' | 'faculty' | 'hod' | 'principal';
  date: string;
  timeIn?: string;
  timeOut?: string;
  status: 'present' | 'absent' | 'late' | 'partial';
  markedBy: string;
  markedByType: 'system' | 'manual' | 'cctv';
  location?: string;
  notes?: string;
  class?: string;
  subject?: string;
}

export interface AttendanceSession {
  id: string;
  date: string;
  class: string;
  subject: string;
  faculty: string;
  startTime: string;
  endTime?: string;
  totalStudents: number;
  presentStudents: number;
  absentStudents: string[];
  lateStudents: string[];
}

export interface User {
  id: string;
  email: string;
  password: string;
  userType: 'student' | 'faculty' | 'hod' | 'principal';
  profileId: string; // References Student or Faculty ID
  lastLogin?: string;
  isActive: boolean;
  permissions: string[];
}

class DatabaseService {
  private db: IDBDatabase | null = null;
  private readonly dbName = 'AttendanceSystemDB';
  private readonly version = 1;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create object stores
        if (!db.objectStoreNames.contains('students')) {
          const studentStore = db.createObjectStore('students', { keyPath: 'id' });
          studentStore.createIndex('rollNumber', 'rollNumber', { unique: true });
          studentStore.createIndex('email', 'email', { unique: true });
          studentStore.createIndex('department', 'department');
          studentStore.createIndex('class', 'class');
        }

        if (!db.objectStoreNames.contains('faculty')) {
          const facultyStore = db.createObjectStore('faculty', { keyPath: 'id' });
          facultyStore.createIndex('employeeId', 'employeeId', { unique: true });
          facultyStore.createIndex('email', 'email', { unique: true });
          facultyStore.createIndex('department', 'department');
        }

        if (!db.objectStoreNames.contains('users')) {
          const userStore = db.createObjectStore('users', { keyPath: 'id' });
          userStore.createIndex('email', 'email', { unique: true });
          userStore.createIndex('userType', 'userType');
        }

        if (!db.objectStoreNames.contains('attendance')) {
          const attendanceStore = db.createObjectStore('attendance', { keyPath: 'id' });
          attendanceStore.createIndex('userId', 'userId');
          attendanceStore.createIndex('date', 'date');
          attendanceStore.createIndex('userType', 'userType');
          attendanceStore.createIndex('class', 'class');
        }

        if (!db.objectStoreNames.contains('sessions')) {
          const sessionStore = db.createObjectStore('sessions', { keyPath: 'id' });
          sessionStore.createIndex('date', 'date');
          sessionStore.createIndex('class', 'class');
          sessionStore.createIndex('faculty', 'faculty');
        }
      };
    });
  }

  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // Student Operations
  async addStudent(student: Omit<Student, 'id'>): Promise<Student> {
    if (!this.db) throw new Error('Database not initialized');
    
    const newStudent: Student = {
      ...student,
      id: this.generateId(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readwrite');
      const store = transaction.objectStore('students');
      const request = store.add(newStudent);

      request.onsuccess = () => resolve(newStudent);
      request.onerror = () => reject(request.error);
    });
  }

  async getStudent(id: string): Promise<Student | null> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readonly');
      const store = transaction.objectStore('students');
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async getStudentByRoll(rollNumber: string): Promise<Student | null> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readonly');
      const store = transaction.objectStore('students');
      const index = store.index('rollNumber');
      const request = index.get(rollNumber);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllStudents(): Promise<Student[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readonly');
      const store = transaction.objectStore('students');
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getStudentsByClass(className: string): Promise<Student[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readonly');
      const store = transaction.objectStore('students');
      const index = store.index('class');
      const request = index.getAll(className);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async updateStudent(id: string, updates: Partial<Student>): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const student = await this.getStudent(id);
    if (!student) throw new Error('Student not found');

    const updatedStudent = { ...student, ...updates };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['students'], 'readwrite');
      const store = transaction.objectStore('students');
      const request = store.put(updatedStudent);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Faculty Operations
  async addFaculty(faculty: Omit<Faculty, 'id'>): Promise<Faculty> {
    if (!this.db) throw new Error('Database not initialized');
    
    const newFaculty: Faculty = {
      ...faculty,
      id: this.generateId(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['faculty'], 'readwrite');
      const store = transaction.objectStore('faculty');
      const request = store.add(newFaculty);

      request.onsuccess = () => resolve(newFaculty);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllFaculty(): Promise<Faculty[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['faculty'], 'readonly');
      const store = transaction.objectStore('faculty');
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // User Authentication
  async addUser(user: Omit<User, 'id'>): Promise<User> {
    if (!this.db) throw new Error('Database not initialized');
    
    const newUser: User = {
      ...user,
      id: this.generateId(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['users'], 'readwrite');
      const store = transaction.objectStore('users');
      const request = store.add(newUser);

      request.onsuccess = () => resolve(newUser);
      request.onerror = () => reject(request.error);
    });
  }

  async getUserByEmail(email: string): Promise<User | null> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['users'], 'readonly');
      const store = transaction.objectStore('users');
      const index = store.index('email');
      const request = index.get(email);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async updateUser(id: string, updates: Partial<User>): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const user = await this.getUser(id);
    if (!user) throw new Error('User not found');

    const updatedUser = { ...user, ...updates };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['users'], 'readwrite');
      const store = transaction.objectStore('users');
      const request = store.put(updatedUser);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getUser(id: string): Promise<User | null> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['users'], 'readonly');
      const store = transaction.objectStore('users');
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  // Attendance Operations
  async markAttendance(attendance: Omit<AttendanceRecord, 'id'>): Promise<AttendanceRecord> {
    if (!this.db) throw new Error('Database not initialized');
    
    const newAttendance: AttendanceRecord = {
      ...attendance,
      id: this.generateId(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['attendance'], 'readwrite');
      const store = transaction.objectStore('attendance');
      const request = store.add(newAttendance);

      request.onsuccess = () => resolve(newAttendance);
      request.onerror = () => reject(request.error);
    });
  }

  async getAttendanceByUser(userId: string, startDate?: string, endDate?: string): Promise<AttendanceRecord[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['attendance'], 'readonly');
      const store = transaction.objectStore('attendance');
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        let results = request.result;
        
        if (startDate || endDate) {
          results = results.filter(record => {
            if (startDate && record.date < startDate) return false;
            if (endDate && record.date > endDate) return false;
            return true;
          });
        }
        
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAttendanceByDate(date: string): Promise<AttendanceRecord[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['attendance'], 'readonly');
      const store = transaction.objectStore('attendance');
      const index = store.index('date');
      const request = index.getAll(date);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAttendanceByClass(className: string, date?: string): Promise<AttendanceRecord[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['attendance'], 'readonly');
      const store = transaction.objectStore('attendance');
      const index = store.index('class');
      const request = index.getAll(className);

      request.onsuccess = () => {
        let results = request.result;
        
        if (date) {
          results = results.filter(record => record.date === date);
        }
        
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  }

  // Analytics and Reports
  async getAttendanceStats(userId: string, period: 'week' | 'month' | 'semester'): Promise<{
    totalDays: number;
    presentDays: number;
    absentDays: number;
    percentage: number;
    lateCount: number;
  }> {
    const records = await this.getAttendanceByUser(userId);
    
    // Calculate date range based on period
    const today = new Date();
    const startDate = new Date();
    
    switch (period) {
      case 'week':
        startDate.setDate(today.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(today.getMonth() - 1);
        break;
      case 'semester':
        startDate.setMonth(today.getMonth() - 6);
        break;
    }

    const filteredRecords = records.filter(record => 
      new Date(record.date) >= startDate
    );

    const totalDays = filteredRecords.length;
    const presentDays = filteredRecords.filter(r => r.status === 'present').length;
    const absentDays = filteredRecords.filter(r => r.status === 'absent').length;
    const lateCount = filteredRecords.filter(r => r.status === 'late').length;
    const percentage = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;

    return {
      totalDays,
      presentDays,
      absentDays,
      percentage: Math.round(percentage * 100) / 100,
      lateCount
    };
  }

  // Initialize with sample data
  async initializeSampleData(): Promise<void> {
    try {
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Database initialization timeout')), 10000)
      );
      
      const initPromise = this.performInitialization();
      
      await Promise.race([initPromise, timeoutPromise]);
    } catch (error) {
      console.error('Error initializing sample data:', error);
      // Don't throw - let the application continue without sample data
    }
  }

  private async performInitialization(): Promise<void> {
    const existingStudents = await this.getAllStudents();
    if (existingStudents.length > 0) return; // Data already exists

    // Sample Students
    const sampleStudents: Omit<Student, 'id'>[] = [
        {
          rollNumber: 'CS001',
          name: 'John Doe',
          email: 'john.doe@student.edu',
          phone: '+1234567890',
          department: 'Computer Science',
          class: 'CS-4A',
          year: 4,
          semester: 8,
          isActive: true,
          enrolledDate: '2021-08-15',
          guardianName: 'Robert Doe',
          guardianPhone: '+1234567891'
        },
        {
          rollNumber: 'CS002',
          name: 'Jane Smith',
          email: 'jane.smith@student.edu',
          phone: '+1234567892',
          department: 'Computer Science',
          class: 'CS-4A',
          year: 4,
          semester: 8,
          isActive: true,
          enrolledDate: '2021-08-15',
          guardianName: 'Mary Smith',
          guardianPhone: '+1234567893'
        },
        {
          rollNumber: 'CS003',
          name: 'Mike Johnson',
          email: 'mike.johnson@student.edu',
          phone: '+1234567894',
          department: 'Computer Science',
          class: 'CS-4A',
          year: 4,
          semester: 8,
          isActive: true,
          enrolledDate: '2021-08-15',
          guardianName: 'David Johnson',
          guardianPhone: '+1234567895'
        }
      ];

      // Sample Faculty
      const sampleFaculty: Omit<Faculty, 'id'>[] = [
        {
          employeeId: 'FAC001',
          name: 'Dr. Sarah Wilson',
          email: 'sarah.wilson@college.edu',
          phone: '+1234567896',
          department: 'Computer Science',
          designation: 'Professor',
          subjects: ['Data Structures', 'Algorithms', 'Database Systems'],
          classes: ['CS-4A', 'CS-4B', 'CS-3A'],
          isActive: true,
          joinedDate: '2018-06-01'
        },
        {
          employeeId: 'HOD001',
          name: 'Dr. David Brown',
          email: 'david.brown@college.edu',
          phone: '+1234567897',
          department: 'Computer Science',
          designation: 'HOD',
          subjects: ['Software Engineering', 'Project Management'],
          classes: ['CS-4A', 'CS-4B'],
          isActive: true,
          joinedDate: '2015-03-15'
        }
      ];

      // Add sample data
      for (const student of sampleStudents) {
        await this.addStudent(student);
      }

      for (const faculty of sampleFaculty) {
        await this.addFaculty(faculty);
      }

      // Sample Users
      const sampleUsers: Omit<User, 'id'>[] = [
        {
          email: 'john.doe@student.edu',
          password: 'password123',
          userType: 'student',
          profileId: 'student-id-placeholder',
          isActive: true,
          permissions: ['view_own_attendance', 'mark_own_attendance']
        },
        {
          email: 'sarah.wilson@college.edu',
          password: 'password123',
          userType: 'faculty',
          profileId: 'faculty-id-placeholder',
          isActive: true,
          permissions: ['view_class_attendance', 'mark_class_attendance', 'view_reports']
        },
        {
          email: 'david.brown@college.edu',
          password: 'password123',
          userType: 'hod',
          profileId: 'hod-id-placeholder',
          isActive: true,
          permissions: ['view_department_attendance', 'view_faculty_attendance', 'generate_reports']
        },
        {
          email: 'principal@college.edu',
          password: 'password123',
          userType: 'principal',
          profileId: 'principal-id-placeholder',
          isActive: true,
          permissions: ['view_all_attendance', 'view_all_reports', 'manage_system']
        }
      ];

      for (const user of sampleUsers) {
        await this.addUser(user);
      }

      console.log('Sample data initialized successfully');
  }
}

export const dbService = new DatabaseService();