// Attendance Service for managing attendance data with localStorage persistence
// This provides a working system that can later be upgraded to use a real database

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  userType: 'student' | 'faculty' | 'hod' | 'principal';
  date: string;
  time: string;
  status: 'present' | 'absent' | 'late';
  method: 'cctv' | 'manual' | 'biometric';
  markedBy: string;
  location?: string;
  className?: string;
  subject?: string;
}

export interface AttendanceStats {
  totalClasses: number;
  classesAttended: number;
  totalAbsents: number;
  percentage: number;
  monthlyData: Array<{ month: string; attendance: number; }>;
  subjectWise: Array<{
    subject: string;
    total: number;
    attended: number;
    percentage: number;
  }>;
}

class AttendanceService {
  private readonly storageKey = 'attendance_records';
  private readonly userStatsKey = 'user_attendance_stats';

  // Get all attendance records
  getAttendanceRecords(): AttendanceRecord[] {
    try {
      const records = localStorage.getItem(this.storageKey);
      return records ? JSON.parse(records) : [];
    } catch (error) {
      console.error('Error reading attendance records:', error);
      return [];
    }
  }

  // Save attendance records
  private saveAttendanceRecords(records: AttendanceRecord[]): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(records));
    } catch (error) {
      console.error('Error saving attendance records:', error);
    }
  }

  // Mark attendance for a user
  markAttendance(attendance: Omit<AttendanceRecord, 'id'>): AttendanceRecord {
    const records = this.getAttendanceRecords();
    const todayDate = new Date().toISOString().split('T')[0];
    
    // Check if attendance already marked today for this user
    const existingRecord = records.find(record => 
      record.userId === attendance.userId && 
      record.date === todayDate
    );

    if (existingRecord) {
      // Update existing record
      existingRecord.time = attendance.time;
      existingRecord.status = attendance.status;
      existingRecord.method = attendance.method;
      existingRecord.markedBy = attendance.markedBy;
      this.saveAttendanceRecords(records);
      return existingRecord;
    } else {
      // Create new record
      const newRecord: AttendanceRecord = {
        ...attendance,
        id: this.generateId(),
        date: todayDate
      };
      
      records.push(newRecord);
      this.saveAttendanceRecords(records);
      return newRecord;
    }
  }

  // Mark attendance for multiple users (batch operation)
  markBatchAttendance(users: Array<{
    userId: string;
    userName: string;
    userType: 'student' | 'faculty' | 'hod' | 'principal';
  }>, markedBy: string, method: 'cctv' | 'manual' | 'biometric' = 'cctv'): AttendanceRecord[] {
    const currentTime = new Date().toISOString().split('T')[1].split('.')[0];
    const markedRecords: AttendanceRecord[] = [];

    users.forEach(user => {
      const record = this.markAttendance({
        userId: user.userId,
        userName: user.userName,
        userType: user.userType,
        time: currentTime,
        status: 'present',
        method: method,
        markedBy: markedBy,
        className: 'CS-4A', // Default class - can be made dynamic
        subject: 'Current Class' // Default subject - can be made dynamic
      });
      markedRecords.push(record);
    });

    return markedRecords;
  }

  // Get attendance records for a specific user
  getUserAttendance(userId: string, startDate?: string, endDate?: string): AttendanceRecord[] {
    const records = this.getAttendanceRecords();
    let userRecords = records.filter(record => record.userId === userId);

    if (startDate || endDate) {
      userRecords = userRecords.filter(record => {
        if (startDate && record.date < startDate) return false;
        if (endDate && record.date > endDate) return false;
        return true;
      });
    }

    return userRecords.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  // Get attendance stats for a user
  getUserStats(userId: string): AttendanceStats {
    const userRecords = this.getUserAttendance(userId);
    
    // Calculate basic stats
    const totalClasses = userRecords.length;
    const classesAttended = userRecords.filter(r => r.status === 'present').length;
    const totalAbsents = userRecords.filter(r => r.status === 'absent').length;
    const percentage = totalClasses > 0 ? Math.round((classesAttended / totalClasses) * 100) : 0;

    // Generate monthly data for the last 6 months
    const monthlyData = this.generateMonthlyData(userRecords);
    
    // Generate subject-wise data
    const subjectWise = this.generateSubjectWiseData(userRecords);

    return {
      totalClasses,
      classesAttended,
      totalAbsents,
      percentage,
      monthlyData,
      subjectWise
    };
  }

  // Check if user has marked attendance today
  hasMarkedToday(userId: string): boolean {
    const todayDate = new Date().toISOString().split('T')[0];
    const records = this.getAttendanceRecords();
    return records.some(record => 
      record.userId === userId && 
      record.date === todayDate
    );
  }

  // Get today's attendance for all users
  getTodayAttendance(): AttendanceRecord[] {
    const todayDate = new Date().toISOString().split('T')[0];
    const records = this.getAttendanceRecords();
    return records.filter(record => record.date === todayDate);
  }

  // Generate monthly attendance data
  private generateMonthlyData(records: AttendanceRecord[]): Array<{ month: string; attendance: number; }> {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const monthlyData: Array<{ month: string; attendance: number; }> = [];

    for (let i = 5; i >= 0; i--) {
      const monthIndex = (currentMonth - i + 12) % 12;
      const monthName = months[monthIndex];
      
      // Calculate attendance percentage for this month
      const monthRecords = records.filter(record => {
        const recordDate = new Date(record.date);
        return recordDate.getMonth() === monthIndex;
      });
      
      const presentCount = monthRecords.filter(r => r.status === 'present').length;
      const totalCount = monthRecords.length;
      const percentage = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;
      
      monthlyData.push({
        month: monthName,
        attendance: percentage
      });
    }

    return monthlyData;
  }

  // Generate subject-wise attendance data
  private generateSubjectWiseData(records: AttendanceRecord[]): Array<{
    subject: string;
    total: number;
    attended: number;
    percentage: number;
  }> {
    const subjects = ['Mathematics', 'Physics', 'Chemistry', 'English', 'Computer Science'];
    const subjectData: Array<{
      subject: string;
      total: number;
      attended: number;
      percentage: number;
    }> = [];

    subjects.forEach(subject => {
      // For demo purposes, distribute records across subjects
      const subjectRecords = records.filter((_, index) => {
        return index % subjects.length === subjects.indexOf(subject);
      });
      
      const total = Math.max(subjectRecords.length, 1); // Ensure at least 1 for calculation
      const attended = subjectRecords.filter(r => r.status === 'present').length;
      const percentage = Math.round((attended / total) * 100);
      
      subjectData.push({
        subject,
        total,
        attended,
        percentage
      });
    });

    return subjectData;
  }

  // Initialize sample data for new users
  initializeSampleData(userId: string, userName: string, userType: 'student' | 'faculty' | 'hod' | 'principal'): void {
    const existingRecords = this.getUserAttendance(userId);
    
    // Only initialize if user has no records
    if (existingRecords.length === 0) {
      const sampleRecords: Omit<AttendanceRecord, 'id'>[] = [];
      const today = new Date();
      
      // Generate 30 days of sample attendance data
      for (let i = 30; i >= 1; i--) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        
        // Skip weekends for sample data
        if (date.getDay() === 0 || date.getDay() === 6) continue;
        
        // 90% attendance rate for sample data
        const isPresent = Math.random() > 0.1;
        
        sampleRecords.push({
          userId,
          userName,
          userType,
          date: date.toISOString().split('T')[0],
          time: '09:00:00',
          status: isPresent ? 'present' : 'absent',
          method: 'cctv',
          markedBy: 'System',
          className: 'CS-4A',
          subject: ['Mathematics', 'Physics', 'Chemistry', 'English', 'Computer Science'][Math.floor(Math.random() * 5)]
        });
      }
      
      // Add all sample records
      const records = this.getAttendanceRecords();
      const newRecords = sampleRecords.map(record => ({
        ...record,
        id: this.generateId()
      }));
      
      records.push(...newRecords);
      this.saveAttendanceRecords(records);
    }
  }

  // Generate unique ID
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // Clear all attendance data (for testing)
  clearAllData(): void {
    localStorage.removeItem(this.storageKey);
    localStorage.removeItem(this.userStatsKey);
  }

  // Export attendance data
  exportAttendanceData(): { records: AttendanceRecord[]; exportDate: string; } {
    return {
      records: this.getAttendanceRecords(),
      exportDate: new Date().toISOString()
    };
  }

  // Import attendance data
  importAttendanceData(data: { records: AttendanceRecord[]; }): void {
    this.saveAttendanceRecords(data.records);
  }
}

export const attendanceService = new AttendanceService();