// Simple Authentication Service using localStorage
// This provides working authentication without complex database dependencies

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  interfaceType: 'student' | 'faculty' | 'hod' | 'principal';
  rollNumber?: string;
  department?: string;
  employeeId?: string;
  createdAt: string;
  lastLogin?: string;
}

class SimpleAuthService {
  private readonly storageKey = 'simple_auth_users';
  private readonly sessionKey = 'current_user_session';

  // Get all users from localStorage
  private getUsers(): Array<UserProfile & { password: string }> {
    try {
      const users = localStorage.getItem(this.storageKey);
      return users ? JSON.parse(users) : this.getDefaultUsers();
    } catch (error) {
      console.error('Error reading users:', error);
      return this.getDefaultUsers();
    }
  }

  // Save users to localStorage
  private saveUsers(users: Array<UserProfile & { password: string }>): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(users));
    } catch (error) {
      console.error('Error saving users:', error);
    }
  }

  // Get default demo users
  private getDefaultUsers(): Array<UserProfile & { password: string }> {
    return [
      {
        id: 'student-1',
        email: 'john.doe@student.edu',
        password: 'password123',
        fullName: 'John Doe',
        interfaceType: 'student',
        rollNumber: 'CS001',
        department: 'Computer Science',
        createdAt: new Date().toISOString()
      },
      {
        id: 'faculty-1',
        email: 'sarah.wilson@college.edu',
        password: 'password123',
        fullName: 'Dr. Sarah Wilson',
        interfaceType: 'faculty',
        employeeId: 'FAC001',
        department: 'Computer Science',
        createdAt: new Date().toISOString()
      },
      {
        id: 'hod-1',
        email: 'david.brown@college.edu',
        password: 'password123',
        fullName: 'Dr. David Brown',
        interfaceType: 'hod',
        employeeId: 'HOD001',
        department: 'Computer Science',
        createdAt: new Date().toISOString()
      },
      {
        id: 'principal-1',
        email: 'principal@college.edu',
        password: 'password123',
        fullName: 'Dr. Principal',
        interfaceType: 'principal',
        employeeId: 'PRIN001',
        department: 'Administration',
        createdAt: new Date().toISOString()
      }
    ];
  }

  // Login user
  async login(email: string, password: string, expectedUserType: 'student' | 'faculty' | 'hod' | 'principal'): Promise<UserProfile> {
    const users = this.getUsers();
    const user = users.find(u => u.email === email);

    if (!user) {
      throw new Error('User not found. Please check your email or sign up.');
    }

    if (user.password !== password) {
      throw new Error('Invalid password. Please try again.');
    }

    if (user.interfaceType !== expectedUserType) {
      throw new Error(`This account is not authorized for ${expectedUserType} access.`);
    }

    // Update last login
    user.lastLogin = new Date().toISOString();
    this.saveUsers(users);

    // Create session
    const userProfile: UserProfile = {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      interfaceType: user.interfaceType,
      rollNumber: user.rollNumber,
      department: user.department,
      employeeId: user.employeeId,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin
    };

    this.setCurrentSession(userProfile);
    return userProfile;
  }

  // Register new user
  async register(userData: {
    email: string;
    password: string;
    fullName: string;
    interfaceType: 'student' | 'faculty' | 'hod' | 'principal';
    rollNumber?: string;
    department: string;
    employeeId?: string;
  }): Promise<UserProfile> {
    const users = this.getUsers();
    
    // Check if user already exists
    const existingUser = users.find(u => u.email === userData.email);
    if (existingUser) {
      throw new Error('User with this email already exists.');
    }

    // Check roll number for students
    if (userData.interfaceType === 'student' && userData.rollNumber) {
      const existingStudent = users.find(u => u.rollNumber === userData.rollNumber);
      if (existingStudent) {
        throw new Error('Student with this roll number already exists.');
      }
    }

    // Check employee ID for faculty/staff
    if (userData.interfaceType !== 'student' && userData.employeeId) {
      const existingEmployee = users.find(u => u.employeeId === userData.employeeId);
      if (existingEmployee) {
        throw new Error('Employee with this ID already exists.');
      }
    }

    // Create new user
    const newUser = {
      id: this.generateId(),
      email: userData.email,
      password: userData.password,
      fullName: userData.fullName,
      interfaceType: userData.interfaceType,
      rollNumber: userData.rollNumber,
      department: userData.department,
      employeeId: userData.employeeId,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    };

    users.push(newUser);
    this.saveUsers(users);

    // Create user profile without password
    const userProfile: UserProfile = {
      id: newUser.id,
      email: newUser.email,
      fullName: newUser.fullName,
      interfaceType: newUser.interfaceType,
      rollNumber: newUser.rollNumber,
      department: newUser.department,
      employeeId: newUser.employeeId,
      createdAt: newUser.createdAt,
      lastLogin: newUser.lastLogin
    };

    this.setCurrentSession(userProfile);
    return userProfile;
  }

  // Set current user session
  private setCurrentSession(user: UserProfile): void {
    try {
      localStorage.setItem(this.sessionKey, JSON.stringify(user));
    } catch (error) {
      console.error('Error saving session:', error);
    }
  }

  // Get current user session
  getCurrentSession(): UserProfile | null {
    try {
      const session = localStorage.getItem(this.sessionKey);
      return session ? JSON.parse(session) : null;
    } catch (error) {
      console.error('Error reading session:', error);
      return null;
    }
  }

  // Logout user
  logout(): void {
    try {
      localStorage.removeItem(this.sessionKey);
    } catch (error) {
      console.error('Error during logout:', error);
    }
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return this.getCurrentSession() !== null;
  }

  // Generate unique ID
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // Initialize default users (call this on app start)
  initializeDefaultUsers(): void {
    const users = this.getUsers();
    // Save default users if storage is empty
    this.saveUsers(users);
  }

  // Clear all data (for testing)
  clearAllData(): void {
    localStorage.removeItem(this.storageKey);
    localStorage.removeItem(this.sessionKey);
  }
}

export const simpleAuthService = new SimpleAuthService();