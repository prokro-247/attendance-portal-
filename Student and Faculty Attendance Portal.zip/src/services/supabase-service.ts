import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { localDemoService } from './local-demo-service';

// Initialize Supabase client
const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// Types for our attendance system
export interface User {
  id: string;
  email: string;
  fullName: string;
  interfaceType: 'student' | 'faculty' | 'hod' | 'principal';
  employeeId?: string;
  className?: string;
  department?: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  userType: string;
  date: string;
  time: string;
  status: 'present' | 'absent';
  method: 'manual' | 'cctv';
  markedBy: string;
  className: string;
  subject: string;
  location: string;
  timestamp: string;
}

export interface AttendanceData {
  totalDays: number;
  presentDays: number;
  absentDays: number;
  percentage: number;
  recentRecords: AttendanceRecord[];
}

class SupabaseAttendanceService {
  private baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-3d5883fa`;

  // Get current session
  async getSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    return { session, error };
  }

  // Sign up new user
  async signUp(userData: {
    email: string;
    password: string;
    fullName: string;
    interfaceType: string;
    employeeId?: string;
    className?: string;
    department?: string;
  }) {
    try {
      const response = await fetch(`${this.baseUrl}/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(userData),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Signup failed');
      }

      return { data: result, error: null };
    } catch (error) {
      console.error('Signup error:', error);
      return { data: null, error: error.message };
    }
  }

  // Sign in user
  async signIn(email: string, password: string) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        // Fall back to local demo service
        console.log('Supabase auth failed, trying local demo service');
        return await localDemoService.signIn(email, password);
      }

      if (!data.session || !data.user) {
        // Fall back to local demo service
        return await localDemoService.signIn(email, password);
      }

      // Wait a moment for session to be fully established
      await new Promise(resolve => setTimeout(resolve, 100));

      // Get user profile from our backend
      const userProfile = await this.getUserProfile(data.user.id);
      
      if (userProfile.error) {
        console.error('Failed to get user profile:', userProfile.error);
        // Fall back to local demo service
        return await localDemoService.signIn(email, password);
      }
      
      return { 
        data: { 
          session: data.session, 
          user: userProfile.data 
        }, 
        error: null 
      };
    } catch (error) {
      console.error('Sign in error:', error);
      // Fall back to local demo service
      return await localDemoService.signIn(email, password);
    }
  }

  // Sign out user
  async signOut() {
    return await supabase.auth.signOut();
  }

  // Get user profile
  async getUserProfile(userId: string, retryCount = 0) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        if (retryCount < 3) {
          // Wait and retry if session is not ready yet
          await new Promise(resolve => setTimeout(resolve, 200));
          return this.getUserProfile(userId, retryCount + 1);
        }
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/user/${userId}`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch user profile');
      }

      return { data: result.user, error: null };
    } catch (error) {
      console.error('Get user profile error:', error);
      // Return user data from auth session as fallback
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        return { 
          data: {
            id: session.user.id,
            email: session.user.email,
            fullName: session.user.user_metadata?.fullName || session.user.email,
            interfaceType: session.user.user_metadata?.interfaceType || 'student',
            employeeId: session.user.user_metadata?.employeeId,
            className: session.user.user_metadata?.className,
            department: session.user.user_metadata?.department
          }, 
          error: null 
        };
      }
      return { data: null, error: error.message };
    }
  }

  // Mark attendance
  async markAttendance(attendanceData: {
    userId: string;
    userName: string;
    userType: string;
    time: string;
    status: 'present' | 'absent';
    method: 'manual' | 'cctv';
    markedBy: string;
    className: string;
    subject: string;
    location?: string;
  }) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/attendance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(attendanceData),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to mark attendance');
      }

      return { data: result.record, error: null };
    } catch (error) {
      console.error('Mark attendance error:', error);
      // Create a mock record as fallback
      const mockRecord = {
        id: `attendance:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`,
        ...attendanceData,
        date: new Date().toISOString().split('T')[0],
        timestamp: new Date().toISOString()
      };
      return { data: mockRecord, error: null };
    }
  }

  // Bulk mark attendance (for CCTV)
  async markBulkAttendance(data: {
    attendanceRecords: Array<{
      userId: string;
      userName: string;
      userType?: string;
      status: 'present' | 'absent';
    }>;
    markedBy: string;
    className: string;
    subject: string;
  }) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/attendance/bulk`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to mark bulk attendance');
      }

      return { data: result.records, error: null };
    } catch (error) {
      console.error('Bulk attendance error:', error);
      // Create mock records as fallback
      const mockRecords = data.attendanceRecords.map(record => ({
        id: `attendance:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`,
        userId: record.userId,
        userName: record.userName,
        userType: record.userType || 'student',
        date: new Date().toISOString().split('T')[0],
        time: new Date().toISOString().split('T')[1].split('.')[0],
        status: record.status,
        method: 'cctv' as const,
        markedBy: data.markedBy,
        className: data.className,
        subject: data.subject,
        location: 'CCTV Camera',
        timestamp: new Date().toISOString()
      }));
      return { data: mockRecords, error: null };
    }
  }

  // Get attendance records for a user
  async getAttendanceRecords(userId: string) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/attendance/${userId}`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch attendance records');
      }

      return { data: result.records, error: null };
    } catch (error) {
      console.error('Get attendance records error:', error);
      // Return demo attendance data as fallback
      const demoRecords = this.generateDemoAttendanceRecords(userId);
      return { data: demoRecords, error: null };
    }
  }

  // Get all attendance records (for admin views)
  async getAllAttendanceRecords() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/attendance`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch attendance records');
      }

      return { data: result.records, error: null };
    } catch (error) {
      console.error('Get all attendance records error:', error);
      return { data: [], error: error.message };
    }
  }

  // Get analytics data
  async getAnalytics(userType: string, userId: string) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/analytics/${userType}/${userId}`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch analytics');
      }

      return { data: result.analytics, error: null };
    } catch (error) {
      console.error('Get analytics error:', error);
      return { data: null, error: error.message };
    }
  }

  // Calculate attendance data from records
  calculateAttendanceData(records: AttendanceRecord[]): AttendanceData {
    const totalDays = records.length;
    const presentDays = records.filter(record => record.status === 'present').length;
    const absentDays = totalDays - presentDays;
    const percentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0;

    return {
      totalDays,
      presentDays,
      absentDays,
      percentage,
      recentRecords: records.slice(0, 10)
    };
  }

  // Check if user has marked attendance today
  hasMarkedToday(records: AttendanceRecord[]): boolean {
    const today = new Date().toISOString().split('T')[0];
    return records.some(record => record.date === today);
  }

  // Get attendance status and color
  getAttendanceStatus(percentage: number) {
    if (percentage >= 85) return { status: 'Excellent', color: 'bg-green-600' };
    if (percentage >= 75) return { status: 'Good', color: 'bg-blue-600' };
    if (percentage >= 65) return { status: 'Average', color: 'bg-yellow-600' };
    return { status: 'Poor', color: 'bg-red-600' };
  }

  // Initialize demo users with timeout protection
  async initializeDemoUsers() {
    try {
      // Create timeout promise to prevent hanging
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Demo initialization timeout')), 2500);
      });

      const initPromise = (async () => {
        const response = await fetch(`${this.baseUrl}/init-demo`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        });

        const result = await response.json();
        
        if (!response.ok) {
          throw new Error(result.error || 'Failed to initialize demo users');
        }

        return { data: result, error: null };
      })();

      return await Promise.race([initPromise, timeoutPromise]);
    } catch (error) {
      // Silently handle timeout and other errors - this is expected behavior
      console.log('Using local demo service (backend unavailable)');
      // Fall back to local demo service
      return await localDemoService.initializeDemoUsers();
    }
  }

  // Add student
  async addStudent(studentData: any) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/students`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(studentData),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to add student');
      }

      return { data: result.student, error: null };
    } catch (error) {
      console.error('Add student error:', error);
      return { data: null, error: error.message };
    }
  }

  // Get all students
  async getAllStudents() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/students`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch students');
      }

      return { data: result.students, error: null };
    } catch (error) {
      console.error('Get all students error:', error);
      // Fall back to local demo service
      return await localDemoService.getAllStudents();
    }
  }

  // Update student status for timeout tracking
  async updateStudentStatus(studentId: string, status: string, timeoutStart?: string) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/students/${studentId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ status, timeoutStart }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to update student status');
      }

      return { data: result.student, error: null };
    } catch (error) {
      console.error('Update student status error:', error);
      // Fall back to local demo service
      return await localDemoService.updateStudentStatus(studentId, status, timeoutStart);
    }
  }

  // Get timeout students
  async getTimeoutStudents() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/students/timeouts`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch timeout students');
      }

      return { data: result.students, error: null };
    } catch (error) {
      console.error('Get timeout students error:', error);
      // Fall back to local demo service
      return await localDemoService.getTimeoutStudents();
    }
  }

  // Send SMS alert for student
  async sendStudentAlert(studentId: string, alertType: string = 'timeout') {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/students/${studentId}/alert`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ alertType }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to send alert');
      }

      return { data: result, error: null };
    } catch (error) {
      console.error('Send alert error:', error);
      // Fall back to local demo service
      return await localDemoService.sendStudentAlert(studentId, alertType);
    }
  }

  // Get alert logs
  async getAlertLogs() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${this.baseUrl}/alerts`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch alerts');
      }

      return { data: result.alerts, error: null };
    } catch (error) {
      console.error('Get alerts error:', error);
      // Fall back to local demo service
      return await localDemoService.getAlertLogs();
    }
  }

  // Generate demo students list for fallback
  private generateDemoStudentsList() {
    const departments = [
      { name: 'Computer Science', code: 'CSE', years: 4, classesPerYear: 3 },
      { name: 'Computer Science & Machine Learning', code: 'CSM', years: 4, classesPerYear: 3 },
      { name: 'Computer Science & Data Science', code: 'CSD', years: 4, classesPerYear: 3 },
      { name: 'Electrical & Electronics Engineering', code: 'EEE', years: 4, classesPerYear: 3 },
      { name: 'Electronics & Communication Engineering', code: 'ECE', years: 4, classesPerYear: 3 },
      { name: 'Information Technology', code: 'IT', years: 4, classesPerYear: 3 },
      { name: 'Internet of Things', code: 'IoT', years: 4, classesPerYear: 3 },
      { name: 'Biotechnology', code: 'BT', years: 6, classesPerYear: 2 },
      { name: 'Computer Applications', code: 'CA', years: 5, classesPerYear: 1 },
      { name: 'Mechanical Engineering', code: 'ME', years: 4, classesPerYear: 2 },
      { name: 'Civil Engineering', code: 'CE', years: 4, classesPerYear: 2 },
      { name: 'Chemical Engineering', code: 'CH', years: 4, classesPerYear: 2 }
    ];

    const firstNames = [
      'Aarav', 'Aditya', 'Arjun', 'Aryan', 'Dhruv', 'Ishaan', 'Karan', 'Krishna',
      'Pranav', 'Reyansh', 'Siddharth', 'Vaibhav', 'Vivaan', 'Yash', 'Aditi', 'Aisha',
      'Ananya', 'Anoushka', 'Diya', 'Ishika', 'Kavya', 'Kiara', 'Prisha', 'Riya'
    ];

    const lastNames = [
      'Sharma', 'Verma', 'Gupta', 'Kumar', 'Singh', 'Agarwal', 'Jain', 'Patel',
      'Reddy', 'Nair', 'Iyer', 'Rao', 'Das', 'Roy', 'Joshi', 'Pandey'
    ];

    const students = [];
    let rollNumberCounter = 1;

    // Generate a subset of demo students
    departments.slice(0, 6).forEach(dept => {
      for (let year = 1; year <= Math.min(dept.years, 2); year++) {
        for (let classNum = 1; classNum <= Math.min(dept.classesPerYear, 1); classNum++) {
          const classCode = dept.classesPerYear === 1 ? 
            `${dept.code}-${year}` : 
            `${dept.code}-${year}${String.fromCharCode(64 + classNum)}`;
          
          for (let i = 1; i <= 10; i++) { // 10 students per class for demo
            const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
            const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
            const fullName = `${firstName} ${lastName}`;
            
            const rollNumber = `${dept.code}${String(rollNumberCounter).padStart(4, '0')}`;
            rollNumberCounter++;
            
            const student = {
              id: `student:${rollNumber}`,
              rollNumber,
              name: fullName,
              email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@student.edu`,
              phone: `+91${Math.floor(Math.random() * 9000000000) + 1000000000}`,
              department: dept.name,
              departmentCode: dept.code,
              className: classCode,
              year: year,
              semester: (year - 1) * 2 + 1,
              guardianName: `${firstName} ${lastName} (Father)`,
              guardianPhone: `+91${Math.floor(Math.random() * 9000000000) + 1000000000}`,
              isActive: true,
              enrolledDate: `2024-08-15`,
              currentStatus: Math.random() > 0.8 ? 'left_class' : 'in_class',
              lastActivity: new Date().toISOString(),
              timeoutStart: Math.random() > 0.9 ? new Date(Date.now() - 8 * 60 * 1000).toISOString() : null,
              timeoutDuration: 7 * 60 * 1000,
              alertsSent: false,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            
            students.push(student);
          }
        }
      }
    });

    return students;
  }

  // Generate demo attendance records for fallback
  private generateDemoAttendanceRecords(userId: string): AttendanceRecord[] {
    const records: AttendanceRecord[] = [];
    const today = new Date();
    const subjects = ['Mathematics', 'Physics', 'Chemistry', 'Computer Science', 'English'];
    
    // Generate 30 days of demo attendance
    for (let i = 30; i >= 1; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      
      // Skip weekends
      if (date.getDay() === 0 || date.getDay() === 6) continue;
      
      // 85% attendance rate for demo
      const isPresent = Math.random() > 0.15;
      const subject = subjects[Math.floor(Math.random() * subjects.length)];
      
      records.push({
        id: `demo:${date.getTime()}:${Math.random().toString(36).substr(2, 9)}`,
        userId: userId,
        userName: 'Demo User',
        userType: 'student',
        date: date.toISOString().split('T')[0],
        time: '09:00:00',
        status: isPresent ? 'present' : 'absent',
        method: 'cctv',
        markedBy: 'Demo System',
        className: 'CS-4A',
        subject: subject,
        location: 'Demo Campus',
        timestamp: date.toISOString()
      });
    }
    
    return records.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
}

export const supabaseService = new SupabaseAttendanceService();