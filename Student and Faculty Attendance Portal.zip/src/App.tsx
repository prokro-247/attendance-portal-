import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { InterfaceSelection } from "./components/interface-selection";
import { AuthForm } from "./components/auth-form";
import { DashboardLayout } from "./components/dashboard-layout";
import { Toaster } from "./components/ui/sonner";
import { supabaseService } from "./services/supabase-service";
import { toast } from "sonner@2.0.3";

type AppState = 'interface-selection' | 'auth' | 'dashboard';
type InterfaceType = 'student' | 'faculty' | 'hod' | 'principal';

export default function App() {
  const [appState, setAppState] = useState<AppState>('interface-selection');
  const [selectedInterface, setSelectedInterface] = useState<InterfaceType | null>(null);
  const [userData, setUserData] = useState<any>(null);
  const [demoInitialized, setDemoInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionChecked, setSessionChecked] = useState(false);

  // Check for existing sessions on app start
  useEffect(() => {
    const checkExistingSession = async () => {
      try {
        // Check all interface types for existing auto-login sessions
        const interfaceTypes: InterfaceType[] = ['student', 'faculty', 'hod', 'principal'];
        
        for (const interfaceType of interfaceTypes) {
          const autoLoginSetting = localStorage.getItem(`attendance_${interfaceType}_auto_login`);
          const savedCredentials = localStorage.getItem(`attendance_${interfaceType}_credentials`);
          
          if (autoLoginSetting === 'true' && savedCredentials) {
            try {
              const credentials = JSON.parse(savedCredentials);
              const result = await supabaseService.signIn(credentials.email, credentials.password);
              
              if (result.data && result.data.user && result.data.user.interfaceType === interfaceType) {
                setUserData(result.data.user);
                setSelectedInterface(interfaceType);
                setAppState('dashboard');
                toast.success(`Welcome back! Auto-signed in to ${interfaceType} portal.`);
                return; // Stop checking once we find a valid session
              }
            } catch (error) {
              // Clear invalid credentials
              localStorage.removeItem(`attendance_${interfaceType}_credentials`);
              localStorage.removeItem(`attendance_${interfaceType}_auto_login`);
            }
          }
        }
        
        // Check for regular Supabase session if no auto-login found
        const sessionResult = await supabaseService.getSession();
        if (sessionResult && 'session' in sessionResult && sessionResult.session) {
          try {
            const userProfile = await supabaseService.getUserProfile(sessionResult.session.user.id);
            if (userProfile.data) {
              setUserData(userProfile.data);
              setSelectedInterface(userProfile.data.interfaceType);
              setAppState('dashboard');
              toast.success("Session restored successfully!");
            }
          } catch (profileError) {
            console.warn('Failed to restore session:', profileError);
          }
        }
      } catch (error) {
        console.warn('Session check failed, starting fresh:', error);
      } finally {
        setSessionChecked(true);
      }
    };

    if (!sessionChecked) {
      checkExistingSession();
    }
  }, [sessionChecked]);

  // Initialize demo data on app start with timeout protection
  useEffect(() => {
    const initializeDemoData = async () => {
      if (!demoInitialized) {
        try {
          console.log('Initializing demo data...');
          
          // Create a timeout promise to prevent hanging
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Initialization timeout')), 3000);
          });

          // Race between initialization and timeout
          const initPromise = supabaseService.initializeDemoUsers();
          
          const result = await Promise.race([initPromise, timeoutPromise]);
          
          setDemoInitialized(true);
          if (result && typeof result === 'object' && 'data' in result && result.data && result.data.message) {
            console.log('Demo data initialization completed:', result.data.message);
          }
        } catch (error) {
          // Don't show timeout as an error since it's expected when backend is unavailable
          if (error.message === 'Initialization timeout' || error.message === 'Demo initialization timeout') {
            console.log('Backend services unavailable, continuing in offline mode');
          } else {
            console.warn('Demo data initialization failed, continuing in offline mode:', error);
          }
          
          // Continue anyway as the app should work without demo data
          setDemoInitialized(true);
          
          // Show a friendly notification about demo mode only once
          setTimeout(() => {
            toast.info("Welcome to Demo Mode", {
              description: "Exploring with sample data. All features are fully functional!"
            });
          }, 2000);
        }
      }
    };

    // Don't block the UI - run initialization in background
    initializeDemoData();
  }, [demoInitialized]);

  const handleInterfaceSelection = async (interfaceType: InterfaceType) => {
    try {
      setIsLoading(true);
      // Reduce delay for better responsiveness
      await new Promise(resolve => setTimeout(resolve, 150));
      setSelectedInterface(interfaceType);
      setAppState('auth');
    } catch (error) {
      console.error('Error selecting interface:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAuth = async (user: any) => {
    try {
      setIsLoading(true);
      // Reduce delay for better responsiveness
      await new Promise(resolve => setTimeout(resolve, 200));
      setUserData(user);
      setAppState('dashboard');
    } catch (error) {
      console.error('Error during authentication:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      setIsLoading(true);
      
      // Sign out from supabase if available
      try {
        await supabaseService.signOut();
      } catch (signOutError) {
        console.warn('Sign out failed, continuing with local logout:', signOutError);
      }
      
      // Clear all session data but preserve auto-login settings if enabled
      const interfaceTypes: InterfaceType[] = ['student', 'faculty', 'hod', 'principal'];
      interfaceTypes.forEach(interfaceType => {
        const autoLoginSetting = localStorage.getItem(`attendance_${interfaceType}_auto_login`);
        // Only clear auto-login data if auto-login is disabled
        if (autoLoginSetting !== 'true') {
          localStorage.removeItem(`attendance_${interfaceType}_credentials`);
          localStorage.removeItem(`attendance_${interfaceType}_auto_login`);
        }
      });
      
      await new Promise(resolve => setTimeout(resolve, 150));
      setUserData(null);
      setSelectedInterface(null);
      setAppState('interface-selection');
      setSessionChecked(false); // Reset session check for fresh start
      
      toast.success("Logged out successfully");
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = async () => {
    try {
      if (appState === 'auth') {
        setIsLoading(true);
        await new Promise(resolve => setTimeout(resolve, 150));
        setAppState('interface-selection');
        setSelectedInterface(null);
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Error going back:', error);
      setIsLoading(false);
    }
  };

  // Simplified page transition variants for better performance
  const pageVariants = {
    initial: { 
      opacity: 0, 
      y: 10
    },
    in: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    },
    out: { 
      opacity: 0, 
      y: -10,
      transition: {
        duration: 0.2,
        ease: "easeIn"
      }
    }
  };

  // Loading overlay variants
  const loadingVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { duration: 0.15 }
    },
    exit: {
      opacity: 0,
      transition: { duration: 0.15 }
    }
  };

  return (
    <div className="min-h-screen bg-background relative">
      {/* Show loading while checking session */}
      {!sessionChecked ? (
        <div className="min-h-screen bg-background flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"
            />
            <h2 className="text-xl font-semibold mb-2">Initializing System</h2>
            <p className="text-muted-foreground">Checking for existing sessions...</p>
          </motion.div>
        </div>
      ) : (
        <AnimatePresence mode="wait">
          {appState === 'interface-selection' && (
            <motion.div
              key="interface-selection"
              variants={pageVariants}
              initial="initial"
              animate="in"
              exit="out"
              className="w-full h-full"
            >
              <InterfaceSelection onSelectInterface={handleInterfaceSelection} />
            </motion.div>
          )}
          
          {appState === 'auth' && selectedInterface && (
            <motion.div
              key="auth"
              variants={pageVariants}
              initial="initial"
              animate="in"
              exit="out"
              className="w-full h-full"
            >
              <AuthForm 
                interfaceType={selectedInterface}
                onBack={handleBack}
                onAuth={handleAuth}
              />
            </motion.div>
          )}
          
          {appState === 'dashboard' && userData && (
            <motion.div
              key="dashboard"
              variants={pageVariants}
              initial="initial"
              animate="in"
              exit="out"
              className="w-full h-full"
            >
              <DashboardLayout 
                userData={userData}
                onLogout={handleLogout}
              />
            </motion.div>
          )}
        </AnimatePresence>
      )}

      {/* Loading Overlay */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            variants={loadingVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 flex items-center justify-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full"
            />
          </motion.div>
        )}
      </AnimatePresence>
      
      <Toaster />
    </div>
  );
}