import { Users, GraduationCap, User, Crown } from "lucide-react";
import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";

interface InterfaceSelectionProps {
  onSelectInterface: (interfaceType: 'student' | 'faculty' | 'hod' | 'principal') => void;
}

export function InterfaceSelection({ onSelectInterface }: InterfaceSelectionProps) {
  const interfaces = [
    {
      id: 'student' as const,
      title: 'Student Portal',
      description: 'View attendance, percentage, and records',
      icon: GraduationCap,
      color: 'bg-blue-500',
    },
    {
      id: 'faculty' as const,
      title: 'Faculty Portal',
      description: 'Manage class attendance and view student records',
      icon: User,
      color: 'bg-green-500',
    },
    {
      id: 'hod' as const,
      title: 'HOD Portal',
      description: 'Monitor faculty and department attendance',
      icon: Users,
      color: 'bg-orange-500',
    },
    {
      id: 'principal' as const,
      title: 'Principal Portal',
      description: 'Overview of all departments and analytics',
      icon: Crown,
      color: 'bg-purple-500',
    },
  ];

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 20,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  };

  const iconVariants = {
    initial: { scale: 1, rotate: 0 },
    hover: { 
      scale: 1.1, 
      rotate: 5,
      transition: {
        duration: 0.2,
        ease: "easeInOut"
      }
    }
  };

  const titleVariants = {
    hidden: { opacity: 0, y: -10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        delay: 0.3,
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <motion.div 
          className="text-center mb-8"
          variants={titleVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.h1 
            className="mb-2"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            Smart Attendance Management System
          </motion.h1>
          <motion.p 
            className="text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            Select your portal to continue
          </motion.p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {interfaces.map((interface_) => {
            const Icon = interface_.icon;
            return (
              <motion.div
                key={interface_.id}
                variants={cardVariants}
                whileHover={{ 
                  y: -5,
                  transition: { duration: 0.2 }
                }}
                whileTap={{ scale: 0.95 }}
              >
                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden group"
                  onClick={() => onSelectInterface(interface_.id)}
                >
                  <CardHeader className="text-center">
                    <motion.div 
                      className={`${interface_.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:shadow-lg transition-shadow`}
                      variants={iconVariants}
                      initial="initial"
                      whileHover="hover"
                    >
                      <Icon className="w-8 h-8 text-white" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      <CardTitle className="group-hover:text-primary transition-colors">
                        {interface_.title}
                      </CardTitle>
                      <CardDescription>{interface_.description}</CardDescription>
                    </motion.div>
                  </CardHeader>
                  <CardContent>
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors" variant="outline">
                        Enter Portal
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </div>
  );
}