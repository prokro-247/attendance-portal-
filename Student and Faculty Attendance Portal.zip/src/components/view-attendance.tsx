import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { Calendar, Clock, Eye, Download, Filter } from "lucide-react";
import { supabaseService, AttendanceRecord } from "../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface ViewAttendanceProps {
  userData: any;
  userType?: 'faculty' | 'hod' | 'principal' | 'student';
}

export function ViewAttendance({ userData, userType = 'student' }: ViewAttendanceProps) {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterSubject, setFilterSubject] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterMonth, setFilterMonth] = useState("all");
  const [filterClass, setFilterClass] = useState("all");

  useEffect(() => {
    loadAttendanceRecords();
  }, []);

  useEffect(() => {
    filterRecords();
  }, [attendanceRecords, filterSubject, filterStatus, filterMonth, filterClass]);

  const loadAttendanceRecords = async () => {
    try {
      setIsLoading(true);
      
      // Load demo data for now since backend may not be available
      const demoRecords: AttendanceRecord[] = [
        {
          id: '1',
          date: '2024-01-15',
          time: '09:30 AM',
          subject: 'Data Structures',
          className: 'CSE-4A',
          status: 'present',
          method: 'cctv',
          markedBy: 'Dr. Priya Singh',
          userId: userData.id,
          userName: userType === 'student' ? userData.fullName : 'Aarav Sharma'
        },
        {
          id: '2',
          date: '2024-01-16',
          time: '11:00 AM',
          subject: 'Algorithms',
          className: 'CSE-4A',
          status: 'present',
          method: 'manual',
          markedBy: 'Dr. Rajesh Kumar',
          userId: userData.id,
          userName: userType === 'student' ? userData.fullName : 'Aditi Verma'
        },
        {
          id: '3',
          date: '2024-01-17',
          time: '02:00 PM',
          subject: 'Database Management',
          className: 'CSE-4B',
          status: 'absent',
          method: 'cctv',
          markedBy: 'Dr. Priya Singh',
          userId: userData.id,
          userName: userType === 'student' ? userData.fullName : 'Arjun Gupta'
        },
        {
          id: '4',
          date: '2024-01-18',
          time: '10:30 AM',
          subject: 'Operating Systems',
          className: 'CSE-4A',
          status: 'present',
          method: 'manual',
          markedBy: 'Dr. Sunita Agarwal',
          userId: userData.id,
          userName: userType === 'student' ? userData.fullName : 'Kavya Patel'
        }
      ];
      
      setAttendanceRecords(demoRecords);
    } catch (error) {
      console.error('Error loading attendance records:', error);
      toast.error('Failed to load attendance records');
    } finally {
      setIsLoading(false);
    }
  };

  const filterRecords = () => {
    let filtered = [...attendanceRecords];

    if (filterSubject !== "all") {
      filtered = filtered.filter(record => record.subject === filterSubject);
    }

    if (filterStatus !== "all") {
      filtered = filtered.filter(record => record.status === filterStatus);
    }

    if (filterMonth !== "all") {
      const targetMonth = parseInt(filterMonth);
      filtered = filtered.filter(record => {
        const recordMonth = new Date(record.date).getMonth() + 1;
        return recordMonth === targetMonth;
      });
    }

    if (filterClass !== "all") {
      filtered = filtered.filter(record => record.className === filterClass);
    }

    setFilteredRecords(filtered);
  };

  const exportAttendance = () => {
    const csvContent = [
      ['Date', 'Time', 'Subject', 'Class', 'Status', 'Method', 'Marked By'],
      ...filteredRecords.map(record => [
        record.date,
        record.time,
        record.subject,
        record.className,
        record.status,
        record.method,
        record.markedBy
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `my_attendance_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success("Attendance data exported successfully");
  };

  const getStatusBadge = (status: string) => {
    return (
      <Badge variant={status === 'present' ? 'default' : 'destructive'}>
        {status === 'present' ? 'Present' : 'Absent'}
      </Badge>
    );
  };

  const getMethodBadge = (method: string) => {
    return (
      <Badge variant={method === 'cctv' ? 'secondary' : 'outline'}>
        {method === 'cctv' ? 'CCTV' : 'Manual'}
      </Badge>
    );
  };

  // Get unique subjects, months, and classes for filters
  const subjects = [...new Set(attendanceRecords.map(record => record.subject))];
  const months = [...new Set(attendanceRecords.map(record => {
    const date = new Date(record.date);
    return { value: date.getMonth() + 1, name: date.toLocaleDateString('en-US', { month: 'long' }) };
  }))];
  const classes = [...new Set(attendanceRecords.map(record => record.className))];

  // Calculate statistics
  const totalRecords = filteredRecords.length;
  const presentCount = filteredRecords.filter(record => record.status === 'present').length;
  const absentCount = totalRecords - presentCount;
  const attendancePercentage = totalRecords > 0 ? Math.round((presentCount / totalRecords) * 100) : 0;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Loading attendance records...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            {userType === 'student' ? 'My Attendance Records' : 'Class Attendance Records'}
          </CardTitle>
          <CardDescription>
            {userType === 'student' 
              ? 'View and track your attendance across all subjects'
              : 'View attendance records for your classes and students'
            }
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{totalRecords}</div>
              <div className="text-sm text-blue-800">Total Classes</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{presentCount}</div>
              <div className="text-sm text-green-800">Present</div>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{absentCount}</div>
              <div className="text-sm text-red-800">Absent</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{attendancePercentage}%</div>
              <div className="text-sm text-purple-800">Attendance Rate</div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex gap-2 items-center flex-wrap">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              
              <Select value={filterSubject} onValueChange={setFilterSubject}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {subjects.map(subject => (
                    <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="present">Present</SelectItem>
                  <SelectItem value="absent">Absent</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterMonth} onValueChange={setFilterMonth}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Month" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Months</SelectItem>
                  {months.map(month => (
                    <SelectItem key={month.value} value={month.value.toString()}>
                      {month.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterClass} onValueChange={setFilterClass}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {classes.map(cls => (
                    <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={exportAttendance} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export Records
            </Button>
          </div>

          {/* Attendance Records Table */}
          {filteredRecords.length > 0 ? (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Time</TableHead>
                    {userType !== 'student' && <TableHead>Student</TableHead>}
                    {userType !== 'student' && <TableHead>Roll No.</TableHead>}
                    <TableHead>Subject</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Marked By</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-500" />
                          {new Date(record.date).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-500" />
                          {record.time}
                        </div>
                      </TableCell>
                      {userType !== 'student' && <TableCell className="font-medium">{record.userName}</TableCell>}
                      {userType !== 'student' && <TableCell>{record.userId?.split(':')[1] || 'N/A'}</TableCell>}
                      <TableCell className="font-medium">{record.subject}</TableCell>
                      <TableCell>{record.className}</TableCell>
                      <TableCell>{getStatusBadge(record.status)}</TableCell>
                      <TableCell>{getMethodBadge(record.method)}</TableCell>
                      <TableCell className="text-sm text-gray-600">{record.markedBy}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Eye className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No attendance records found.</p>
              <p className="text-sm">
                {attendanceRecords.length === 0 
                  ? "Your attendance will appear here once classes begin."
                  : "Try adjusting the filters to see more records."
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}