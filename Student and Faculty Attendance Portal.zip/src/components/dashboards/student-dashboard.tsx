import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Progress } from "../ui/progress";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Calendar, TrendingUp, Clock, User, CheckCircle, XCircle, RefreshCw } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { supabaseService, AttendanceData, AttendanceRecord } from "../../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface StudentDashboardProps {
  userData: any;
}

interface EnhancedAttendanceData extends AttendanceData {
  subjectWise: Array<{
    subject: string;
    attended: number;
    total: number;
    percentage: number;
  }>;
  monthlyData: Array<{
    month: string;
    attendance: number;
  }>;
  totalClasses: number;
  classesAttended: number;
}

export function StudentDashboard({ userData }: StudentDashboardProps) {
  const [attendanceData, setAttendanceData] = useState<EnhancedAttendanceData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasMarkedToday, setHasMarkedToday] = useState(false);

  // Load attendance data
  useEffect(() => {
    loadAttendanceData();
  }, [userData]);

  const loadAttendanceData = async () => {
    try {
      setIsLoading(true);
      const userId = userData.id || userData.email || 'current-student';
      
      // Get attendance records from Supabase
      const result = await supabaseService.getAttendanceRecords(userId);
      
      if (result.error) {
        console.error('Error fetching attendance:', result.error);
        toast.error('Failed to load attendance data');
        setIsLoading(false);
        return;
      }

      // Calculate attendance data from records
      const attendanceStats = supabaseService.calculateAttendanceData(result.data || []);
      
      // If no data exists, create some demo data
      if (attendanceStats.totalDays === 0) {
        // Create some sample attendance records for demo purposes
        const demoAttendance = {
          totalDays: 45,
          presentDays: 38,
          absentDays: 7,
          percentage: 84,
          recentRecords: []
        };
        
        const enhancedData: EnhancedAttendanceData = {
          ...demoAttendance,
          subjectWise: [
            { subject: 'Mathematics', attended: 12, total: 15, percentage: 80 },
            { subject: 'Physics', attended: 10, total: 12, percentage: 83 },
            { subject: 'Chemistry', attended: 9, total: 10, percentage: 90 },
            { subject: 'Computer Science', attended: 7, total: 8, percentage: 88 }
          ],
          monthlyData: [
            { month: 'Jan', attendance: 85 },
            { month: 'Feb', attendance: 82 },
            { month: 'Mar', attendance: 87 },
            { month: 'Apr', attendance: 81 },
            { month: 'May', attendance: 86 },
            { month: 'Jun', attendance: 84 }
          ],
          totalClasses: 45,
          classesAttended: 38
        };
        
        setAttendanceData(enhancedData);
        setHasMarkedToday(false);
      } else {
        // Add mock subject-wise and monthly data for visualization
        const enhancedData: EnhancedAttendanceData = {
          ...attendanceStats,
          subjectWise: [
            { subject: 'Mathematics', attended: Math.floor(attendanceStats.presentDays * 0.3), total: Math.floor(attendanceStats.totalDays * 0.3), percentage: Math.round((Math.floor(attendanceStats.presentDays * 0.3) / Math.max(1, Math.floor(attendanceStats.totalDays * 0.3))) * 100) },
            { subject: 'Physics', attended: Math.floor(attendanceStats.presentDays * 0.25), total: Math.floor(attendanceStats.totalDays * 0.25), percentage: Math.round((Math.floor(attendanceStats.presentDays * 0.25) / Math.max(1, Math.floor(attendanceStats.totalDays * 0.25))) * 100) },
            { subject: 'Chemistry', attended: Math.floor(attendanceStats.presentDays * 0.25), total: Math.floor(attendanceStats.totalDays * 0.25), percentage: Math.round((Math.floor(attendanceStats.presentDays * 0.25) / Math.max(1, Math.floor(attendanceStats.totalDays * 0.25))) * 100) },
            { subject: 'Computer Science', attended: Math.floor(attendanceStats.presentDays * 0.2), total: Math.floor(attendanceStats.totalDays * 0.2), percentage: Math.round((Math.floor(attendanceStats.presentDays * 0.2) / Math.max(1, Math.floor(attendanceStats.totalDays * 0.2))) * 100) }
          ],
          monthlyData: [
            { month: 'Jan', attendance: Math.max(60, attendanceStats.percentage - 10) },
            { month: 'Feb', attendance: Math.max(60, attendanceStats.percentage - 5) },
            { month: 'Mar', attendance: Math.max(60, attendanceStats.percentage + 5) },
            { month: 'Apr', attendance: Math.max(60, attendanceStats.percentage - 2) },
            { month: 'May', attendance: Math.max(60, attendanceStats.percentage + 3) },
            { month: 'Jun', attendance: attendanceStats.percentage }
          ],
          totalClasses: attendanceStats.totalDays,
          classesAttended: attendanceStats.presentDays
        };
        
        setAttendanceData(enhancedData);
        
        // Check if marked today
        const markedToday = supabaseService.hasMarkedToday(result.data || []);
        setHasMarkedToday(markedToday);
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading attendance data:', error);
      setIsLoading(false);
      toast.error('Failed to load attendance data');
    }
  };

  if (isLoading || !attendanceData) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center space-y-4">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto text-primary" />
            <p>Loading your attendance data...</p>
          </div>
        </div>
      </div>
    );
  }

  const pieData = [
    { name: 'Present', value: attendanceData.presentDays, fill: '#22c55e' },
    { name: 'Absent', value: attendanceData.absentDays, fill: '#ef4444' },
  ];

  const getAttendanceStatus = (percentage: number) => {
    if (percentage >= 90) return { status: 'Excellent', color: 'bg-green-500' };
    if (percentage >= 80) return { status: 'Good', color: 'bg-yellow-500' };
    if (percentage >= 75) return { status: 'Warning', color: 'bg-orange-500' };
    return { status: 'Critical', color: 'bg-red-500' };
  };

  const status = getAttendanceStatus(attendanceData.percentage);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Student Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {userData.fullName}</p>
        </div>
        <div className="flex items-center gap-4">
          {hasMarkedToday && (
            <Badge className="bg-green-100 text-green-800 border-green-300">
              <CheckCircle className="w-3 h-3 mr-1" />
              Marked Today
            </Badge>
          )}
          {!hasMarkedToday && (
            <Badge className="bg-orange-100 text-orange-800 border-orange-300">
              <XCircle className="w-3 h-3 mr-1" />
              Not Marked Today
            </Badge>
          )}
          <Badge className={`${status.color} text-white`}>
            {status.status} - {attendanceData.percentage}%
          </Badge>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Classes</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.totalClasses}</div>
            <p className="text-xs text-muted-foreground">This semester</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Classes Attended</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{attendanceData.classesAttended}</div>
            <p className="text-xs text-muted-foreground">Out of {attendanceData.totalClasses}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Absents</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{attendanceData.absentDays}</div>
            <p className="text-xs text-muted-foreground">Classes missed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceData.percentage}%</div>
            <Progress value={attendanceData.percentage} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Attendance Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Attendance Trend</CardTitle>
            <CardDescription>Your attendance percentage over the past 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={attendanceData.monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="attendance" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Attendance Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Distribution</CardTitle>
            <CardDescription>Overview of your present vs absent days</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Subject-wise Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Subject-wise Attendance</CardTitle>
          <CardDescription>Your attendance breakdown by subject</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {attendanceData.subjectWise.map((subject, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4>{subject.subject}</h4>
                    <Badge 
                      variant={subject.percentage >= 80 ? 'default' : 'destructive'}
                      className={subject.percentage >= 80 ? 'bg-green-600' : ''}
                    >
                      {subject.percentage}%
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>Attended: {subject.attended}/{subject.total}</span>
                    <span>Missed: {subject.total - subject.attended}</span>
                  </div>
                  <Progress value={subject.percentage} className="mt-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}