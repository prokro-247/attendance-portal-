import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Users, TrendingUp, AlertTriangle, GraduationCap } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface HodDashboardProps {
  userData: any;
}

export function HodDashboard({ userData }: HodDashboardProps) {
  // Mock HOD data
  const hodData = {
    myAttendance: {
      totalDays: 180,
      daysAttended: 175,
      percentage: 97.2
    },
    departmentOverview: {
      totalFaculty: 15,
      totalStudents: 240,
      averageFacultyAttendance: 94.5,
      averageStudentAttendance: 85.2
    },
    facultyAttendance: [
      { name: 'Dr. John Smith', employeeId: 'FAC001', percentage: 96.5, department: 'Computer Science' },
      { name: 'Prof. Sarah Johnson', employeeId: 'FAC002', percentage: 94.2, department: 'Computer Science' },
      { name: 'Dr. Mike Wilson', employeeId: 'FAC003', percentage: 98.1, department: 'Computer Science' },
      { name: 'Prof. Emily Davis', employeeId: 'FAC004', percentage: 92.3, department: 'Computer Science' },
      { name: 'Dr. Robert Brown', employeeId: 'FAC005', percentage: 89.7, department: 'Computer Science' },
      { name: 'Prof. Lisa Garcia', employeeId: 'FAC006', percentage: 95.8, department: 'Computer Science' },
      { name: 'Dr. David Miller', employeeId: 'FAC007', percentage: 93.4, department: 'Computer Science' },
      { name: 'Prof. Anna Martinez', employeeId: 'FAC008', percentage: 96.9, department: 'Computer Science' },
    ],
    classAttendance: [
      { class: 'CSE-A 1st Year', students: 45, avgAttendance: 87, lowAttendance: 8 },
      { class: 'CSE-B 1st Year', students: 42, avgAttendance: 89, lowAttendance: 6 },
      { class: 'CSE-A 2nd Year', students: 38, avgAttendance: 85, lowAttendance: 9 },
      { class: 'CSE-B 2nd Year', students: 40, avgAttendance: 91, lowAttendance: 4 },
      { class: 'CSE-A 3rd Year', students: 35, avgAttendance: 83, lowAttendance: 12 },
      { class: 'CSE-B 3rd Year', students: 40, avgAttendance: 86, lowAttendance: 7 },
    ],
    monthlyTrend: [
      { month: 'Jan', faculty: 95, students: 86 },
      { month: 'Feb', faculty: 94, students: 84 },
      { month: 'Mar', faculty: 96, students: 87 },
      { month: 'Apr', faculty: 93, students: 83 },
      { month: 'May', faculty: 95, students: 85 },
      { month: 'Jun', faculty: 94, students: 85 },
    ]
  };

  const attendanceDistribution = [
    { name: '90-100%', value: 12, fill: '#22c55e' },
    { name: '80-89%', value: 2, fill: '#eab308' },
    { name: '75-79%', value: 1, fill: '#f97316' },
    { name: 'Below 75%', value: 0, fill: '#ef4444' },
  ];

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 90) return 'text-green-600 bg-green-50';
    if (percentage >= 80) return 'text-yellow-600 bg-yellow-50';
    if (percentage >= 75) return 'text-orange-600 bg-orange-50';
    return 'text-red-600 bg-red-50';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>HOD Dashboard</h1>
          <p className="text-muted-foreground">Department of Computer Science - {userData.fullName}</p>
        </div>
        <Badge className="bg-blue-600 text-white">
          Department Head
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="faculty">Faculty Attendance</TabsTrigger>
          <TabsTrigger value="classes">Class Performance</TabsTrigger>
          <TabsTrigger value="personal">My Attendance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Department Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Faculty</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hodData.departmentOverview.totalFaculty}</div>
                <p className="text-xs text-muted-foreground">In CS Department</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                <GraduationCap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hodData.departmentOverview.totalStudents}</div>
                <p className="text-xs text-muted-foreground">Across all years</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Faculty Avg</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {hodData.departmentOverview.averageFacultyAttendance}%
                </div>
                <p className="text-xs text-muted-foreground">Faculty attendance</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Student Avg</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {hodData.departmentOverview.averageStudentAttendance}%
                </div>
                <p className="text-xs text-muted-foreground">Student attendance</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Monthly Attendance Trend */}
            <Card>
              <CardHeader>
                <CardTitle>Department Attendance Trend</CardTitle>
                <CardDescription>Monthly attendance comparison between faculty and students</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={hodData.monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="faculty" fill="#3b82f6" name="Faculty" />
                    <Bar dataKey="students" fill="#10b981" name="Students" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Faculty Attendance Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Faculty Attendance Distribution</CardTitle>
                <CardDescription>Distribution of faculty by attendance percentage</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={attendanceDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {attendanceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="faculty" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Faculty Attendance Overview</CardTitle>
              <CardDescription>Attendance records for all faculty members in the department</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {hodData.facultyAttendance.map((faculty, index) => (
                  <div key={index} className={`p-4 rounded-lg border ${getAttendanceColor(faculty.percentage)}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4>{faculty.name}</h4>
                          <Badge variant="outline">{faculty.employeeId}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{faculty.department}</p>
                        <Progress value={faculty.percentage} className="mt-2" />
                      </div>
                      <Badge className={`ml-4 ${faculty.percentage >= 90 ? 'bg-green-600' : faculty.percentage >= 80 ? 'bg-yellow-600' : 'bg-red-600'}`}>
                        {faculty.percentage}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="classes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Class-wise Attendance Performance</CardTitle>
              <CardDescription>Overview of attendance across different classes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {hodData.classAttendance.map((classData, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4>{classData.class}</h4>
                        <p className="text-sm text-muted-foreground">
                          {classData.students} students
                        </p>
                      </div>
                      <Badge className={`${classData.avgAttendance >= 85 ? 'bg-green-600' : classData.avgAttendance >= 75 ? 'bg-yellow-600' : 'bg-red-600'}`}>
                        {classData.avgAttendance}% Avg
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                      <div className="text-center">
                        <div className="font-semibold">{classData.students}</div>
                        <p className="text-xs text-muted-foreground">Total Students</p>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-green-600">{classData.avgAttendance}%</div>
                        <p className="text-xs text-muted-foreground">Average Attendance</p>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-red-600">{classData.lowAttendance}</div>
                        <p className="text-xs text-muted-foreground">Low Attendance ({`<75%`})</p>
                      </div>
                    </div>
                    
                    <Progress value={classData.avgAttendance} />
                    
                    {classData.lowAttendance > 0 && (
                      <div className="flex items-center gap-2 mt-2">
                        <AlertTriangle className="w-4 h-4 text-red-500" />
                        <span className="text-sm text-red-600">
                          {classData.lowAttendance} students need attention
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="personal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>My Personal Attendance</CardTitle>
              <CardDescription>Your attendance record as HOD</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold">{hodData.myAttendance.totalDays}</div>
                  <p className="text-sm text-muted-foreground">Total Working Days</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{hodData.myAttendance.daysAttended}</div>
                  <p className="text-sm text-muted-foreground">Days Present</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">
                    {hodData.myAttendance.totalDays - hodData.myAttendance.daysAttended}
                  </div>
                  <p className="text-sm text-muted-foreground">Days Absent</p>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span>Attendance Percentage</span>
                  <span className="font-medium text-green-600">{hodData.myAttendance.percentage}%</span>
                </div>
                <Progress value={hodData.myAttendance.percentage} />
              </div>
              
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <Badge className="bg-green-600 mb-2">Outstanding Performance</Badge>
                <p className="text-sm text-green-800">
                  Your attendance sets an excellent example for the department!
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}