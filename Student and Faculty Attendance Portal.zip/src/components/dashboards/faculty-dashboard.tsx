import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Users, AlertTriangle, TrendingUp, Calendar, Camera, FileText, Eye, Download, Settings } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { CameraAttendance } from "../camera-attendance";
import { MarkAttendance } from "../mark-attendance";
import { ViewAttendance } from "../view-attendance";
import { AdministrationPanel } from "../administration-panel";

interface FacultyDashboardProps {
  userData: any;
}

export function FacultyDashboard({ userData }: FacultyDashboardProps) {
  const [showCamera, setShowCamera] = useState(false);
  const [showManualAttendance, setShowManualAttendance] = useState(false);
  const [showViewRecords, setShowViewRecords] = useState(false);
  const [showAdministration, setShowAdministration] = useState(false);
  
  // Mock faculty data with Indian names
  const facultyData = {
    myAttendance: {
      totalDays: 180,
      daysAttended: 172,
      percentage: 95.6
    },
    classes: [
      {
        id: 1,
        name: 'CSE-A 3rd Year',
        subject: 'Data Structures',
        totalStudents: 60,
        averageAttendance: 87,
        lowAttendanceStudents: 12
      },
      {
        id: 2,
        name: 'CSE-B 3rd Year', 
        subject: 'Algorithms',
        totalStudents: 60,
        averageAttendance: 92,
        lowAttendanceStudents: 8
      },
      {
        id: 3,
        name: 'CSE-C 3rd Year', 
        subject: 'Database Systems',
        totalStudents: 60,
        averageAttendance: 89,
        lowAttendanceStudents: 10
      }
    ],
    lowAttendanceStudents: [
      { name: 'Arjun Sharma', rollNumber: 'CSE001', percentage: 68, absents: 12 },
      { name: 'Priya Singh', rollNumber: 'CSE002', percentage: 72, absents: 10 },
      { name: 'Rahul Gupta', rollNumber: 'CSE003', percentage: 65, absents: 15 },
      { name: 'Kavya Patel', rollNumber: 'CSE004', percentage: 70, absents: 11 },
      { name: 'Aditya Kumar', rollNumber: 'CSE005', percentage: 74, absents: 9 },
      { name: 'Deepika Sharma', rollNumber: 'CSE006', percentage: 69, absents: 13 },
      { name: 'Ravi Verma', rollNumber: 'CSE007', percentage: 71, absents: 12 },
      { name: 'Nisha Gupta', rollNumber: 'CSE008', percentage: 67, absents: 14 },
      { name: 'Manish Singh', rollNumber: 'CSE009', percentage: 73, absents: 10 },
      { name: 'Anjali Jain', rollNumber: 'CSE010', percentage: 68, absents: 13 }
    ],
    attendanceTrend: [
      { month: 'Jan', classA: 85, classB: 90, classC: 87 },
      { month: 'Feb', classA: 87, classB: 88, classC: 89 },
      { month: 'Mar', classA: 89, classB: 92, classC: 91 },
      { month: 'Apr', classA: 86, classB: 91, classC: 90 },
      { month: 'May', classA: 87, classB: 92, classC: 89 },
      { month: 'Jun', classA: 88, classB: 94, classC: 92 },
    ]
  };

  const handleMarkAttendance = async (detectedUsers: string[]) => {
    try {
      const { supabaseService } = await import('../../services/supabase-service');
      const { toast } = await import('sonner@2.0.3');
      
      // Convert detected users to user objects
      const attendanceRecords = detectedUsers.map((user: string, index: number) => ({
        userId: `student-${index + 1}`,
        userName: user.replace(/\s*\([^)]*\)/, ''), // Remove roll number from display name
        userType: 'student' as const,
        status: 'present' as const
      }));
      
      const result = await supabaseService.markBulkAttendance({
        attendanceRecords,
        markedBy: userData.fullName,
        className: 'CS-4A',
        subject: 'Current Class'
      });
      
      if (result.error) {
        toast.error('Failed to mark attendance');
        return;
      }
      
      console.log('Faculty marked attendance:', result.data);
      toast.success(`Attendance marked for ${result.data.length} students!`, {
        description: `Marked at ${new Date().toLocaleTimeString()}`,
      });
      
      setShowCamera(false);
    } catch (error) {
      console.error('Error marking attendance:', error);
      const { toast } = await import('sonner@2.0.3');
      toast.error('Failed to mark attendance. Please try again.');
    }
  };

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 85) return 'text-green-600';
    if (percentage >= 75) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (showCamera) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1>Mark Class Attendance</h1>
          <Button variant="outline" onClick={() => setShowCamera(false)}>
            Back to Dashboard
          </Button>
        </div>
        <CameraAttendance onMarkAttendance={handleMarkAttendance} userType="faculty" />
      </div>
    );
  }

  if (showManualAttendance) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1>Mark Class Attendance Manually</h1>
          <Button variant="outline" onClick={() => setShowManualAttendance(false)}>
            Back to Dashboard
          </Button>
        </div>
        <MarkAttendance userData={userData} userType="faculty" />
      </div>
    );
  }

  if (showViewRecords) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1>View Attendance Records</h1>
          <Button variant="outline" onClick={() => setShowViewRecords(false)}>
            Back to Dashboard
          </Button>
        </div>
        <ViewAttendance userData={userData} userType="faculty" />
      </div>
    );
  }

  if (showAdministration) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1>Administration Panel</h1>
          <Button variant="outline" onClick={() => setShowAdministration(false)}>
            Back to Dashboard
          </Button>
        </div>
        <AdministrationPanel userData={userData} />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Faculty Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, Prof. {userData.fullName}</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowCamera(true)} className="flex items-center gap-2">
            <Camera className="w-4 h-4" />
            CCTV Mark
          </Button>
          <Button onClick={() => setShowManualAttendance(true)} variant="outline" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Manual Mark
          </Button>
          <Button onClick={() => setShowViewRecords(true)} variant="outline" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            View Records
          </Button>
          <Button onClick={() => setShowAdministration(true)} variant="outline" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Administration
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="classes">My Classes</TabsTrigger>
          <TabsTrigger value="students">Low Attendance Students</TabsTrigger>
          <TabsTrigger value="attendance">My Attendance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Classes</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{facultyData.classes.length}</div>
                <p className="text-xs text-muted-foreground">Classes assigned</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {facultyData.classes.reduce((total, cls) => total + cls.totalStudents, 0)}
                </div>
                <p className="text-xs text-muted-foreground">Under your supervision</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Low Attendance</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  {facultyData.lowAttendanceStudents.length}
                </div>
                <p className="text-xs text-muted-foreground">Students below 75%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">My Attendance</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {facultyData.myAttendance.percentage}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {facultyData.myAttendance.daysAttended}/{facultyData.myAttendance.totalDays} days
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Attendance Trend Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Class Attendance Trend</CardTitle>
              <CardDescription>Monthly attendance percentage for your classes</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={facultyData.attendanceTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="classA" stroke="#3b82f6" name="CSE-A 3rd Year" />
                  <Line type="monotone" dataKey="classB" stroke="#10b981" name="CSE-B 3rd Year" />
                  <Line type="monotone" dataKey="classC" stroke="#f6c106" name="CSE-C 3rd Year" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="classes" className="space-y-4">
          <div className="grid gap-4">
            {facultyData.classes.map((classInfo) => (
              <Card key={classInfo.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{classInfo.name}</CardTitle>
                      <CardDescription>{classInfo.subject}</CardDescription>
                    </div>
                    <Badge className={`${getAttendanceColor(classInfo.averageAttendance)} bg-transparent border`}>
                      {classInfo.averageAttendance}% Average
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{classInfo.totalStudents}</div>
                      <p className="text-sm text-muted-foreground">Total Students</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{classInfo.averageAttendance}%</div>
                      <p className="text-sm text-muted-foreground">Average Attendance</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{classInfo.lowAttendanceStudents}</div>
                      <p className="text-sm text-muted-foreground">Low Attendance</p>
                    </div>
                  </div>
                  <Progress value={classInfo.averageAttendance} className="mt-4" />
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="students" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                Students with Low Attendance ({`<75%`})
              </CardTitle>
              <CardDescription>
                Students who need attention regarding their attendance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {facultyData.lowAttendanceStudents.map((student, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4>{student.name}</h4>
                        <Badge variant="outline">{student.rollNumber}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Attendance: {student.percentage}%</span>
                        <span>Total Absents: {student.absents}</span>
                      </div>
                      <Progress value={student.percentage} className="mt-2" />
                    </div>
                    <Badge variant="destructive" className="ml-4">
                      {student.percentage}%
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>My Attendance Record</CardTitle>
              <CardDescription>Your personal attendance statistics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold">{facultyData.myAttendance.totalDays}</div>
                  <p className="text-sm text-muted-foreground">Total Working Days</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{facultyData.myAttendance.daysAttended}</div>
                  <p className="text-sm text-muted-foreground">Days Present</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">
                    {facultyData.myAttendance.totalDays - facultyData.myAttendance.daysAttended}
                  </div>
                  <p className="text-sm text-muted-foreground">Days Absent</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span>Attendance Percentage</span>
                  <span className="font-medium">{facultyData.myAttendance.percentage}%</span>
                </div>
                <Progress value={facultyData.myAttendance.percentage} />
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <Badge className="bg-green-600">Excellent Attendance</Badge>
                <p className="text-sm text-green-800 mt-2">
                  You have maintained excellent attendance throughout the semester!
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}