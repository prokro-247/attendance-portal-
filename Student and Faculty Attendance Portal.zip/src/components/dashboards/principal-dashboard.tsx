import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Building, Users, GraduationCap, TrendingUp, AlertTriangle, Award, FileText, Database, Download, Upload, Clock, Timer, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { toast } from "sonner@2.0.3";
import { supabaseService } from "../../services/supabase-service";
import { localDemoService } from "../../services/local-demo-service";

interface PrincipalDashboardProps {
  userData: any;
}

export function PrincipalDashboard({ userData }: PrincipalDashboardProps) {
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [timeoutStudents, setTimeoutStudents] = useState([]);
  const [showTimeoutManagement, setShowTimeoutManagement] = useState(false);
  
  // Mock Principal data with Indian names - comprehensive overview
  const principalData = {
    instituteOverview: {
      totalDepartments: 12,
      totalFaculty: 185,
      totalStudents: 4800,
      totalHODs: 12,
      overallAttendance: 86.4
    },
    departmentWise: [
      { department: 'Computer Science', students: 540, faculty: 24, hod: 'Dr. Rajesh Kumar', avgStudentAttendance: 85.2, avgFacultyAttendance: 94.5 },
      { department: 'Computer Science & ML', students: 360, faculty: 18, hod: 'Dr. Priya Singh', avgStudentAttendance: 87.8, avgFacultyAttendance: 93.2 },
      { department: 'Information Technology', students: 420, faculty: 20, hod: 'Dr. Amit Sharma', avgStudentAttendance: 84.5, avgFacultyAttendance: 92.8 },
      { department: 'Electronics & Communication', students: 480, faculty: 22, hod: 'Dr. Sunita Agarwal', avgStudentAttendance: 86.9, avgFacultyAttendance: 95.1 },
      { department: 'Mechanical Engineering', students: 540, faculty: 25, hod: 'Dr. Vikash Gupta', avgStudentAttendance: 88.3, avgFacultyAttendance: 96.2 },
      { department: 'Civil Engineering', students: 480, faculty: 22, hod: 'Dr. Neha Patel', avgStudentAttendance: 89.1, avgFacultyAttendance: 94.7 },
      { department: 'Chemical Engineering', students: 360, faculty: 18, hod: 'Dr. Rohit Verma', avgStudentAttendance: 83.6, avgFacultyAttendance: 91.5 },
      { department: 'Biotechnology', students: 720, faculty: 16, hod: 'Dr. Kavya Jain', avgStudentAttendance: 86.2, avgFacultyAttendance: 93.8 },
      { department: 'Computer Applications', students: 225, faculty: 12, hod: 'Dr. Arjun Yadav', avgStudentAttendance: 87.5, avgFacultyAttendance: 94.2 },
      { department: 'Electrical Engineering', students: 360, faculty: 18, hod: 'Dr. Pooja Mishra', avgStudentAttendance: 85.8, avgFacultyAttendance: 93.6 },
      { department: 'Data Science', students: 270, faculty: 15, hod: 'Dr. Rahul Tripathi', avgStudentAttendance: 88.9, avgFacultyAttendance: 95.3 },
      { department: 'Internet of Things', students: 180, faculty: 12, hod: 'Dr. Shreya Bansal', avgStudentAttendance: 86.7, avgFacultyAttendance: 92.9 },
    ],
    hodAttendance: [
      { name: 'Dr. Rajesh Kumar (CSE)', percentage: 97.2, department: 'Computer Science' },
      { name: 'Dr. Priya Singh (CSM)', percentage: 95.8, department: 'Computer Science & ML' },
      { name: 'Dr. Amit Sharma (IT)', percentage: 94.3, department: 'Information Technology' },
      { name: 'Dr. Sunita Agarwal (ECE)', percentage: 96.7, department: 'Electronics & Communication' },
      { name: 'Dr. Vikash Gupta (ME)', percentage: 98.1, department: 'Mechanical Engineering' },
      { name: 'Dr. Neha Patel (CE)', percentage: 95.4, department: 'Civil Engineering' },
      { name: 'Dr. Rohit Verma (CH)', percentage: 93.9, department: 'Chemical Engineering' },
      { name: 'Dr. Kavya Jain (BT)', percentage: 96.2, department: 'Biotechnology' },
      { name: 'Dr. Arjun Yadav (CA)', percentage: 94.8, department: 'Computer Applications' },
      { name: 'Dr. Pooja Mishra (EEE)', percentage: 95.6, department: 'Electrical Engineering' },
      { name: 'Dr. Rahul Tripathi (CSD)', percentage: 97.0, department: 'Data Science' },
      { name: 'Dr. Shreya Bansal (IoT)', percentage: 94.5, department: 'Internet of Things' },
    ],
    monthlyTrend: [
      { month: 'Jan', students: 87.2, faculty: 94.8, hods: 96.5 },
      { month: 'Feb', students: 85.6, faculty: 93.4, hods: 95.8 },
      { month: 'Mar', students: 88.1, faculty: 95.2, hods: 97.1 },
      { month: 'Apr', students: 84.9, faculty: 92.9, hods: 95.2 },
      { month: 'May', students: 86.4, faculty: 94.1, hods: 96.3 },
      { month: 'Jun', students: 87.8, faculty: 94.7, hods: 96.8 },
    ],
    attendanceDistribution: [
      { name: 'Excellent (90-100%)', value: 45, fill: '#22c55e' },
      { name: 'Good (80-89%)', value: 38, fill: '#3b82f6' },
      { name: 'Average (70-79%)', value: 12, fill: '#eab308' },
      { name: 'Poor (<70%)', value: 5, fill: '#ef4444' },
    ],
    topPerformers: {
      departments: [
        { name: 'Mechanical Engineering', attendance: 88.3 },
        { name: 'Civil Engineering', attendance: 89.1 },
        { name: 'Data Science', attendance: 88.9 },
      ],
      classes: [
        { name: 'BT-A 2nd Year', attendance: 92.4 },
        { name: 'ME-B 3rd Year', attendance: 91.8 },
        { name: 'CSD-A 1st Year', attendance: 90.6 },
      ]
    }
  };

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 90) return 'text-green-600 bg-green-50';
    if (percentage >= 80) return 'text-blue-600 bg-blue-50';
    if (percentage >= 70) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getBadgeColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-green-600';
    if (percentage >= 80) return 'bg-blue-600';
    if (percentage >= 70) return 'bg-yellow-600';
    return 'bg-red-600';
  };

  // Administration Functions
  const generateReport = async () => {
    setIsGeneratingReport(true);
    try {
      // Simulate report generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const reportData = {
        generatedBy: userData.fullName,
        generatedAt: new Date().toISOString(),
        instituteStats: principalData.instituteOverview,
        departmentStats: principalData.departmentWise,
        hodPerformance: principalData.hodAttendance
      };
      
      // Convert to CSV format
      const csvContent = [
        ['Institute Attendance Report'],
        ['Generated by:', userData.fullName],
        ['Generated at:', new Date().toLocaleString()],
        [''],
        ['Institute Overview'],
        ['Total Departments', principalData.instituteOverview.totalDepartments],
        ['Total Faculty', principalData.instituteOverview.totalFaculty],
        ['Total Students', principalData.instituteOverview.totalStudents],
        ['Overall Attendance', `${principalData.instituteOverview.overallAttendance}%`],
        [''],
        ['Department Performance'],
        ['Department', 'Students', 'Faculty', 'HOD', 'Student Attendance', 'Faculty Attendance'],
        ...principalData.departmentWise.map(dept => [
          dept.department,
          dept.students,
          dept.faculty,
          dept.hod,
          `${dept.avgStudentAttendance}%`,
          `${dept.avgFacultyAttendance}%`
        ])
      ].map(row => row.join(',')).join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `institute_attendance_report_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success('Institute attendance report generated and downloaded successfully!');
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Failed to generate report. Please try again.');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const backupDatabase = async () => {
    setIsBackingUp(true);
    try {
      // Simulate database backup
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const backupData = {
        timestamp: new Date().toISOString(),
        version: '2.1.0',
        students: await localDemoService.getAllStudents(),
        users: principalData.departmentWise,
        attendance_records: principalData.monthlyTrend,
        system_settings: {
          timeout_duration: 7,
          sms_enabled: true,
          alert_phone: '+916302694381'
        }
      };
      
      const backupJson = JSON.stringify(backupData, null, 2);
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `attendance_system_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success('Database backup completed and downloaded successfully!');
    } catch (error) {
      console.error('Error backing up database:', error);
      toast.error('Database backup failed. Please try again.');
    } finally {
      setIsBackingUp(false);
    }
  };

  const exportData = async () => {
    setIsExporting(true);
    try {
      // Simulate data export
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const exportData = {
        students: principalData.departmentWise.reduce((total, dept) => total + dept.students, 0),
        faculty: principalData.departmentWise.reduce((total, dept) => total + dept.faculty, 0),
        departments: principalData.departmentWise.length,
        exported_at: new Date().toISOString(),
        exported_by: userData.fullName
      };
      
      // Create comprehensive export
      const csvContent = [
        ['Data Export - Attendance Management System'],
        ['Exported by:', userData.fullName],
        ['Export Date:', new Date().toLocaleString()],
        [''],
        ['Summary Statistics'],
        ['Total Students', exportData.students],
        ['Total Faculty', exportData.faculty],
        ['Total Departments', exportData.departments],
        [''],
        ['Department Details'],
        ['Department', 'Students', 'Faculty Members', 'Head of Department', 'Student Attendance %', 'Faculty Attendance %'],
        ...principalData.departmentWise.map(dept => [
          dept.department,
          dept.students,
          dept.faculty,
          dept.hod,
          dept.avgStudentAttendance,
          dept.avgFacultyAttendance
        ])
      ].map(row => row.join(',')).join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `attendance_data_export_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success('Data export completed successfully!');
    } catch (error) {
      console.error('Error exporting data:', error);
      toast.error('Data export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportData = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    setIsImporting(true);
    try {
      const text = await file.text();
      
      if (file.name.endsWith('.json')) {
        const importedData = JSON.parse(text);
        
        // Validate imported data structure
        if (importedData.students && importedData.version) {
          // Simulate import process
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          toast.success(`Successfully imported data from ${file.name}`, {
            description: `${importedData.students?.data?.length || 0} students imported`
          });
        } else {
          throw new Error('Invalid file format');
        }
      } else if (file.name.endsWith('.csv')) {
        // Basic CSV validation
        const lines = text.split('\n');
        if (lines.length > 1) {
          await new Promise(resolve => setTimeout(resolve, 1500));
          toast.success(`Successfully imported ${lines.length - 1} records from CSV file`);
        } else {
          throw new Error('Empty CSV file');
        }
      } else {
        throw new Error('Unsupported file format. Please use JSON or CSV files.');
      }
    } catch (error) {
      console.error('Error importing data:', error);
      toast.error(`Import failed: ${error.message}`);
    } finally {
      setIsImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const loadTimeoutStudents = async () => {
    try {
      const response = await localDemoService.getTimeoutStudents();
      if (response.data) {
        setTimeoutStudents(response.data);
        setShowTimeoutManagement(true);
      }
    } catch (error) {
      console.error('Error loading timeout students:', error);
      toast.error('Failed to load timeout students');
    }
  };

  const sendAlert = async (studentId: string) => {
    try {
      const response = await localDemoService.sendStudentAlert(studentId, 'timeout');
      if (response.data) {
        toast.success(`Alert sent successfully to faculty and parents for student ${response.data.student.name}`);
        loadTimeoutStudents(); // Refresh the list
      }
    } catch (error) {
      console.error('Error sending alert:', error);
      toast.error('Failed to send alert');
    }
  };

  if (showTimeoutManagement) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1>Timeout Management</h1>
            <p className="text-muted-foreground">Monitor and manage students who have left class</p>
          </div>
          <Button variant="outline" onClick={() => setShowTimeoutManagement(false)}>
            Back to Dashboard
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-red-500" />
              Students on Timeout ({timeoutStudents.length})
            </CardTitle>
            <CardDescription>
              Students who have been absent from class for more than 7 minutes
            </CardDescription>
          </CardHeader>
          <CardContent>
            {timeoutStudents.length > 0 ? (
              <div className="space-y-4">
                {timeoutStudents.map((student: any) => (
                  <div key={student.id} className="p-4 border rounded-lg bg-red-50 border-red-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-red-800">{student.name}</h4>
                        <p className="text-sm text-red-600">
                          Roll: {student.rollNumber} | Class: {student.className}
                        </p>
                        <p className="text-sm text-red-600">
                          Timeout Duration: {Math.floor(student.timeoutDurationPassed / (1000 * 60))} minutes
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {student.needsAlert && !student.alertsSent && (
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => sendAlert(student.id)}
                          >
                            <AlertCircle className="w-4 h-4 mr-2" />
                            Send Alert
                          </Button>
                        )}
                        {student.alertsSent && (
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-800">
                            Alert Sent
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Timer className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No students currently on timeout.</p>
                <p className="text-sm">All students are accounted for in their classes.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Principal Dashboard</h1>
          <p className="text-muted-foreground">Institute-wide Attendance Management System</p>
        </div>
        <Badge className="bg-purple-600 text-white flex items-center gap-2">
          <Award className="w-4 h-4" />
          Principal Access
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Institute Overview</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="hods">HOD Performance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="administration">Administration</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Institute Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Departments</CardTitle>
                <Building className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{principalData.instituteOverview.totalDepartments}</div>
                <p className="text-xs text-muted-foreground">Academic departments</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Faculty</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{principalData.instituteOverview.totalFaculty}</div>
                <p className="text-xs text-muted-foreground">Teaching staff</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                <GraduationCap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{principalData.instituteOverview.totalStudents}</div>
                <p className="text-xs text-muted-foreground">Enrolled students</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">HODs</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{principalData.instituteOverview.totalHODs}</div>
                <p className="text-xs text-muted-foreground">Department heads</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{principalData.instituteOverview.overallAttendance}%</div>
                <p className="text-xs text-muted-foreground">Institute average</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Monthly Attendance Trend */}
            <Card>
              <CardHeader>
                <CardTitle>Institute Attendance Trend</CardTitle>
                <CardDescription>Monthly attendance across all user categories</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={principalData.monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="students" stroke="#3b82f6" name="Students" strokeWidth={2} />
                    <Line type="monotone" dataKey="faculty" stroke="#10b981" name="Faculty" strokeWidth={2} />
                    <Line type="monotone" dataKey="hods" stroke="#8b5cf6" name="HODs" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Attendance Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Attendance Distribution</CardTitle>
                <CardDescription>Student attendance distribution across the institute</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={principalData.attendanceDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {principalData.attendanceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Top Performers */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-500" />
                  Top Performing Departments
                </CardTitle>
                <CardDescription>Departments with highest student attendance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {principalData.topPerformers.departments.map((dept, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-yellow-600">#{index + 1}</Badge>
                        <span>{dept.name}</span>
                      </div>
                      <Badge className="bg-green-600">{dept.attendance}%</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-500" />
                  Top Performing Classes
                </CardTitle>
                <CardDescription>Individual classes with exceptional attendance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {principalData.topPerformers.classes.map((cls, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-yellow-600">#{index + 1}</Badge>
                        <span>{cls.name}</span>
                      </div>
                      <Badge className="bg-green-600">{cls.attendance}%</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="departments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Department-wise Performance Overview</CardTitle>
              <CardDescription>Comprehensive attendance analytics for all departments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {principalData.departmentWise.map((dept, index) => (
                  <div key={index} className="p-6 border rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="text-lg">{dept.department}</h4>
                        <p className="text-sm text-muted-foreground">HOD: {dept.hod}</p>
                      </div>
                      <div className="flex gap-2">
                        <Badge className={getBadgeColor(dept.avgStudentAttendance)}>
                          Students: {dept.avgStudentAttendance}%
                        </Badge>
                        <Badge className={getBadgeColor(dept.avgFacultyAttendance)}>
                          Faculty: {dept.avgFacultyAttendance}%
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-xl font-semibold">{dept.students}</div>
                        <p className="text-xs text-muted-foreground">Students</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-semibold">{dept.faculty}</div>
                        <p className="text-xs text-muted-foreground">Faculty</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-semibold text-blue-600">{dept.avgStudentAttendance}%</div>
                        <p className="text-xs text-muted-foreground">Student Avg</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-semibold text-green-600">{dept.avgFacultyAttendance}%</div>
                        <p className="text-xs text-muted-foreground">Faculty Avg</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Student Attendance</span>
                        <span>{dept.avgStudentAttendance}%</span>
                      </div>
                      <Progress value={dept.avgStudentAttendance} className="h-2" />
                      
                      <div className="flex items-center justify-between text-sm">
                        <span>Faculty Attendance</span>
                        <span>{dept.avgFacultyAttendance}%</span>
                      </div>
                      <Progress value={dept.avgFacultyAttendance} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hods" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>HOD Attendance Performance</CardTitle>
              <CardDescription>Individual attendance records of all department heads</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {principalData.hodAttendance.map((hod, index) => (
                  <div key={index} className={`p-4 rounded-lg border ${getAttendanceColor(hod.percentage)}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4>{hod.name}</h4>
                          <Badge variant="outline">{hod.department}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">Department: {hod.department}</p>
                        <Progress value={hod.percentage} />
                      </div>
                      <div className="ml-4">
                        <Badge className={getBadgeColor(hod.percentage)}>
                          {hod.percentage}%
                        </Badge>
                        {hod.percentage >= 96 && (
                          <Award className="w-5 h-5 text-yellow-500 mt-2 mx-auto" />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          {/* Department Comparison Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Department Attendance Comparison</CardTitle>
              <CardDescription>Student vs Faculty attendance across all departments</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={principalData.departmentWise} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="department" 
                    angle={-45}
                    textAnchor="end"
                    height={100}
                    fontSize={12}
                  />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="avgStudentAttendance" fill="#3b82f6" name="Students" />
                  <Bar dataKey="avgFacultyAttendance" fill="#10b981" name="Faculty" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Critical Issues */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                Areas Requiring Attention
              </CardTitle>
              <CardDescription>Departments and metrics that need immediate attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <h4 className="text-red-800 mb-2">Low Student Attendance</h4>
                  <p className="text-sm text-red-700">
                    Physics Department: 83.6% (Below institute average)
                  </p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <h4 className="text-yellow-800 mb-2">Faculty Attendance Watch</h4>
                  <p className="text-sm text-yellow-700">
                    Physics Department: 91.5% (Lowest among all departments)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Institute Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Institute Performance Summary</CardTitle>
              <CardDescription>Overall health check of attendance across the institute</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">92.5%</div>
                  <p className="text-sm text-green-800">Overall Faculty Performance</p>
                  <Badge className="bg-green-600 mt-2">Excellent</Badge>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">86.4%</div>
                  <p className="text-sm text-blue-800">Overall Student Performance</p>
                  <Badge className="bg-blue-600 mt-2">Good</Badge>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">95.8%</div>
                  <p className="text-sm text-purple-800">HOD Performance</p>
                  <Badge className="bg-purple-600 mt-2">Outstanding</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="administration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Administration Functions</CardTitle>
              <CardDescription>Manage and perform administrative tasks for the institute</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Button 
                  onClick={generateReport} 
                  disabled={isGeneratingReport}
                  className="h-20 flex flex-col gap-2"
                >
                  <FileText className="w-6 h-6" />
                  {isGeneratingReport ? 'Generating...' : 'Generate Report'}
                  <span className="text-xs opacity-75">Institute attendance report</span>
                </Button>
                
                <Button 
                  onClick={backupDatabase} 
                  disabled={isBackingUp}
                  variant="outline"
                  className="h-20 flex flex-col gap-2"
                >
                  <Database className="w-6 h-6" />
                  {isBackingUp ? 'Backing up...' : 'Backup Database'}
                  <span className="text-xs opacity-75">Full system backup</span>
                </Button>
                
                <Button 
                  onClick={exportData} 
                  disabled={isExporting}
                  variant="outline"
                  className="h-20 flex flex-col gap-2"
                >
                  <Download className="w-6 h-6" />
                  {isExporting ? 'Exporting...' : 'Export Data'}
                  <span className="text-xs opacity-75">Export to CSV</span>
                </Button>
                
                <div className="flex flex-col">
                  <Label htmlFor="import-file" className="mb-2">Import Data</Label>
                  <Input 
                    id="import-file"
                    type="file" 
                    accept=".json,.csv"
                    onChange={handleImportData}
                    disabled={isImporting}
                    className="h-20"
                  />
                  {isImporting && (
                    <span className="text-xs text-blue-600 mt-1">Importing...</span>
                  )}
                </div>
                
                <Button 
                  onClick={loadTimeoutStudents}
                  variant="destructive"
                  className="h-20 flex flex-col gap-2"
                >
                  <Timer className="w-6 h-6" />
                  Timeout Management
                  <span className="text-xs opacity-75">Monitor absent students</span>
                </Button>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-2">SMS Alert System</h4>
                  <p className="text-sm text-blue-700">All alerts are sent to:</p>
                  <p className="text-sm font-mono text-blue-800">+916302694381</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
              <CardDescription>Current system health and configuration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-green-800 font-medium">Database Status</span>
                  </div>
                  <p className="text-sm text-green-700">Connected and operational</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-green-800 font-medium">SMS Service</span>
                  </div>
                  <p className="text-sm text-green-700">Active and sending alerts</p>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="text-blue-800 font-medium">Timeout Settings</span>
                  </div>
                  <p className="text-sm text-blue-700">7 minutes threshold</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}