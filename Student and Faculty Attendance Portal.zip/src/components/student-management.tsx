import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Search, Plus, Edit, Trash2, Users, Download, Upload } from "lucide-react";
import { supabaseService } from "../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  className: string;
  year: number;
  semester: number;
  guardianName: string;
  guardianPhone: string;
  isActive: boolean;
  enrolledDate: string;
}

interface StudentManagementProps {
  userType: 'faculty' | 'hod' | 'principal';
}

export function StudentManagement({ userType }: StudentManagementProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [filterClass, setFilterClass] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [newStudent, setNewStudent] = useState({
    rollNumber: '',
    name: '',
    email: '',
    phone: '',
    department: '',
    className: '',
    year: 1,
    semester: 1,
    guardianName: '',
    guardianPhone: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterStudents();
  }, [students, searchTerm, filterDepartment, filterClass]);

  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // Load students from Supabase backend
      const { projectId } = await import('../utils/supabase/info');
      const result = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-3d5883fa/students`, {
        headers: {
          'Authorization': `Bearer ${await getAccessToken()}`,
        },
      });

      if (result.ok) {
        const data = await result.json();
        setStudents(data.students || []);
      } else {
        // Create demo students if none exist
        await createDemoStudents();
        setStudents(getDemoStudents());
      }
    } catch (error) {
      console.error('Error loading data:', error);
      // Fallback to demo data
      setStudents(getDemoStudents());
      toast.error("Using demo data - some features may be limited");
    } finally {
      setIsLoading(false);
    }
  };

  const getAccessToken = async () => {
    const { session } = await supabaseService.getSession();
    return session?.access_token || '';
  };

  const getDemoStudents = (): Student[] => [
    {
      id: 'student:CS001',
      rollNumber: 'CS001',
      name: 'Aarav Sharma',
      email: 'aarav.sharma@student.edu',
      phone: '+919876543210',
      department: 'Computer Science',
      className: 'CS-4A',
      year: 4,
      semester: 7,
      guardianName: 'Rajesh Sharma (Father)',
      guardianPhone: '+919876543211',
      isActive: true,
      enrolledDate: '2021-09-01'
    },
    {
      id: 'student:CS002',
      rollNumber: 'CS002',
      name: 'Aditi Verma',
      email: 'aditi.verma@student.edu',
      phone: '+919876543212',
      department: 'Computer Science',
      className: 'CS-4A',
      year: 4,
      semester: 7,
      guardianName: 'Sunita Verma (Mother)',
      guardianPhone: '+919876543213',
      isActive: true,
      enrolledDate: '2021-09-01'
    },
    {
      id: 'student:CS003',
      rollNumber: 'CS003',
      name: 'Arjun Gupta',
      email: 'arjun.gupta@student.edu',
      phone: '+919876543214',
      department: 'Computer Science',
      className: 'CS-4A',
      year: 4,
      semester: 7,
      guardianName: 'Mohan Gupta (Father)',
      guardianPhone: '+919876543215',
      isActive: true,
      enrolledDate: '2021-09-01'
    },
    {
      id: 'student:IT001',
      rollNumber: 'IT001',
      name: 'Kavya Agarwal',
      email: 'kavya.agarwal@student.edu',
      phone: '+919876543216',
      department: 'Information Technology',
      className: 'IT-4A',
      year: 4,
      semester: 7,
      guardianName: 'Priya Agarwal (Mother)',
      guardianPhone: '+919876543217',
      isActive: true,
      enrolledDate: '2021-09-01'
    },
    {
      id: 'student:ME001',
      rollNumber: 'ME001',
      name: 'Dhruv Singh',
      email: 'dhruv.singh@student.edu',
      phone: '+919876543218',
      department: 'Mechanical Engineering',
      className: 'ME-3A',
      year: 3,
      semester: 5,
      guardianName: 'Vikram Singh (Father)',
      guardianPhone: '+919876543219',
      isActive: true,
      enrolledDate: '2022-09-01'
    }
  ];

  const createDemoStudents = async () => {
    try {
      const demoStudents = getDemoStudents();
      for (const student of demoStudents) {
        await addStudentToBackend(student);
      }
    } catch (error) {
      console.error('Error creating demo students:', error);
    }
  };

  const filterStudents = () => {
    let filtered = students;

    if (searchTerm) {
      filtered = filtered.filter(student =>
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterDepartment !== 'all') {
      filtered = filtered.filter(student => student.department === filterDepartment);
    }

    if (filterClass !== 'all') {
      filtered = filtered.filter(student => student.className === filterClass);
    }

    setFilteredStudents(filtered);
  };

  const addStudentToBackend = async (studentData: any) => {
    const { projectId } = await import('../utils/supabase/info');
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-3d5883fa/students`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await getAccessToken()}`,
      },
      body: JSON.stringify(studentData),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to add student');
    }

    return response.json();
  };

  const handleAddStudent = async () => {
    try {
      if (!newStudent.rollNumber || !newStudent.name || !newStudent.email) {
        toast.error("Please fill in all required fields");
        return;
      }

      // Check if roll number already exists
      const existingStudent = students.find(s => s.rollNumber === newStudent.rollNumber);
      if (existingStudent) {
        toast.error("A student with this roll number already exists");
        return;
      }

      const studentData = {
        ...newStudent,
        id: `student-${Date.now()}`,
        isActive: true,
        enrolledDate: new Date().toISOString().split('T')[0]
      };

      await addStudentToBackend(studentData);
      await loadData();
      
      setIsAddDialogOpen(false);
      resetForm();
      toast.success("Student added successfully");
    } catch (error) {
      console.error('Error adding student:', error);
      toast.error(error.message || "Failed to add student");
    }
  };

  const updateStudentInBackend = async (studentId: string, studentData: any) => {
    const { projectId } = await import('../utils/supabase/info');
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-3d5883fa/students/${studentId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await getAccessToken()}`,
      },
      body: JSON.stringify(studentData),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to update student');
    }

    return response.json();
  };

  const handleEditStudent = async () => {
    try {
      if (!editingStudent) return;

      await updateStudentInBackend(editingStudent.id, editingStudent);
      await loadData();
      
      setEditingStudent(null);
      toast.success("Student updated successfully");
    } catch (error) {
      console.error('Error updating student:', error);
      toast.error(error.message || "Failed to update student");
    }
  };

  const handleDeleteStudent = async (studentId: string) => {
    try {
      // Deactivate instead of delete
      const student = students.find(s => s.id === studentId);
      if (student) {
        await updateStudentInBackend(studentId, { ...student, isActive: false });
        await loadData();
        toast.success("Student deactivated successfully");
      }
    } catch (error) {
      console.error('Error deactivating student:', error);
      toast.error(error.message || "Failed to deactivate student");
    }
  };

  const resetForm = () => {
    setNewStudent({
      rollNumber: '',
      name: '',
      email: '',
      phone: '',
      department: '',
      className: '',
      year: 1,
      semester: 1,
      guardianName: '',
      guardianPhone: ''
    });
  };

  const exportData = () => {
    const csvContent = [
      ['Roll Number', 'Name', 'Email', 'Phone', 'Department', 'Class', 'Year', 'Semester'],
      ...filteredStudents.map(student => [
        student.rollNumber,
        student.name,
        student.email,
        student.phone,
        student.department,
        student.className,
        student.year.toString(),
        student.semester.toString()
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students_data.csv';
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success("Data exported successfully");
  };

  const departments = [...new Set(students.map(s => s.department))];
  const classes = [...new Set(students.map(s => s.className))];

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Loading student data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Student Management
          </CardTitle>
          <CardDescription>
            Manage student information and database records
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{students.length}</div>
              <div className="text-sm text-blue-800">Total Students</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {students.filter(s => s.isActive).length}
              </div>
              <div className="text-sm text-green-800">Active Students</div>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{departments.length}</div>
              <div className="text-sm text-orange-800">Departments</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{classes.length}</div>
              <div className="text-sm text-purple-800">Classes</div>
            </div>
          </div>

          {/* Filters and Actions */}
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex gap-2 items-center flex-wrap">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterClass} onValueChange={setFilterClass}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Filter by class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {classes.map(cls => (
                    <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button onClick={exportData} variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Student
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add New Student</DialogTitle>
                    <DialogDescription>
                      Enter the student's information to add them to the database.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="rollNumber">Roll Number *</Label>
                      <Input
                        id="rollNumber"
                        value={newStudent.rollNumber}
                        onChange={(e) => setNewStudent({...newStudent, rollNumber: e.target.value})}
                        placeholder="CS001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        value={newStudent.name}
                        onChange={(e) => setNewStudent({...newStudent, name: e.target.value})}
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newStudent.email}
                        onChange={(e) => setNewStudent({...newStudent, email: e.target.value})}
                        placeholder="john.doe@student.edu"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={newStudent.phone}
                        onChange={(e) => setNewStudent({...newStudent, phone: e.target.value})}
                        placeholder="+1234567890"
                      />
                    </div>
                    <div>
                      <Label htmlFor="department">Department</Label>
                      <Input
                        id="department"
                        value={newStudent.department}
                        onChange={(e) => setNewStudent({...newStudent, department: e.target.value})}
                        placeholder="Computer Science"
                      />
                    </div>
                    <div>
                      <Label htmlFor="class">Class</Label>
                      <Input
                        id="className"
                        value={newStudent.className}
                        onChange={(e) => setNewStudent({...newStudent, className: e.target.value})}
                        placeholder="CS-4A"
                      />
                    </div>
                    <div>
                      <Label htmlFor="year">Year</Label>
                      <Select value={newStudent.year.toString()} onValueChange={(value) => setNewStudent({...newStudent, year: parseInt(value)})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1st Year</SelectItem>
                          <SelectItem value="2">2nd Year</SelectItem>
                          <SelectItem value="3">3rd Year</SelectItem>
                          <SelectItem value="4">4th Year</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="semester">Semester</Label>
                      <Select value={newStudent.semester.toString()} onValueChange={(value) => setNewStudent({...newStudent, semester: parseInt(value)})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1,2,3,4,5,6,7,8].map(sem => (
                            <SelectItem key={sem} value={sem.toString()}>{sem}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="guardianName">Guardian Name</Label>
                      <Input
                        id="guardianName"
                        value={newStudent.guardianName}
                        onChange={(e) => setNewStudent({...newStudent, guardianName: e.target.value})}
                        placeholder="Robert Doe"
                      />
                    </div>
                    <div>
                      <Label htmlFor="guardianPhone">Guardian Phone</Label>
                      <Input
                        id="guardianPhone"
                        value={newStudent.guardianPhone}
                        onChange={(e) => setNewStudent({...newStudent, guardianPhone: e.target.value})}
                        placeholder="+1234567891"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddStudent}>
                      Add Student
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Students Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll Number</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Year</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">{student.rollNumber}</TableCell>
                    <TableCell>{student.name}</TableCell>
                    <TableCell>{student.email}</TableCell>
                    <TableCell>{student.department}</TableCell>
                    <TableCell>{student.className}</TableCell>
                    <TableCell>{student.year}</TableCell>
                    <TableCell>
                      <Badge variant={student.isActive ? "default" : "secondary"}>
                        {student.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingStudent(student)}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        {(userType === 'hod' || userType === 'principal') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteStudent(student.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredStudents.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No students found matching your criteria.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Student Dialog */}
      {editingStudent && (
        <Dialog open={!!editingStudent} onOpenChange={() => setEditingStudent(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Student</DialogTitle>
              <DialogDescription>
                Update the student's information.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="editRollNumber">Roll Number</Label>
                <Input
                  id="editRollNumber"
                  value={editingStudent.rollNumber}
                  onChange={(e) => setEditingStudent({...editingStudent, rollNumber: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="editName">Name</Label>
                <Input
                  id="editName"
                  value={editingStudent.name}
                  onChange={(e) => setEditingStudent({...editingStudent, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="editEmail">Email</Label>
                <Input
                  id="editEmail"
                  type="email"
                  value={editingStudent.email}
                  onChange={(e) => setEditingStudent({...editingStudent, email: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="editPhone">Phone</Label>
                <Input
                  id="editPhone"
                  value={editingStudent.phone}
                  onChange={(e) => setEditingStudent({...editingStudent, phone: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="editDepartment">Department</Label>
                <Input
                  id="editDepartment"
                  value={editingStudent.department}
                  onChange={(e) => setEditingStudent({...editingStudent, department: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="editClass">Class</Label>
                <Input
                  id="editClass"
                  value={editingStudent.className}
                  onChange={(e) => setEditingStudent({...editingStudent, className: e.target.value})}
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setEditingStudent(null)}>
                Cancel
              </Button>
              <Button onClick={handleEditStudent}>
                Update Student
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}