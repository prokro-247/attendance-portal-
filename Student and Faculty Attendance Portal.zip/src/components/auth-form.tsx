import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Switch } from "./ui/switch";
import { ArrowLeft, Eye, EyeOff, Settings, Zap } from "lucide-react";
import { supabaseService } from "../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface AuthFormProps {
  interfaceType: 'student' | 'faculty' | 'hod' | 'principal';
  onBack: () => void;
  onAuth: (userData: any) => void;
}

export function AuthForm({ interfaceType, onBack, onAuth }: AuthFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("login");
  const [autoLoginEnabled, setAutoLoginEnabled] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isAutoLoggingIn, setIsAutoLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    rollNumber: '',
    department: '',
    employeeId: ''
  });

  // Auto-login storage keys
  const getStorageKey = (key: string) => `attendance_${interfaceType}_${key}`;

  // Clear login error when switching tabs or changing form data
  const clearLoginError = () => {
    if (loginError) setLoginError(null);
  };

  // Check for existing session and auto-login on component mount
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Check auto-login settings
        const autoLoginSetting = localStorage.getItem(getStorageKey('auto_login'));
        const savedCredentials = localStorage.getItem(getStorageKey('credentials'));
        
        if (autoLoginSetting === 'true' && savedCredentials) {
          const credentials = JSON.parse(savedCredentials);
          setAutoLoginEnabled(true);
          setIsAutoLoggingIn(true);
          
          // Auto-fill form
          setFormData(prev => ({
            ...prev,
            email: credentials.email,
            password: credentials.password
          }));

          // Auto login
          toast.info(`Auto-login enabled for ${interfaceType}`, {
            description: "Signing you in automatically..."
          });

          const result = await supabaseService.signIn(credentials.email, credentials.password);
          
          if (result.error) {
            toast.error('Auto-login failed. Please sign in manually.');
            // Clear invalid credentials
            localStorage.removeItem(getStorageKey('credentials'));
            localStorage.removeItem(getStorageKey('auto_login'));
            setAutoLoginEnabled(false);
            setIsAutoLoggingIn(false);
            return;
          }

          if (!result.data || !result.data.user) {
            toast.error('Auto-login failed. Please sign in manually.');
            setIsAutoLoggingIn(false);
            return;
          }

          const user = result.data.user;
          if (user.interfaceType !== interfaceType) {
            toast.error(`Auto-login failed: Account not authorized for ${interfaceType} portal`);
            await supabaseService.signOut();
            setIsAutoLoggingIn(false);
            return;
          }
          
          toast.success(`${interfaceType.charAt(0).toUpperCase() + interfaceType.slice(1)} auto-login successful!`);
          onAuth(user);
          return;
        }

        // Check for existing session with timeout
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Session check timeout')), 3000);
        });

        const sessionPromise = supabaseService.getSession();
        const sessionResult = await Promise.race([sessionPromise, timeoutPromise]);

        if (sessionResult && 'session' in sessionResult && sessionResult.session) {
          try {
            const userProfile = await supabaseService.getUserProfile(sessionResult.session.user.id);
            if (userProfile.data && userProfile.data.interfaceType === interfaceType) {
              onAuth(userProfile.data);
            }
          } catch (profileError) {
            console.warn('Failed to get user profile:', profileError);
          }
        }
      } catch (error) {
        console.warn('App initialization had issues, continuing in offline mode:', error);
      } finally {
        setIsAutoLoggingIn(false);
      }
    };
    
    // Run initialization without blocking
    initializeApp();
  }, [interfaceType, onAuth]);

  const handleAutoLoginToggle = (enabled: boolean) => {
    setAutoLoginEnabled(enabled);
    
    if (enabled) {
      toast.info(`Auto-login enabled for ${interfaceType}`, {
        description: "Your credentials will be saved securely for automatic login."
      });
    } else {
      // Clear stored credentials
      localStorage.removeItem(getStorageKey('credentials'));
      localStorage.removeItem(getStorageKey('auto_login'));
      toast.info("Auto-login disabled", {
        description: "Stored credentials have been cleared."
      });
    }
  };

  const saveCredentials = (email: string, password: string) => {
    if (autoLoginEnabled) {
      const credentials = { email, password };
      localStorage.setItem(getStorageKey('credentials'), JSON.stringify(credentials));
      localStorage.setItem(getStorageKey('auto_login'), 'true');
    }
  };

  const handleSubmit = async (e: React.FormEvent, isLogin: boolean) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isLogin) {
        // Handle login
        const result = await supabaseService.signIn(formData.email, formData.password);
        
        if (result.error) {
          setLoginError(result.error.message || 'Login failed. Please check your credentials.');
          return;
        }

        if (!result.data || !result.data.user) {
          setLoginError('Login failed. Please try again.');
          return;
        }

        // Check if user has the correct interface type
        const user = result.data.user;
        if (user.interfaceType !== interfaceType) {
          setLoginError(`This account is not authorized for ${interfaceType} portal`);
          await supabaseService.signOut();
          return;
        }

        // Save credentials for auto-login if enabled
        saveCredentials(formData.email, formData.password);
        
        // Clear any previous errors
        setLoginError(null);
        toast.success(`${interfaceType.charAt(0).toUpperCase() + interfaceType.slice(1)} login successful!`);
        onAuth(user);
      } else {
        // Handle signup
        if (formData.password !== formData.confirmPassword) {
          toast.error("Passwords do not match.");
          return;
        }

        const result = await supabaseService.signUp({
          email: formData.email,
          password: formData.password,
          fullName: formData.fullName,
          interfaceType: interfaceType,
          employeeId: formData.employeeId,
          className: formData.rollNumber,
          department: formData.department
        });

        if (result.error) {
          toast.error(result.error);
          return;
        }

        if (!result.data) {
          toast.error('Account creation failed. Please try again.');
          return;
        }

        toast.success(`${interfaceType.charAt(0).toUpperCase() + interfaceType.slice(1)} account created successfully! Please sign in.`);
        
        // Clear the form
        setFormData({
          email: '',
          password: '',
          confirmPassword: '',
          fullName: '',
          rollNumber: '',
          department: '',
          employeeId: ''
        });
        
        // Switch to login tab after successful signup
        setActiveTab("login");
      }
    } catch (error) {
      console.error('Authentication error:', error);
      setLoginError(error.message || "An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const fillDemoCredentials = (userType: string) => {
    const demoCredentials = {
      student: { email: 'rahul.sharma@student.edu', password: 'password123' },
      faculty: { email: 'priya.singh@college.edu', password: 'password123' },
      hod: { email: 'rajesh.kumar@college.edu', password: 'password123' },
      principal: { email: 'sunita.agarwal@college.edu', password: 'password123' }
    };

    const credentials = demoCredentials[userType] || demoCredentials.student;
    setFormData(prev => ({
      ...prev,
      email: credentials.email,
      password: credentials.password
    }));
    
    // Clear any previous errors
    clearLoginError();
    toast.success(`Demo credentials filled for ${userType} portal`);
  };

  const getPortalTitle = () => {
    const titles = {
      student: 'Student Portal',
      faculty: 'Faculty Portal',
      hod: 'HOD Portal',
      principal: 'Principal Portal'
    };
    return titles[interfaceType];
  };

  const getPortalDescription = () => {
    const descriptions = {
      student: 'Access your personal attendance records and analytics',
      faculty: 'Manage class attendance and monitor student performance',
      hod: 'Oversee faculty attendance and department analytics',
      principal: 'Monitor institute-wide attendance and comprehensive reports'
    };
    return descriptions[interfaceType];
  };

  // Animation variants
  const cardVariants = {
    initial: { 
      opacity: 0, 
      y: 20,
      scale: 0.95
    },
    animate: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  };

  const formVariants = {
    hidden: { 
      opacity: 0, 
      x: -10
    },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: {
        duration: 0.3,
        staggerChildren: 0.1
      }
    }
  };

  const fieldVariants = {
    hidden: { 
      opacity: 0, 
      y: 10
    },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.3
      }
    }
  };

  if (isAutoLoggingIn) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"
          />
          <h2 className="text-xl font-semibold mb-2">Auto-Login Active</h2>
          <p className="text-muted-foreground">Signing you in automatically...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        variants={cardVariants}
        initial="initial"
        animate="animate"
      >
        <Card className="w-full max-w-md">
          <CardHeader>
            <motion.div 
              className="flex items-center gap-2 mb-2"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="ghost" size="sm" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </motion.div>
              <CardTitle>{getPortalTitle()}</CardTitle>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <CardDescription>
                {getPortalDescription()}
              </CardDescription>
            </motion.div>
          </CardHeader>
          <CardContent>
            {/* Auto-Login Settings */}
            <motion.div 
              className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900">Auto-Login</span>
                </div>
                <Switch
                  checked={autoLoginEnabled}
                  onCheckedChange={handleAutoLoginToggle}
                />
              </div>
              <p className="text-xs text-blue-700 mt-2">
                {autoLoginEnabled 
                  ? "Enabled - You'll be automatically signed in next time"
                  : "Disabled - Manual login required each time"
                }
              </p>
            </motion.div>

            <Tabs value={activeTab} onValueChange={(value) => {
              setActiveTab(value);
              clearLoginError();
            }} className="w-full">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login">Login</TabsTrigger>
                  <TabsTrigger value="signup">Sign Up</TabsTrigger>
                </TabsList>
              </motion.div>
              
              <AnimatePresence mode="wait">
                <TabsContent value="login" key="login">
                  <motion.form 
                    onSubmit={(e) => handleSubmit(e, true)} 
                    className="space-y-4"
                    variants={formVariants}
                    initial="hidden"
                    animate="visible"
                  >
                    {loginError && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 bg-red-50 border border-red-200 rounded-lg"
                      >
                        <p className="text-sm text-red-800">{loginError}</p>
                      </motion.div>
                    )}
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder={`Enter your ${interfaceType} email`}
                        value={formData.email}
                        onChange={(e) => {
                          setFormData(prev => ({...prev, email: e.target.value}));
                          clearLoginError();
                        }}
                        required
                      />
                    </motion.div>
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter your password"
                          value={formData.password}
                          onChange={(e) => {
                            setFormData(prev => ({...prev, password: e.target.value}));
                            clearLoginError();
                          }}
                          required
                        />
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            <motion.div
                              initial={false}
                              animate={{ rotate: showPassword ? 180 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </motion.div>
                          </Button>
                        </motion.div>
                      </div>
                    </motion.div>
                    
                    <motion.div variants={fieldVariants}>
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button type="submit" className="w-full" disabled={isLoading}>
                          {isLoading ? (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
                            />
                          ) : null}
                          {isLoading ? 'Signing In...' : `Sign Into ${interfaceType.charAt(0).toUpperCase() + interfaceType.slice(1)} Portal`}
                        </Button>
                      </motion.div>
                    </motion.div>
                    
                    {/* Quick Demo Access */}
                    <motion.div 
                      className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200"
                      variants={fieldVariants}
                    >
                      <p className="text-sm text-green-800 font-medium mb-3">Quick Demo Access:</p>
                      <div className="grid grid-cols-2 gap-2">
                        {['student', 'faculty', 'hod', 'principal'].map((type) => (
                          <motion.button
                            key={type}
                            type="button"
                            onClick={() => fillDemoCredentials(type)}
                            className={`px-3 py-2 text-xs rounded-md transition-colors capitalize ${
                              type === interfaceType 
                                ? 'bg-green-200 hover:bg-green-300 text-green-900 font-medium border-2 border-green-400'
                                : 'bg-green-100 hover:bg-green-200 text-green-800'
                            }`}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            {type}
                            {type === interfaceType && ' ✓'}
                          </motion.button>
                        ))}
                      </div>
                      <p className="text-xs text-green-600 mt-2">
                        Click "{interfaceType}" to auto-fill demo credentials for this portal
                      </p>
                    </motion.div>
                  </motion.form>
                </TabsContent>
                
                <TabsContent value="signup" key="signup">
                  <motion.form 
                    onSubmit={(e) => handleSubmit(e, false)} 
                    className="space-y-4"
                    variants={formVariants}
                    initial="hidden"
                    animate="visible"
                  >
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        placeholder="Enter your full name"
                        value={formData.fullName}
                        onChange={(e) => setFormData(prev => ({...prev, fullName: e.target.value}))}
                        required
                      />
                    </motion.div>
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="email-signup">Email</Label>
                      <Input
                        id="email-signup"
                        type="email"
                        placeholder="Enter your email"
                        value={formData.email}
                        onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                        required
                      />
                    </motion.div>
                    
                    {interfaceType === 'student' && (
                      <motion.div className="space-y-2" variants={fieldVariants}>
                        <Label htmlFor="rollNumber">Roll Number</Label>
                        <Input
                          id="rollNumber"
                          placeholder="Enter your roll number"
                          value={formData.rollNumber}
                          onChange={(e) => setFormData(prev => ({...prev, rollNumber: e.target.value}))}
                          required
                        />
                      </motion.div>
                    )}
                    
                    {interfaceType !== 'student' && (
                      <motion.div className="space-y-2" variants={fieldVariants}>
                        <Label htmlFor="employeeId">Employee ID</Label>
                        <Input
                          id="employeeId"
                          placeholder="Enter your employee ID"
                          value={formData.employeeId}
                          onChange={(e) => setFormData(prev => ({...prev, employeeId: e.target.value}))}
                          required
                        />
                      </motion.div>
                    )}
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="department">Department</Label>
                      <select
                        id="department"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        value={formData.department}
                        onChange={(e) => setFormData(prev => ({...prev, department: e.target.value}))}
                        required
                      >
                        <option value="">Select Department</option>
                        <option value="Computer Science">Computer Science (CSE)</option>
                        <option value="Computer Science & Machine Learning">Computer Science & Machine Learning (CSM)</option>
                        <option value="Computer Science & Data Science">Computer Science & Data Science (CSD)</option>
                        <option value="Electrical & Electronics Engineering">Electrical & Electronics Engineering (EEE)</option>
                        <option value="Electronics & Communication Engineering">Electronics & Communication Engineering (ECE)</option>
                        <option value="Information Technology">Information Technology (IT)</option>
                        <option value="Internet of Things">Internet of Things (IoT)</option>
                        <option value="Biotechnology">Biotechnology (BT)</option>
                        <option value="Computer Applications">Computer Applications (CA)</option>
                        <option value="Mechanical Engineering">Mechanical Engineering (ME)</option>
                        <option value="Civil Engineering">Civil Engineering (CE)</option>
                        <option value="Chemical Engineering">Chemical Engineering (CH)</option>
                      </select>
                    </motion.div>
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="password-signup">Password</Label>
                      <Input
                        id="password-signup"
                        type="password"
                        placeholder="Create a password"
                        value={formData.password}
                        onChange={(e) => setFormData(prev => ({...prev, password: e.target.value}))}
                        required
                      />
                    </motion.div>
                    
                    <motion.div className="space-y-2" variants={fieldVariants}>
                      <Label htmlFor="confirmPassword">Confirm Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm your password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData(prev => ({...prev, confirmPassword: e.target.value}))}
                        required
                      />
                    </motion.div>
                    
                    <motion.div variants={fieldVariants}>
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button type="submit" className="w-full" disabled={isLoading}>
                          {isLoading ? (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
                            />
                          ) : null}
                          {isLoading ? 'Creating Account...' : 'Create Account'}
                        </Button>
                      </motion.div>
                    </motion.div>
                  </motion.form>
                </TabsContent>
              </AnimatePresence>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}