import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  LogOut, 
  Camera, 
  BarChart3, 
  Users, 
  Settings,
  User,
  GraduationCap,
  Crown,
  Database,
  CheckSquare,
  ClipboardList,
  Clock
} from "lucide-react";
import { StudentDashboard } from "./dashboards/student-dashboard";
import { FacultyDashboard } from "./dashboards/faculty-dashboard";
import { HodDashboard } from "./dashboards/hod-dashboard";
import { PrincipalDashboard } from "./dashboards/principal-dashboard";
import { CameraAttendance } from "./camera-attendance";
import { StudentManagement } from "./student-management";
import { MarkAttendance } from "./mark-attendance";
import { ViewAttendance } from "./view-attendance";
import { AttendanceTimeoutManager } from "./attendance-timeout-manager";
import { AdministrationPanel } from "./administration-panel";

interface DashboardLayoutProps {
  userData: any;
  onLogout: () => void;
}

export function DashboardLayout({ userData, onLogout }: DashboardLayoutProps) {
  const [activeTab, setActiveTab] = useState('dashboard');

  const getInterfaceIcon = () => {
    switch(userData.interfaceType) {
      case 'student': return GraduationCap;
      case 'faculty': return User;
      case 'hod': return Users;
      case 'principal': return Crown;
      default: return User;
    }
  };

  const getInterfaceColor = () => {
    switch(userData.interfaceType) {
      case 'student': return 'bg-blue-500';
      case 'faculty': return 'bg-green-500';
      case 'hod': return 'bg-orange-500';
      case 'principal': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getInterfaceTitle = () => {
    switch(userData.interfaceType) {
      case 'student': return 'Student Portal';
      case 'faculty': return 'Faculty Portal';
      case 'hod': return 'HOD Portal';
      case 'principal': return 'Principal Portal';
      default: return 'Portal';
    }
  };

  const handleMarkAttendance = async (detectedUsers: any[]) => {
    try {
      const { supabaseService } = await import('../services/supabase-service');
      const { toast } = await import('sonner@2.0.3');
      
      if (userData.interfaceType === 'student') {
        // Mark attendance for the current student only
        const result = await supabaseService.markAttendance({
          userId: userData.id || 'current-student',
          userName: userData.fullName,
          userType: 'student',
          time: new Date().toISOString().split('T')[1].split('.')[0],
          status: 'present',
          method: 'cctv',
          markedBy: userData.fullName,
          className: userData.className || 'CS-4A',
          subject: 'Current Class'
        });
        
        if (result.error) {
          toast.error('Failed to mark attendance');
          return;
        }
        
        console.log('Student attendance marked:', result.data);
        toast.success('Attendance marked successfully!', {
          description: `Marked present at ${result.data.time}`,
        });
      } else {
        // Mark attendance for multiple students (faculty/HOD interface)
        const attendanceRecords = detectedUsers.map((user: any) => ({
          userId: user.id || `student-${Math.random().toString(36).substr(2, 9)}`,
          userName: user.name || user,
          userType: 'student',
          status: 'present' as const
        }));
        
        const result = await supabaseService.markBulkAttendance({
          attendanceRecords,
          markedBy: userData.fullName,
          className: 'CS-4A',
          subject: 'Current Class'
        });
        
        if (result.error) {
          toast.error('Failed to mark bulk attendance');
          return;
        }
        
        console.log('Batch attendance marked:', result.data);
        toast.success(`Attendance marked for ${result.data.length} students!`, {
          description: `Marked at ${new Date().toLocaleTimeString()}`,
        });
      }
      
      // Return to dashboard after marking attendance
      setTimeout(() => {
        setActiveTab('dashboard');
      }, 1000);
    } catch (error) {
      console.error('Error marking attendance:', error);
      const { toast } = await import('sonner@2.0.3');
      toast.error('Failed to mark attendance. Please try again.');
    }
  };

  const renderDashboard = () => {
    switch(userData.interfaceType) {
      case 'student':
        return <StudentDashboard userData={userData} />;
      case 'faculty':
        return <FacultyDashboard userData={userData} />;
      case 'hod':
        return <HodDashboard userData={userData} />;
      case 'principal':
        return <PrincipalDashboard userData={userData} />;
      default:
        return <div>Dashboard not available</div>;
    }
  };

  const IconComponent = getInterfaceIcon();

  // Navigation items configuration
  const getNavItems = () => {
    const baseItems = [
      { id: 'dashboard', label: 'Dashboard', icon: BarChart3 }
    ];

    if (userData.interfaceType === 'student') {
      baseItems.push(
        { id: 'view-attendance', label: 'My Attendance', icon: ClipboardList }
      );
    } else {
      baseItems.push(
        { id: 'camera-attendance', label: 'CCTV Attendance', icon: Camera },
        { id: 'mark-attendance', label: 'Mark Attendance', icon: CheckSquare },
        { id: 'management', label: 'Student Database', icon: Database },
        { id: 'timeout-manager', label: 'Timeout Manager', icon: Clock }
      );
      
      // Add Administration tab only for faculty, HOD, and principal
      if (['faculty', 'hod', 'principal'].includes(userData.interfaceType)) {
        baseItems.push(
          { id: 'administration', label: 'Administration', icon: Settings }
        );
      }
    }

    return baseItems;
  };

  // Animation variants
  const headerVariants = {
    initial: { opacity: 0, y: -20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  };

  const navVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const navItemVariants = {
    initial: { opacity: 0, y: 10 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.3
      }
    }
  };

  const contentVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    },
    exit: { 
      opacity: 0, 
      y: -20,
      transition: {
        duration: 0.3,
        ease: "easeIn"
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        className="border-b bg-card"
        variants={headerVariants}
        initial="initial"
        animate="animate"
      >
        <div className="flex items-center justify-between px-6 py-4">
          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div 
              className={`${getInterfaceColor()} w-10 h-10 rounded-full flex items-center justify-center`}
              whileHover={{ scale: 1.05, rotate: 5 }}
              whileTap={{ scale: 0.95 }}
            >
              <IconComponent className="w-6 h-6 text-white" />
            </motion.div>
            <div>
              <h1>{getInterfaceTitle()}</h1>
              <p className="text-muted-foreground">Smart Attendance Management</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Badge variant="outline" className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {userData.fullName}
              </Badge>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </motion.div>
          </motion.div>
        </div>
        
        {/* Navigation Tabs */}
        <div className="px-6">
          <motion.nav 
            className="flex space-x-8 border-b border-border"
            variants={navVariants}
            initial="initial"
            animate="animate"
          >
            {getNavItems().map((item) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  variants={navItemVariants}
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                  className={`flex items-center gap-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === item.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <motion.div
                    animate={{ 
                      rotate: activeTab === item.id ? 360 : 0,
                      scale: activeTab === item.id ? 1.1 : 1
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <Icon className="w-4 h-4" />
                  </motion.div>
                  {item.label}
                </motion.button>
              );
            })}
          </motion.nav>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            variants={contentVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            {activeTab === 'dashboard' && renderDashboard()}
            
            {activeTab === 'camera-attendance' && (
              <div className="p-6">
                <CameraAttendance 
                  onMarkAttendance={handleMarkAttendance} 
                  userType={userData.interfaceType}
                />
              </div>
            )}
            
            {activeTab === 'mark-attendance' && userData.interfaceType !== 'student' && (
              <div className="p-6">
                <MarkAttendance 
                  userData={userData}
                  userType={userData.interfaceType}
                />
              </div>
            )}
            
            {activeTab === 'management' && userData.interfaceType !== 'student' && (
              <div className="p-6">
                <StudentManagement userType={userData.interfaceType} />
              </div>
            )}
            
            {activeTab === 'view-attendance' && userData.interfaceType === 'student' && (
              <div className="p-6">
                <ViewAttendance userData={userData} />
              </div>
            )}
            
            {activeTab === 'timeout-manager' && userData.interfaceType !== 'student' && (
              <div className="p-6">
                <AttendanceTimeoutManager />
              </div>
            )}
            
            {activeTab === 'administration' && (
              <div className="p-6">
                <AdministrationPanel userData={userData} />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}