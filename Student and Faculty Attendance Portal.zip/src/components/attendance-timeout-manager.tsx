import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { Separator } from "./ui/separator";
import { ScrollArea } from "./ui/scroll-area";
import { AlertTriangle, Clock, Send, Users, Phone, User, CheckCircle } from "lucide-react";
import { supabaseService } from "../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  departmentCode: string;
  className: string;
  year: number;
  semester: number;
  guardianName: string;
  guardianPhone: string;
  isActive: boolean;
  currentStatus: 'in_class' | 'left_class' | 'on_timeout' | 'absent';
  lastActivity: string;
  timeoutStart: string | null;
  timeoutDuration: number;
  alertsSent: boolean;
  timeoutDurationPassed?: number;
  needsAlert?: boolean;
}

interface AlertLog {
  id: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  className: string;
  alertType: string;
  facultyMessage: string;
  parentMessage: string;
  parentPhone: string;
  timestamp: string;
  sentBy: string;
}

export function AttendanceTimeoutManager() {
  const [timeoutStudents, setTimeoutStudents] = useState<Student[]>([]);
  const [alertLogs, setAlertLogs] = useState<AlertLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [sendingAlert, setSendingAlert] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'timeouts' | 'alerts'>('timeouts');

  // Fetch timeout students and alert logs
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [timeoutsResult, alertsResult] = await Promise.all([
          supabaseService.getTimeoutStudents(),
          supabaseService.getAlertLogs()
        ]);

        if (timeoutsResult.data) {
          setTimeoutStudents(timeoutsResult.data);
        }

        if (alertsResult.data) {
          setAlertLogs(alertsResult.data);
        }
      } catch (error) {
        console.error('Error fetching timeout data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // Refresh data every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Send SMS alert for a student
  const handleSendAlert = async (studentId: string) => {
    setSendingAlert(studentId);
    try {
      const result = await supabaseService.sendStudentAlert(studentId, 'timeout');
      
      if (result.data) {
        toast.success('SMS alerts sent successfully', {
          description: `Notifications sent to faculty and parent for student timeout.`
        });
        
        // Update the student's alerts sent status
        setTimeoutStudents(prev => 
          prev.map(student => 
            student.id === studentId 
              ? { ...student, alertsSent: true }
              : student
          )
        );

        // Add to alert logs
        if (result.data.alertLog) {
          setAlertLogs(prev => [result.data.alertLog, ...prev]);
        }
      } else {
        throw new Error('Failed to send alerts');
      }
    } catch (error) {
      console.error('Error sending alert:', error);
      toast.error('Failed to send SMS alerts', {
        description: 'Please try again or contact system administrator.'
      });
    } finally {
      setSendingAlert(null);
    }
  };

  // Update student status (e.g., mark as returned to class)
  const handleUpdateStatus = async (studentId: string, status: string) => {
    try {
      const result = await supabaseService.updateStudentStatus(studentId, status);
      
      if (result.data) {
        toast.success('Student status updated', {
          description: `Student marked as ${status.replace('_', ' ')}.`
        });
        
        // Remove from timeout list if marked as returned to class
        if (status === 'in_class') {
          setTimeoutStudents(prev => prev.filter(student => student.id !== studentId));
        } else {
          setTimeoutStudents(prev => 
            prev.map(student => 
              student.id === studentId 
                ? { ...student, currentStatus: status as any }
                : student
            )
          );
        }
      }
    } catch (error) {
      console.error('Error updating student status:', error);
      toast.error('Failed to update student status');
    }
  };

  // Format time duration
  const formatDuration = (milliseconds: number) => {
    const minutes = Math.floor(milliseconds / (1000 * 60));
    const seconds = Math.floor((milliseconds % (1000 * 60)) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'left_class':
        return 'bg-yellow-500';
      case 'on_timeout':
        return 'bg-orange-500';
      case 'absent':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="size-5" />
            Attendance Timeout Manager
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full border-4 border-muted border-t-primary size-8"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="size-5" />
            Attendance Timeout Manager
          </CardTitle>
          <CardDescription>
            Monitor students who have left class and manage timeout alerts. 
            Automatic SMS alerts are sent to faculty and parents after 7 minutes.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Tab Navigation */}
      <div className="flex gap-2 p-1 bg-muted rounded-lg w-fit">
        <Button
          variant={activeTab === 'timeouts' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('timeouts')}
          className="flex items-center gap-2"
        >
          <AlertTriangle className="size-4" />
          Timeout Students ({timeoutStudents.length})
        </Button>
        <Button
          variant={activeTab === 'alerts' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('alerts')}
          className="flex items-center gap-2"
        >
          <Send className="size-4" />
          Alert History ({alertLogs.length})
        </Button>
      </div>

      {activeTab === 'timeouts' && (
        <div className="space-y-4">
          {timeoutStudents.length === 0 ? (
            <Alert>
              <CheckCircle className="size-4" />
              <AlertDescription>
                No students currently on timeout. All students are in class or have been accounted for.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="grid gap-4">
              {timeoutStudents.map((student) => (
                <Card key={student.id} className="border-l-4 border-l-orange-500">
                  <CardContent className="pt-4">
                    <div className="flex justify-between items-start mb-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <User className="size-4 text-muted-foreground" />
                          <span className="font-medium">{student.name}</span>
                          <Badge variant="outline">{student.rollNumber}</Badge>
                          <Badge className={getStatusColor(student.currentStatus)}>
                            {student.currentStatus.replace('_', ' ')}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {student.className} • {student.department}
                        </div>
                      </div>
                      <div className="text-right space-y-1">
                        <div className="text-sm text-muted-foreground">
                          Left class: {student.timeoutDurationPassed ? 
                            formatDuration(student.timeoutDurationPassed) + ' ago' : 
                            'Unknown'
                          }
                        </div>
                        {student.needsAlert && !student.alertsSent && (
                          <Badge variant="destructive" className="text-xs">
                            Alert Required
                          </Badge>
                        )}
                        {student.alertsSent && (
                          <Badge variant="secondary" className="text-xs">
                            Alert Sent
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="size-4 text-muted-foreground" />
                          <span>Student: {student.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Users className="size-4 text-muted-foreground" />
                          <span>Guardian: {student.guardianName}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="size-4 text-muted-foreground" />
                          <span>Guardian Phone: {student.guardianPhone}</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Timeout Duration: </span>
                          <span className="font-medium">7 minutes</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-muted-foreground">Time Elapsed: </span>
                          <span className="font-medium text-orange-600">
                            {student.timeoutDurationPassed ? 
                              formatDuration(student.timeoutDurationPassed) : 
                              'Unknown'
                            }
                          </span>
                        </div>
                      </div>
                    </div>

                    <Separator className="my-4" />

                    <div className="flex gap-2 flex-wrap">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateStatus(student.id, 'in_class')}
                        className="flex items-center gap-2"
                      >
                        <CheckCircle className="size-4" />
                        Mark as Returned
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateStatus(student.id, 'absent')}
                        className="flex items-center gap-2"
                      >
                        <AlertTriangle className="size-4" />
                        Mark as Absent
                      </Button>
                      
                      {!student.alertsSent && (
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => handleSendAlert(student.id)}
                          disabled={sendingAlert === student.id}
                          className="flex items-center gap-2"
                        >
                          <Send className="size-4" />
                          {sendingAlert === student.id ? 'Sending...' : 'Send SMS Alert'}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'alerts' && (
        <Card>
          <CardHeader>
            <CardTitle>Alert History</CardTitle>
            <CardDescription>
              View all sent SMS alerts for timeout students
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]">
              {alertLogs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No alerts sent yet
                </div>
              ) : (
                <div className="space-y-4">
                  {alertLogs.map((alert) => (
                    <Card key={alert.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <div className="font-medium">{alert.studentName}</div>
                            <div className="text-sm text-muted-foreground">
                              {alert.rollNumber} • {alert.className}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-muted-foreground">
                              {new Date(alert.timestamp).toLocaleString()}
                            </div>
                            <Badge variant="secondary" className="text-xs mt-1">
                              {alert.alertType}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <div className="text-xs font-medium text-muted-foreground mb-1">
                              Faculty Message:
                            </div>
                            <div className="text-sm bg-muted p-2 rounded">
                              {alert.facultyMessage}
                            </div>
                          </div>
                          
                          <div>
                            <div className="text-xs font-medium text-muted-foreground mb-1">
                              Parent Message ({alert.parentPhone}):
                            </div>
                            <div className="text-sm bg-muted p-2 rounded">
                              {alert.parentMessage}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}