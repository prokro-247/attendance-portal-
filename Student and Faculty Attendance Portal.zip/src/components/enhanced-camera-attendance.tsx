import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Camera, CameraOff, Check, X, Users, AlertTriangle, RefreshCw, Info, Scan, Settings } from "lucide-react";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { dbService, Student, Faculty } from "../services/database";
import { toast } from "sonner@2.0.3";

interface EnhancedCameraAttendanceProps {
  onMarkAttendance: (detectedUsers: any[]) => void;
  userType: 'student' | 'faculty' | 'hod' | 'principal';
  currentUser?: any;
}

interface DetectedUser {
  id: string;
  name: string;
  identifier: string; // Roll number or Employee ID
  confidence: number;
  type: 'student' | 'faculty';
}

export function EnhancedCameraAttendance({ onMarkAttendance, userType, currentUser }: EnhancedCameraAttendanceProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [detectedUsers, setDetectedUsers] = useState<DetectedUser[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [cameraError, setCameraError] = useState<{
    title: string;
    message: string;
    canRetry: boolean;
    showInstructions: boolean;
  } | null>(null);
  const [hasTriedCamera, setHasTriedCamera] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [availableCameras, setAvailableCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string>('');
  const [cameraSettings, setCameraSettings] = useState({
    width: { ideal: 1280 },
    height: { ideal: 720 },
    frameRate: { ideal: 30 }
  });
  const [students, setStudents] = useState<Student[]>([]);
  const [faculty, setFaculty] = useState<Faculty[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Check browser compatibility
  const checkBrowserCompatibility = useCallback(() => {
    const compatibility = {
      supported: true,
      issues: [] as string[]
    };

    if (!navigator.mediaDevices) {
      compatibility.supported = false;
      compatibility.issues.push('MediaDevices API not supported');
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      compatibility.supported = false;
      compatibility.issues.push('getUserMedia not supported');
    }

    if (location.protocol !== 'https:' && location.hostname !== 'localhost' && !location.hostname.includes('127.0.0.1')) {
      compatibility.issues.push('Camera requires HTTPS or localhost');
    }

    return compatibility;
  }, []);

  // Initialize database and load data
  useEffect(() => {
    const initializeData = async () => {
      setIsLoadingData(true);
      try {
        // Check browser compatibility
        const compatibility = checkBrowserCompatibility();
        if (!compatibility.supported) {
          toast.warning(`Browser compatibility issues: ${compatibility.issues.join(', ')}`);
        }

        await dbService.init();
        await dbService.initializeSampleData();
        
        const [studentsData, facultyData] = await Promise.all([
          dbService.getAllStudents(),
          dbService.getAllFaculty()
        ]);
        
        setStudents(studentsData);
        setFaculty(facultyData);
        toast.success("Database initialized successfully");
      } catch (error) {
        console.error('Error initializing database:', error);
        toast.error("Failed to initialize database");
      } finally {
        setIsLoadingData(false);
      }
    };

    initializeData();
  }, [checkBrowserCompatibility]);

  // Get available cameras
  useEffect(() => {
    const getAvailableCameras = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(device => device.kind === 'videoinput');
        setAvailableCameras(cameras);
        
        if (cameras.length > 0 && !selectedCamera) {
          // Prefer back camera on mobile, front camera on desktop
          const backCamera = cameras.find(camera => 
            camera.label.toLowerCase().includes('back') || 
            camera.label.toLowerCase().includes('rear')
          );
          const frontCamera = cameras.find(camera => 
            camera.label.toLowerCase().includes('front') || 
            camera.label.toLowerCase().includes('user')
          );
          
          // For attendance systems, back camera is usually better
          setSelectedCamera(backCamera?.deviceId || frontCamera?.deviceId || cameras[0].deviceId);
        }
      } catch (error) {
        console.error('Error getting cameras:', error);
      }
    };

    getAvailableCameras();
  }, [selectedCamera]);

  const getErrorMessage = useCallback((error: any) => {
    if (error.name === 'NotAllowedError') {
      return {
        title: 'Camera Permission Denied',
        message: 'Camera access was denied. Please allow camera permissions in your browser settings and refresh the page.',
        canRetry: true,
        showInstructions: true
      };
    } else if (error.name === 'NotFoundError') {
      return {
        title: 'No Camera Found',
        message: 'No camera was detected on this device. Please connect a camera or use demo mode.',
        canRetry: false,
        showInstructions: false
      };
    } else if (error.name === 'NotSupportedError') {
      return {
        title: 'Camera Not Supported',
        message: 'Camera functionality is not supported on this device or browser.',
        canRetry: false,
        showInstructions: false
      };
    } else if (error.name === 'NotReadableError') {
      return {
        title: 'Camera In Use',
        message: 'Camera is already being used by another application. Please close other apps using the camera.',
        canRetry: true,
        showInstructions: false
      };
    } else if (error.name === 'OverconstrainedError') {
      return {
        title: 'Camera Settings Issue',
        message: 'The selected camera settings are not supported. Trying with default settings.',
        canRetry: true,
        showInstructions: false
      };
    } else if (error.name === 'SecurityError') {
      return {
        title: 'Security Error',
        message: 'Camera access requires a secure connection (HTTPS) or localhost.',
        canRetry: false,
        showInstructions: true
      };
    }
    return {
      title: 'Camera Error',
      message: 'An unknown error occurred while accessing the camera.',
      canRetry: true,
      showInstructions: false
    };
  }, []);

  const requestCameraPermission = async () => {
    try {
      // First, check if we already have permission
      const permission = await navigator.permissions.query({ name: 'camera' as PermissionName });
      if (permission.state === 'granted') {
        return true;
      }
      
      // If permission is prompt, we'll get prompted when calling getUserMedia
      return permission.state !== 'denied';
    } catch (error) {
      // Permissions API not supported, proceed with getUserMedia
      return true;
    }
  };

  const startCamera = async (useBasicConstraints = false) => {
    setIsLoading(true);
    setCameraError(null);
    setHasTriedCamera(true);
    
    try {
      // Check browser support
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access is not supported on this browser.');
      }

      // Check permission status
      const hasPermission = await requestCameraPermission();
      if (!hasPermission) {
        throw { name: 'NotAllowedError', message: 'Camera permission denied' };
      }

      // Stop existing stream if any
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      // Start with basic constraints if previous attempt failed
      const constraints: MediaStreamConstraints = useBasicConstraints ? {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: { ideal: 'environment' }
        },
        audio: false
      } : {
        video: {
          ...cameraSettings,
          deviceId: selectedCamera ? { exact: selectedCamera } : undefined,
          facingMode: selectedCamera ? undefined : { ideal: 'environment' }
        },
        audio: false
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      setStream(mediaStream);
      setIsRecording(true);
      setCameraError(null);
      setIsDemoMode(false);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        
        // Wait for video to load to get actual dimensions
        videoRef.current.onloadedmetadata = () => {
          if (videoRef.current) {
            console.log(`Camera resolution: ${videoRef.current.videoWidth}x${videoRef.current.videoHeight}`);
            toast.success("Camera connected successfully");
            setIsLoading(false);
          }
        };
      } else {
        setIsLoading(false);
      }

    } catch (error: any) {
      console.error('Error accessing camera:', error);
      const errorInfo = getErrorMessage(error);
      setCameraError(errorInfo);
      setIsRecording(false);
      
      // If it's an overconstrained error, try with basic constraints
      if (error.name === 'OverconstrainedError' && !useBasicConstraints) {
        toast.info("Trying with basic camera settings...");
        setTimeout(() => {
          startCamera(true);
        }, 1000);
        return;
      }
      
      toast.error(errorInfo.title);
    } finally {
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    setIsLoading(false);
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (isDemoMode) {
      stopDemoMode();
    } else {
      setIsRecording(false);
      setDetectedUsers([]);
      setCameraError(null);
    }
    toast.info("Camera stopped");
  };

  const retryCamera = () => {
    setCameraError(null);
    setIsLoading(false);
    // Try with basic constraints on retry
    startCamera(true);
  };

  const startDemoMode = () => {
    setIsLoading(false);
    setIsDemoMode(true);
    setIsRecording(true);
    setCameraError(null);
    setHasTriedCamera(true);
    toast.info("Demo mode activated");
  };

  const stopDemoMode = () => {
    setIsLoading(false);
    setIsDemoMode(false);
    setIsRecording(false);
    setDetectedUsers([]);
  };

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return null;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    
    return canvas.toDataURL('image/jpeg', 0.8);
  }, []);

  const simulateFaceDetection = useCallback(async (): Promise<DetectedUser[]> => {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockDetectedUsers: DetectedUser[] = [];
    
    if (userType === 'student') {
      // For students, only detect themselves
      if (currentUser) {
        mockDetectedUsers.push({
          id: currentUser.id || 'current-user',
          name: currentUser.name || 'Current User',
          identifier: currentUser.rollNumber || 'N/A',
          confidence: 0.95,
          type: 'student'
        });
      }
    } else {
      // For faculty/HOD/Principal, simulate detecting multiple students
      const availableStudents = students.filter(s => s.isActive);
      const numToDetect = Math.min(Math.floor(Math.random() * 5) + 1, availableStudents.length);
      
      for (let i = 0; i < numToDetect; i++) {
        const student = availableStudents[Math.floor(Math.random() * availableStudents.length)];
        if (!mockDetectedUsers.find(u => u.id === student.id)) {
          mockDetectedUsers.push({
            id: student.id,
            name: student.name,
            identifier: student.rollNumber,
            confidence: 0.85 + Math.random() * 0.1,
            type: 'student'
          });
        }
      }

      // Sometimes detect faculty too
      if (Math.random() > 0.7 && faculty.length > 0) {
        const randomFaculty = faculty[Math.floor(Math.random() * faculty.length)];
        mockDetectedUsers.push({
          id: randomFaculty.id,
          name: randomFaculty.name,
          identifier: randomFaculty.employeeId,
          confidence: 0.90 + Math.random() * 0.05,
          type: 'faculty'
        });
      }
    }
    
    return mockDetectedUsers;
  }, [userType, currentUser, students, faculty]);

  const processAttendance = async () => {
    setIsProcessing(true);
    toast.info("Processing faces...");
    
    try {
      // Capture current frame for processing
      const frameData = captureFrame();
      
      // Simulate face detection (in real implementation, this would call AI service)
      const detected = await simulateFaceDetection();
      
      setDetectedUsers(detected);
      
      if (detected.length === 0) {
        toast.warning("No faces detected. Please ensure you're clearly visible to the camera.");
      } else {
        toast.success(`Detected ${detected.length} person(s)`);
      }
    } catch (error) {
      console.error('Error processing attendance:', error);
      toast.error("Error processing faces");
    } finally {
      setIsProcessing(false);
    }
  };

  const confirmAttendance = async () => {
    try {
      const attendanceData = [];
      const currentDate = new Date().toISOString().split('T')[0];
      const currentTime = new Date().toLocaleTimeString();

      for (const user of detectedUsers) {
        const attendanceRecord = {
          userId: user.id,
          userType: user.type,
          date: currentDate,
          timeIn: currentTime,
          status: 'present' as const,
          markedBy: currentUser?.id || 'system',
          markedByType: isDemoMode ? 'manual' : 'cctv' as const,
          location: 'Main Campus',
          notes: `Detected with ${Math.round(user.confidence * 100)}% confidence`,
          class: user.type === 'student' ? 'CS-4A' : undefined,
          subject: user.type === 'student' ? 'Current Subject' : undefined
        };

        await dbService.markAttendance(attendanceRecord);
        attendanceData.push({
          ...attendanceRecord,
          name: user.name,
          identifier: user.identifier
        });
      }

      onMarkAttendance(attendanceData);
      stopCamera();
      
      toast.success(`Attendance marked for ${detectedUsers.length} person(s)`);
    } catch (error) {
      console.error('Error marking attendance:', error);
      toast.error("Failed to mark attendance");
    }
  };

  const switchCamera = async (deviceId: string) => {
    setSelectedCamera(deviceId);
    if (isRecording && !isDemoMode) {
      // Restart camera with new device
      stopCamera();
      setTimeout(() => {
        startCamera();
      }, 500);
    }
  };

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  if (isLoadingData) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Initializing attendance system...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Enhanced CCTV Attendance System
        </CardTitle>
        <CardDescription>
          {userType === 'student' 
            ? 'Mark your attendance using facial recognition'
            : 'Monitor and mark attendance for your class using AI-powered face detection'
          }
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Camera Selection */}
        {availableCameras.length > 1 && (
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <Select value={selectedCamera} onValueChange={switchCamera}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select camera" />
              </SelectTrigger>
              <SelectContent>
                {availableCameras.map((camera) => (
                  <SelectItem key={camera.deviceId} value={camera.deviceId}>
                    {camera.label || `Camera ${camera.deviceId.slice(0, 8)}...`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Camera Error Alert */}
        {cameraError && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div className="font-medium">{cameraError.title}</div>
                <div>{cameraError.message}</div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Camera Permission Instructions */}
        {!hasTriedCamera && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <p>To mark attendance using facial recognition, you'll need to grant camera permissions.</p>
                <div className="text-sm">
                  <p><strong>What happens next:</strong></p>
                  <ol className="ml-4 list-decimal space-y-1">
                    <li>Click "Start Camera" below</li>
                    <li>Your browser will ask for camera permission</li>
                    <li>Click "Allow" when prompted</li>
                    <li>Position yourself clearly in front of the camera</li>
                  </ol>
                  <p className="mt-2 text-blue-600">
                    Or use "AI Demo Mode" to test the system without camera access.
                  </p>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Demo Mode Notice */}
        {isDemoMode && (
          <Alert className="border-blue-200 bg-blue-50">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              Demo Mode Active - This simulates the AI face recognition system using sample data from the database.
            </AlertDescription>
          </Alert>
        )}

        <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
          {isRecording ? (
            <>
              {isDemoMode ? (
                <div className="flex items-center justify-center h-full bg-gradient-to-br from-blue-400 to-blue-600 text-white">
                  <div className="text-center">
                    <Scan className="w-16 h-16 mx-auto mb-4 animate-pulse" />
                    <p className="text-lg">AI Camera Simulation</p>
                    <p className="text-sm opacity-80">Face recognition active</p>
                    <div className="mt-4 px-4 py-2 bg-white/20 rounded-lg">
                      <p className="text-xs">Connected to Database: {students.length} students, {faculty.length} faculty</p>
                    </div>
                  </div>
                </div>
              ) : (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              )}
              
              {/* Hidden canvas for frame capture */}
              <canvas
                ref={canvasRef}
                className="hidden"
              />
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <CameraOff className="w-16 h-16 mx-auto mb-4" />
                <p>Camera is not active</p>
                {cameraError && (
                  <p className="text-sm mt-2 text-red-600">Camera access failed</p>
                )}
              </div>
            </div>
          )}
          
          {isProcessing && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-4 rounded-lg text-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                <p>AI processing faces...</p>
                <p className="text-sm text-gray-600 mt-1">Analyzing facial features</p>
              </div>
            </div>
          )}
          
          {detectedUsers.length > 0 && !isProcessing && (
            <div className="absolute top-4 right-4 bg-white p-3 rounded-lg shadow-lg max-w-xs">
              <h4 className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4" />
                Detected ({detectedUsers.length})
              </h4>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {detectedUsers.map((user, index) => (
                  <Badge key={index} variant="secondary" className="block w-full text-left text-xs">
                    <Check className="w-3 h-3 mr-1" />
                    <div>
                      <div>{user.name}</div>
                      <div className="text-xs opacity-70">
                        {user.identifier} • {Math.round(user.confidence * 100)}%
                      </div>
                    </div>
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2 justify-center">
          {!isRecording ? (
            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={() => startCamera(false)} 
                className="flex items-center gap-2"
                disabled={isLoading}
              >
                <Camera className="w-4 h-4" />
                {isLoading ? 'Connecting...' : hasTriedCamera && cameraError ? 'Try Again' : 'Start Camera'}
              </Button>
              
              <Button onClick={startDemoMode} variant="outline" className="flex items-center gap-2">
                <Scan className="w-4 h-4" />
                AI Demo Mode
              </Button>
              
              {cameraError && cameraError.canRetry && (
                <Button onClick={retryCamera} variant="outline" className="flex items-center gap-2" disabled={isLoading}>
                  <RefreshCw className="w-4 h-4" />
                  {isLoading ? 'Retrying...' : 'Retry with Basic Settings'}
                </Button>
              )}
            </div>
          ) : (
            <>
              <Button 
                onClick={processAttendance} 
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                <Scan className="w-4 h-4" />
                {isProcessing ? 'Processing...' : 'Detect Faces'}
              </Button>
              
              {detectedUsers.length > 0 && (
                <Button 
                  onClick={confirmAttendance} 
                  variant="default"
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4" />
                  Mark Attendance ({detectedUsers.length})
                </Button>
              )}
              
              <Button 
                onClick={stopCamera} 
                variant="outline"
                className="flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Stop Camera
              </Button>
            </>
          )}
        </div>

        {/* System Status */}
        <div className="bg-gray-50 p-3 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Database Status:</span>
            <Badge variant="outline" className="bg-green-50 text-green-700">
              Connected • {students.length} Students • {faculty.length} Faculty
            </Badge>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>Camera Support:</span>
            <Badge variant="outline" className={
              navigator.mediaDevices && navigator.mediaDevices.getUserMedia 
                ? "bg-green-50 text-green-700" 
                : "bg-red-50 text-red-700"
            }>
              {navigator.mediaDevices && navigator.mediaDevices.getUserMedia ? 'Available' : 'Not Supported'}
            </Badge>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>Connection:</span>
            <Badge variant="outline" className={
              location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname.includes('127.0.0.1')
                ? "bg-green-50 text-green-700" 
                : "bg-amber-50 text-amber-700"
            }>
              {location.protocol === 'https:' ? 'HTTPS' : location.hostname === 'localhost' ? 'Localhost' : 'HTTP'}
            </Badge>
          </div>
        </div>

        {/* Camera Permission Help */}
        {cameraError && cameraError.showInstructions && (
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">How to enable camera permissions:</h4>
            <div className="text-sm text-blue-800 space-y-2">
              <div>
                <p><strong>Chrome/Edge/Arc:</strong></p>
                <ul className="ml-4 space-y-1 list-disc">
                  <li>Click the camera icon 🎥 in the address bar</li>
                  <li>Select "Allow" for camera access</li>
                  <li>If no icon appears, click the lock icon 🔒 → Camera → Allow</li>
                </ul>
              </div>
              <div>
                <p><strong>Firefox:</strong></p>
                <ul className="ml-4 space-y-1 list-disc">
                  <li>Click the shield icon or camera icon in the address bar</li>
                  <li>Select "Allow" for camera permissions</li>
                </ul>
              </div>
              <div>
                <p><strong>Safari:</strong></p>
                <ul className="ml-4 space-y-1 list-disc">
                  <li>Go to Safari → Settings → Websites → Camera</li>
                  <li>Set this website to "Allow"</li>
                  <li>Or click the camera icon in the address bar if available</li>
                </ul>
              </div>
              <div className="mt-3 p-2 bg-blue-100 rounded">
                <p className="font-medium">After enabling permissions:</p>
                <p>Click "Try Again" below or refresh the entire page (F5/Ctrl+R)</p>
              </div>
            </div>
          </div>
        )}

        {cameraError && cameraError.title.includes('Security') && (
          <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
            <h4 className="font-medium text-amber-900 mb-2">Secure Connection Required</h4>
            <div className="text-sm text-amber-800 space-y-2">
              <p>Camera access requires a secure connection. Please ensure you're using:</p>
              <ul className="ml-4 list-disc space-y-1">
                <li><strong>HTTPS</strong> (https://your-domain.com)</li>
                <li><strong>Localhost</strong> (http://localhost:3000)</li>
                <li><strong>Local IP with HTTPS</strong></li>
              </ul>
              <p className="mt-2">Contact your system administrator if you need help setting up HTTPS.</p>
            </div>
          </div>
        )}
        
        {detectedUsers.length > 0 && (
          <div className="mt-4 p-4 bg-green-50 rounded-lg">
            <p className="text-green-800">
              {detectedUsers.length} person(s) detected and ready for attendance marking.
              {detectedUsers.some(u => u.confidence < 0.8) && (
                <span className="block text-sm mt-1 text-amber-700">
                  Some detections have low confidence. Please ensure clear visibility.
                </span>
              )}
            </p>
          </div>
        )}

        {/* Alternative Options */}
        {cameraError && hasTriedCamera && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
            <h4 className="font-medium text-gray-900 mb-2">Alternative Options</h4>
            <p className="text-sm text-gray-700 mb-3">
              Camera not available? You can still use the attendance system:
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={startDemoMode} className="flex items-center gap-2">
                <Scan className="w-4 h-4" />
                AI Demo Mode
              </Button>
              <Button 
                onClick={async () => {
                  toast.info("Simulating face detection...");
                  const mockUsers = await simulateFaceDetection();
                  setDetectedUsers(mockUsers);
                }} 
                variant="outline"
                className="flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                Quick Detection
              </Button>
              {cameraError.canRetry && (
                <Button onClick={retryCamera} variant="outline" className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Retry Camera
                </Button>
              )}
              <Button 
                onClick={() => {
                  // Refresh the page to reset permissions
                  window.location.reload();
                }}
                variant="outline"
                className="flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh Page
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}