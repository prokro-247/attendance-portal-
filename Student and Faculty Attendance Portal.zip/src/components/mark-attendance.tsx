import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { Search, Users, Calendar, Clock, CheckCircle, XCircle, Download } from "lucide-react";
import { supabaseService } from "../services/supabase-service";
import { toast } from "sonner@2.0.3";

interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  department: string;
  className: string;
  isActive: boolean;
}

interface MarkAttendanceProps {
  userData: any;
  userType: 'faculty' | 'hod' | 'principal';
}

interface AttendanceEntry {
  studentId: string;
  status: 'present' | 'absent';
}

export function MarkAttendance({ userData, userType }: MarkAttendanceProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [attendanceEntries, setAttendanceEntries] = useState<AttendanceEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subjects = [
    "Data Structures",
    "Algorithms",
    "Database Management",
    "Operating Systems",
    "Computer Networks",
    "Software Engineering",
    "Web Development",
    "Machine Learning",
    "Artificial Intelligence",
    "Cybersecurity"
  ];

  const classes = [
    "CS-1A", "CS-1B", "CS-2A", "CS-2B", 
    "CS-3A", "CS-3B", "CS-4A", "CS-4B",
    "IT-1A", "IT-1B", "IT-2A", "IT-2B",
    "IT-3A", "IT-3B", "IT-4A", "IT-4B"
  ];

  useEffect(() => {
    loadStudents();
  }, []);

  useEffect(() => {
    filterStudents();
  }, [students, searchTerm, selectedClass]);

  useEffect(() => {
    // Initialize attendance entries when filtered students change
    setAttendanceEntries(
      filteredStudents.map(student => ({
        studentId: student.id,
        status: 'present' as const
      }))
    );
  }, [filteredStudents]);

  const loadStudents = async () => {
    try {
      setIsLoading(true);
      
      // Get all students from the backend
      const { projectId } = await import('../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-3d5883fa/students`, {
        headers: {
          'Authorization': `Bearer ${await getAccessToken()}`,
        },
      });

      if (response.ok) {
        const result = await response.json();
        setStudents(result.students || []);
      } else {
        console.warn('Backend not available, using demo students');
        setStudents(getDemoStudents());
      }
    } catch (error) {
      console.warn('Backend not available, using demo students:', error);
      // Fallback to demo data
      setStudents(getDemoStudents());
      toast.info("Backend not available - using demo data");
    } finally {
      setIsLoading(false);
    }
  };

  const getAccessToken = async () => {
    const { session } = await supabaseService.getSession();
    return session?.access_token || '';
  };

  const getDemoStudents = (): Student[] => [
    { id: 'student:CSE0001', rollNumber: 'CSE0001', name: 'Aarav Sharma', email: 'aarav.sharma@student.edu', department: 'Computer Science', className: 'CSE-4A', isActive: true },
    { id: 'student:CSE0002', rollNumber: 'CSE0002', name: 'Aditi Verma', email: 'aditi.verma@student.edu', department: 'Computer Science', className: 'CSE-4A', isActive: true },
    { id: 'student:CSE0003', rollNumber: 'CSE0003', name: 'Arjun Gupta', email: 'arjun.gupta@student.edu', department: 'Computer Science', className: 'CSE-4A', isActive: true },
    { id: 'student:CSE0004', rollNumber: 'CSE0004', name: 'Aisha Kumar', email: 'aisha.kumar@student.edu', department: 'Computer Science', className: 'CSE-4B', isActive: true },
    { id: 'student:CSE0005', rollNumber: 'CSE0005', name: 'Dhruv Singh', email: 'dhruv.singh@student.edu', department: 'Computer Science', className: 'CSE-4B', isActive: true },
    { id: 'student:CSE0006', rollNumber: 'CSE0006', name: 'Kavya Agarwal', email: 'kavya.agarwal@student.edu', department: 'Computer Science', className: 'CSE-4A', isActive: true },
    { id: 'student:CSE0007', rollNumber: 'CSE0007', name: 'Karan Jain', email: 'karan.jain@student.edu', department: 'Computer Science', className: 'CSE-4A', isActive: true },
    { id: 'student:CSE0008', rollNumber: 'CSE0008', name: 'Prisha Bansal', email: 'prisha.bansal@student.edu', department: 'Computer Science', className: 'CSE-4B', isActive: true },
    { id: 'student:IT0001', rollNumber: 'IT0001', name: 'Rohit Patel', email: 'rohit.patel@student.edu', department: 'Information Technology', className: 'IT-4A', isActive: true },
    { id: 'student:IT0002', rollNumber: 'IT0002', name: 'Sneha Yadav', email: 'sneha.yadav@student.edu', department: 'Information Technology', className: 'IT-4A', isActive: true },
    { id: 'student:IT0003', rollNumber: 'IT0003', name: 'Vivaan Mishra', email: 'vivaan.mishra@student.edu', department: 'Information Technology', className: 'IT-4B', isActive: true },
    { id: 'student:IT0004', rollNumber: 'IT0004', name: 'Riya Tripathi', email: 'riya.tripathi@student.edu', department: 'Information Technology', className: 'IT-4B', isActive: true },
  ];

  const createDemoStudents = async () => {
    try {
      const demoStudents = getDemoStudents();
      for (const student of demoStudents) {
        await supabaseService.addStudent(student);
      }
    } catch (error) {
      console.error('Error creating demo students:', error);
    }
  };

  const filterStudents = () => {
    let filtered = students.filter(student => student.isActive);

    if (searchTerm) {
      filtered = filtered.filter(student =>
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedClass) {
      filtered = filtered.filter(student => student.className === selectedClass);
    }

    setFilteredStudents(filtered);
  };

  const updateAttendanceStatus = (studentId: string, status: 'present' | 'absent') => {
    setAttendanceEntries(prev =>
      prev.map(entry =>
        entry.studentId === studentId ? { ...entry, status } : entry
      )
    );
  };

  const markAllPresent = () => {
    setAttendanceEntries(prev =>
      prev.map(entry => ({ ...entry, status: 'present' as const }))
    );
  };

  const markAllAbsent = () => {
    setAttendanceEntries(prev =>
      prev.map(entry => ({ ...entry, status: 'absent' as const }))
    );
  };

  const submitAttendance = async () => {
    if (!selectedClass || !selectedSubject) {
      toast.error("Please select both class and subject");
      return;
    }

    if (filteredStudents.length === 0) {
      toast.error("No students to mark attendance for");
      return;
    }

    try {
      setIsSubmitting(true);

      const attendanceRecords = attendanceEntries.map(entry => {
        const student = filteredStudents.find(s => s.id === entry.studentId);
        return {
          userId: entry.studentId,
          userName: student?.name || 'Unknown',
          userType: 'student',
          status: entry.status
        };
      });

      const result = await supabaseService.markBulkAttendance({
        attendanceRecords,
        markedBy: userData.fullName,
        className: selectedClass,
        subject: selectedSubject
      });

      if (result.error) {
        toast.error('Failed to mark attendance');
        return;
      }

      toast.success(`Attendance marked for ${attendanceRecords.length} students!`, {
        description: `${selectedSubject} - ${selectedClass}`,
      });

      // Reset form
      setSelectedClass("");
      setSelectedSubject("");
      setAttendanceEntries([]);
      
    } catch (error) {
      console.error('Error submitting attendance:', error);
      toast.error('Failed to mark attendance. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const exportAttendance = () => {
    const csvContent = [
      ['Roll Number', 'Name', 'Status', 'Class', 'Subject', 'Date', 'Time', 'Marked By'],
      ...attendanceEntries.map(entry => {
        const student = filteredStudents.find(s => s.id === entry.studentId);
        return [
          student?.rollNumber || '',
          student?.name || '',
          entry.status,
          selectedClass,
          selectedSubject,
          new Date().toLocaleDateString(),
          new Date().toLocaleTimeString(),
          userData.fullName
        ];
      })
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_${selectedClass}_${selectedSubject}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success("Attendance data exported successfully");
  };

  const presentCount = attendanceEntries.filter(entry => entry.status === 'present').length;
  const absentCount = attendanceEntries.filter(entry => entry.status === 'absent').length;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Loading students...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Mark Attendance
          </CardTitle>
          <CardDescription>
            Mark attendance for students by class and subject
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Class and Subject Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="class">Select Class *</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="subject">Select Subject *</Label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Session Info */}
          {selectedClass && selectedSubject && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-blue-800">
                      {new Date().toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-blue-800">
                      {new Date().toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                <div className="text-sm text-blue-800">
                  <strong>{selectedSubject}</strong> - {selectedClass}
                </div>
              </div>
            </div>
          )}

          {/* Search and Filters */}
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>

            {filteredStudents.length > 0 && (
              <div className="flex gap-2">
                <Button onClick={markAllPresent} variant="outline" size="sm">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark All Present
                </Button>
                <Button onClick={markAllAbsent} variant="outline" size="sm">
                  <XCircle className="w-4 h-4 mr-2" />
                  Mark All Absent
                </Button>
              </div>
            )}
          </div>

          {/* Attendance Summary */}
          {filteredStudents.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-gray-600">{filteredStudents.length}</div>
                <div className="text-sm text-gray-800">Total Students</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{presentCount}</div>
                <div className="text-sm text-green-800">Present</div>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{absentCount}</div>
                <div className="text-sm text-red-800">Absent</div>
              </div>
            </div>
          )}

          {/* Students Table */}
          {filteredStudents.length > 0 && (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Roll Number</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Attendance Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => {
                    const entry = attendanceEntries.find(e => e.studentId === student.id);
                    return (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.rollNumber}</TableCell>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>{student.department}</TableCell>
                        <TableCell>{student.className}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant={entry?.status === 'present' ? 'default' : 'outline'}
                              onClick={() => updateAttendanceStatus(student.id, 'present')}
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Present
                            </Button>
                            <Button
                              size="sm"
                              variant={entry?.status === 'absent' ? 'destructive' : 'outline'}
                              onClick={() => updateAttendanceStatus(student.id, 'absent')}
                            >
                              <XCircle className="w-3 h-3 mr-1" />
                              Absent
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}

          {/* No Students Message */}
          {filteredStudents.length === 0 && selectedClass && (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No students found for the selected class.</p>
              <p className="text-sm">Try selecting a different class or check the student database.</p>
            </div>
          )}

          {/* Submit Button */}
          {filteredStudents.length > 0 && (
            <div className="flex justify-between items-center pt-4 border-t">
              <Button onClick={exportAttendance} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export Attendance
              </Button>
              
              <Button 
                onClick={submitAttendance} 
                disabled={!selectedClass || !selectedSubject || isSubmitting}
                size="lg"
              >
                {isSubmitting ? 'Submitting...' : `Submit Attendance (${filteredStudents.length} students)`}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}