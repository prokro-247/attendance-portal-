import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Camera, CameraOff, Check, X, Users, AlertTriangle, RefreshCw, Info } from "lucide-react";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";

interface CameraAttendanceProps {
  onMarkAttendance: (detectedUsers: string[]) => void;
  userType: 'student' | 'faculty' | 'hod' | 'principal';
}

export function CameraAttendance({ onMarkAttendance, userType }: CameraAttendanceProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [detectedUsers, setDetectedUsers] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [hasTriedCamera, setHasTriedCamera] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Mock detected users based on user type
  const getMockDetectedUsers = () => {
    if (userType === 'student') {
      return ['Current User (John Doe)'];
    }
    return [
      'John Doe (Roll: CS001)',
      'Jane Smith (Roll: CS002)', 
      'Mike Johnson (Roll: CS003)',
      'Sarah Wilson (Roll: CS004)',
      'David Brown (Roll: CS005)'
    ];
  };

  const getErrorMessage = (error: any) => {
    if (error.name === 'NotAllowedError') {
      return 'Camera permission was denied. You can use Demo Mode instead or grant camera permissions to continue.';
    } else if (error.name === 'NotFoundError') {
      return 'No camera found on this device. Please use Demo Mode to test the attendance system.';
    } else if (error.name === 'NotSupportedError') {
      return 'Camera is not supported on this device. Please use Demo Mode instead.';
    } else if (error.name === 'NotReadableError') {
      return 'Camera is currently in use by another application. Please close other camera apps and try again.';
    } else if (error.name === 'OverconstrainedError') {
      return 'Camera settings are not supported. Please use Demo Mode instead.';
    } else if (error.name === 'SecurityError') {
      return 'Camera access requires a secure HTTPS connection. Please use Demo Mode for now.';
    }
    return 'Camera access failed. Please use Demo Mode to test the attendance system.';
  };

  const startCamera = async () => {
    setCameraError(null);
    setHasTriedCamera(true);
    
    try {
      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access is not supported on this browser.');
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }, 
        audio: false 
      });
      
      setStream(mediaStream);
      setIsRecording(true);
      setCameraError(null);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error: any) {
      console.error('Error accessing camera:', error);
      const errorMessage = getErrorMessage(error);
      setCameraError(errorMessage);
      setIsRecording(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (isDemoMode) {
      stopDemoMode();
    } else {
      setIsRecording(false);
      setDetectedUsers([]);
      setCameraError(null);
    }
  };

  const retryCamera = () => {
    setCameraError(null);
    startCamera();
  };

  const startDemoMode = () => {
    setIsDemoMode(true);
    setIsRecording(true);
    setCameraError(null);
    setHasTriedCamera(true);
  };

  const stopDemoMode = () => {
    setIsDemoMode(false);
    setIsRecording(false);
    setDetectedUsers([]);
  };

  const processAttendance = async () => {
    setIsProcessing(true);
    
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock face detection results
    const mockUsers = getMockDetectedUsers();
    setDetectedUsers(mockUsers);
    setIsProcessing(false);
  };

  const confirmAttendance = () => {
    onMarkAttendance(detectedUsers);
    stopCamera();
  };

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="w-5 h-5" />
          CCTV Attendance System
        </CardTitle>
        <CardDescription>
          {userType === 'student' 
            ? 'Mark your attendance using the camera'
            : 'Monitor and mark attendance for your class'
          }
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Camera Error Alert */}
        {cameraError && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {cameraError}
            </AlertDescription>
          </Alert>
        )}

        {/* Camera Permission Instructions */}
        {!hasTriedCamera && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              To mark attendance, you'll need to grant camera permissions. Click "Start Camera" and allow access when prompted. 
              Or use "Demo Mode" to test the system without camera access.
            </AlertDescription>
          </Alert>
        )}

        {/* Demo Mode Notice */}
        {isDemoMode && (
          <Alert className="border-blue-200 bg-blue-50">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              Demo Mode Active - This simulates the CCTV attendance system without requiring camera permissions.
            </AlertDescription>
          </Alert>
        )}

        <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
          {isRecording ? (
            <>
              {isDemoMode ? (
                <div className="flex items-center justify-center h-full bg-gradient-to-br from-blue-400 to-blue-600 text-white">
                  <div className="text-center">
                    <Camera className="w-16 h-16 mx-auto mb-4 animate-pulse" />
                    <p className="text-lg">Demo Camera Active</p>
                    <p className="text-sm opacity-80">Simulating CCTV feed</p>
                  </div>
                </div>
              ) : (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              )}
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <CameraOff className="w-16 h-16 mx-auto mb-4" />
                <p>Camera is not active</p>
                {cameraError && (
                  <p className="text-sm mt-2 text-red-600">Camera access failed</p>
                )}
              </div>
            </div>
          )}
          
          {isProcessing && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-4 rounded-lg text-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                <p>Processing faces...</p>
              </div>
            </div>
          )}
          
          {detectedUsers.length > 0 && !isProcessing && (
            <div className="absolute top-4 right-4 bg-white p-3 rounded-lg shadow-lg max-w-xs">
              <h4 className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4" />
                Detected Users
              </h4>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {detectedUsers.map((user, index) => (
                  <Badge key={index} variant="secondary" className="block w-full text-left">
                    <Check className="w-3 h-3 mr-1" />
                    {user}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2 justify-center">
          {!isRecording ? (
            <div className="flex flex-wrap gap-2">
              <Button onClick={startCamera} className="flex items-center gap-2">
                <Camera className="w-4 h-4" />
                {hasTriedCamera && cameraError ? 'Try Again' : 'Start Camera'}
              </Button>
              
              <Button onClick={startDemoMode} variant="outline" className="flex items-center gap-2">
                <Camera className="w-4 h-4" />
                Demo Mode
              </Button>
              
              {cameraError && (
                <Button onClick={retryCamera} variant="outline" className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Retry
                </Button>
              )}
            </div>
          ) : (
            <>
              <Button 
                onClick={processAttendance} 
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                {isProcessing ? 'Processing...' : 'Detect Faces'}
              </Button>
              
              {detectedUsers.length > 0 && (
                <Button 
                  onClick={confirmAttendance} 
                  variant="default"
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4" />
                  Mark Attendance ({detectedUsers.length})
                </Button>
              )}
              
              <Button 
                onClick={stopCamera} 
                variant="outline"
                className="flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Stop Camera
              </Button>
            </>
          )}
        </div>

        {/* Camera Permission Help */}
        {cameraError && cameraError.includes('denied') && (
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">How to enable camera permissions:</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p><strong>Chrome/Edge:</strong> Click the camera icon in the address bar, then "Allow"</p>
              <p><strong>Firefox:</strong> Click the shield icon, then "Allow" for camera</p>
              <p><strong>Safari:</strong> Go to Settings → Websites → Camera → Allow for this site</p>
              <p className="mt-2">After enabling permissions, click "Try Again" or refresh the page.</p>
            </div>
          </div>
        )}

        {cameraError && cameraError.includes('HTTPS') && (
          <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
            <h4 className="font-medium text-amber-900 mb-2">Secure Connection Required</h4>
            <p className="text-sm text-amber-800">
              Camera access requires a secure HTTPS connection. Please ensure you're accessing this page over HTTPS or localhost.
            </p>
          </div>
        )}
        
        {detectedUsers.length > 0 && (
          <div className="mt-4 p-4 bg-green-50 rounded-lg">
            <p className="text-green-800">
              {detectedUsers.length} user(s) detected and ready for attendance marking.
            </p>
          </div>
        )}

        {/* Alternative Options */}
        {cameraError && hasTriedCamera && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
            <h4 className="font-medium text-gray-900 mb-2">Alternative Options</h4>
            <p className="text-sm text-gray-700 mb-3">
              Camera not available? Try these alternatives:
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={startDemoMode} className="flex items-center gap-2">
                <Camera className="w-4 h-4" />
                Try Demo Mode
              </Button>
              <Button 
                onClick={() => {
                  // Simulate manual attendance marking
                  const mockUsers = getMockDetectedUsers();
                  onMarkAttendance(mockUsers);
                }} 
                variant="outline"
                className="flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Mark Present (Manual)
              </Button>
              <Button onClick={retryCamera} variant="outline" className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4" />
                Retry Camera
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}