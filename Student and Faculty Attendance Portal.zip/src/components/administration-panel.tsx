import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { 
  Users, 
  FileText, 
  Download, 
  Upload, 
  Database, 
  Settings, 
  Shield, 
  AlertCircle,
  Clock,
  MessageSquare,
  BarChart3,
  FileSpreadsheet,
  Archive,
  Trash2,
  UserPlus,
  Search,
  Filter
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner@2.0.3";

interface AdministrationPanelProps {
  userData: any;
}

export function AdministrationPanel({ userData }: AdministrationPanelProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [bulkActionType, setBulkActionType] = useState("");

  // Mock data for administrative functions
  const systemStats = {
    totalStudents: 360,
    activeStudents: 342,
    totalFaculty: 45,
    totalDepartments: 12,
    lowAttendanceAlerts: 23,
    timeoutStudents: 8,
    systemUptime: "99.8%",
    lastBackup: "2024-01-15 02:30 AM"
  };

  const departments = [
    'Computer Science', 'Computer Science & Machine Learning', 'Computer Science & Data Science',
    'Information Technology', 'Internet of Things', 'Electronics & Communication Engineering',
    'Electrical & Electronics Engineering', 'Mechanical Engineering', 'Civil Engineering',
    'Chemical Engineering', 'Biotechnology', 'Computer Applications'
  ];

  const handleGenerateReport = async (reportType: string) => {
    setIsLoading(true);
    try {
      // Simulate report generation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const reportData = {
        attendance: {
          fileName: 'attendance-report-2024.xlsx',
          description: 'Comprehensive attendance report for all students and faculty'
        },
        analytics: {
          fileName: 'analytics-dashboard-2024.pdf',
          description: 'Detailed analytics and performance metrics'
        },
        timeout: {
          fileName: 'timeout-alerts-2024.csv',
          description: 'Student timeout incidents and alert logs'
        },
        department: {
          fileName: 'department-summary-2024.xlsx',
          description: 'Department-wise attendance and performance summary'
        }
      };

      const report = reportData[reportType] || reportData.attendance;
      
      // Create a mock file blob
      const blob = new Blob([`Mock ${reportType} report data`], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = report.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success("Report Generated Successfully", {
        description: `${report.description} has been downloaded.`
      });
    } catch (error) {
      toast.error("Failed to generate report");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDatabaseBackup = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Create mock backup file
      const backupData = {
        timestamp: new Date().toISOString(),
        students: systemStats.totalStudents,
        faculty: systemStats.totalFaculty,
        version: "1.0.0"
      };
      
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `database-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success("Database Backup Completed", {
        description: "Full system backup has been downloaded successfully."
      });
    } catch (error) {
      toast.error("Database backup failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDataImport = async (file: File) => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.success("Data Import Successful", {
        description: `Imported data from ${file.name}. ${Math.floor(Math.random() * 50) + 10} records processed.`
      });
    } catch (error) {
      toast.error("Data import failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBulkAction = async (action: string) => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const actions = {
        'reset-passwords': 'Password reset emails sent to selected users',
        'update-status': 'User status updated for selected accounts',
        'send-notification': 'Bulk notification sent successfully',
        'export-data': 'Selected data exported to Excel file'
      };
      
      toast.success("Bulk Action Completed", {
        description: actions[action] || 'Bulk operation completed successfully'
      });
    } catch (error) {
      toast.error("Bulk action failed");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Administration Panel</h1>
          <p className="text-muted-foreground">Manage system settings, users, and data</p>
        </div>
        <Badge variant="outline" className="flex items-center gap-2">
          <Shield className="w-4 h-4" />
          Admin Access
        </Badge>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              {systemStats.activeStudents} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faculty Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.totalFaculty}</div>
            <p className="text-xs text-muted-foreground">
              Across {systemStats.totalDepartments} departments
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Alerts</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{systemStats.lowAttendanceAlerts}</div>
            <p className="text-xs text-muted-foreground">
              Low attendance alerts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{systemStats.systemUptime}</div>
            <p className="text-xs text-muted-foreground">
              Uptime this month
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="reports" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="settings">System Settings</TabsTrigger>
          <TabsTrigger value="alerts">Alert System</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Generate Reports
              </CardTitle>
              <CardDescription>
                Create comprehensive reports for attendance, analytics, and system data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button
                  onClick={() => handleGenerateReport('attendance')}
                  disabled={isLoading}
                  className="flex items-center gap-2 h-20 flex-col"
                >
                  <FileSpreadsheet className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium">Attendance Report</div>
                    <div className="text-xs opacity-80">Excel format</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleGenerateReport('analytics')}
                  disabled={isLoading}
                  variant="outline"
                  className="flex items-center gap-2 h-20 flex-col"
                >
                  <BarChart3 className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium">Analytics Dashboard</div>
                    <div className="text-xs opacity-80">PDF format</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleGenerateReport('timeout')}
                  disabled={isLoading}
                  variant="outline"
                  className="flex items-center gap-2 h-20 flex-col"
                >
                  <Clock className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium">Timeout Alerts</div>
                    <div className="text-xs opacity-80">CSV format</div>
                  </div>
                </Button>

                <Button
                  onClick={() => handleGenerateReport('department')}
                  disabled={isLoading}
                  variant="outline"
                  className="flex items-center gap-2 h-20 flex-col"
                >
                  <Users className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium">Department Summary</div>
                    <div className="text-xs opacity-80">Excel format</div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="w-5 h-5" />
                  Database Management
                </CardTitle>
                <CardDescription>
                  Backup, restore, and manage system data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div>
                    <div className="font-medium">Last Backup</div>
                    <div className="text-sm text-muted-foreground">{systemStats.lastBackup}</div>
                  </div>
                  <Button
                    onClick={handleDatabaseBackup}
                    disabled={isLoading}
                    className="flex items-center gap-2"
                  >
                    <Archive className="w-4 h-4" />
                    Create Backup
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="import-file">Import Data</Label>
                    <Input
                      id="import-file"
                      type="file"
                      accept=".json,.csv,.xlsx"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleDataImport(file);
                      }}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Quick Actions</Label>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Export All
                      </Button>
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4 mr-2" />
                        Optimize
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                User Management
              </CardTitle>
              <CardDescription>
                Manage student and faculty accounts, perform bulk operations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full"
                  />
                </div>
                <select
                  className="border rounded-md px-3 py-2"
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                >
                  <option value="">All Departments</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
                <Button variant="outline">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>

              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-sm font-medium">Bulk Actions</div>
                  <div className="text-sm text-muted-foreground">0 users selected</div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleBulkAction('reset-passwords')}
                    disabled={isLoading}
                  >
                    Reset Passwords
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleBulkAction('update-status')}
                    disabled={isLoading}
                  >
                    Update Status
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleBulkAction('send-notification')}
                    disabled={isLoading}
                  >
                    Send Notification
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleBulkAction('export-data')}
                    disabled={isLoading}
                  >
                    Export Selected
                  </Button>
                </div>
              </div>

              <div className="text-center py-8 text-muted-foreground">
                <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>User management interface would display here</p>
                <p className="text-sm">Use search and filters to find specific users</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                System Settings
              </CardTitle>
              <CardDescription>
                Configure system parameters and application settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-base font-medium">Attendance Settings</Label>
                  <div className="mt-2 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Timeout Duration (minutes)</span>
                      <Input type="number" defaultValue="7" className="w-20" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Minimum Attendance Percentage</span>
                      <Input type="number" defaultValue="75" className="w-20" />
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium">Notification Settings</Label>
                  <div className="mt-2 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">SMS Alert Number</span>
                      <Input defaultValue="+916302694381" className="w-40" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Email Notifications</span>
                      <Button variant="outline" size="sm">Configure</Button>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium">System Preferences</Label>
                  <div className="mt-2 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Auto Backup Frequency</span>
                      <select className="border rounded-md px-3 py-1">
                        <option>Daily</option>
                        <option>Weekly</option>
                        <option>Monthly</option>
                      </select>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Session Timeout (hours)</span>
                      <Input type="number" defaultValue="8" className="w-20" />
                    </div>
                  </div>
                </div>

                <Button className="w-full">
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Alert Management System
              </CardTitle>
              <CardDescription>
                Monitor and manage system alerts, notifications, and timeout incidents
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-orange-200 bg-orange-50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <div>
                        <div className="font-medium">Timeout Alerts</div>
                        <div className="text-2xl font-bold text-orange-600">{systemStats.timeoutStudents}</div>
                        <div className="text-xs text-muted-foreground">Active incidents</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-red-200 bg-red-50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <div>
                        <div className="font-medium">Low Attendance</div>
                        <div className="text-2xl font-bold text-red-600">{systemStats.lowAttendanceAlerts}</div>
                        <div className="text-xs text-muted-foreground">Students below 75%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-blue-200 bg-blue-50">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-medium">SMS Sent</div>
                        <div className="text-2xl font-bold text-blue-600">127</div>
                        <div className="text-xs text-muted-foreground">This week</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Recent Alert Activity</h3>
                  <Button variant="outline" size="sm">View All Logs</Button>
                </div>
                
                <div className="space-y-2">
                  {[
                    { type: 'timeout', student: 'Arjun Sharma', class: 'CSE-4A', time: '2 mins ago' },
                    { type: 'attendance', student: 'Priya Singh', class: 'IT-3B', time: '15 mins ago' },
                    { type: 'timeout', student: 'Rahul Gupta', class: 'ECE-2A', time: '1 hour ago' },
                  ].map((alert, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          alert.type === 'timeout' ? 'bg-orange-500' : 'bg-red-500'
                        }`} />
                        <div>
                          <div className="font-medium">{alert.student}</div>
                          <div className="text-sm text-muted-foreground">
                            {alert.class} • {alert.type === 'timeout' ? 'Timeout Alert' : 'Low Attendance'}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">{alert.time}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}