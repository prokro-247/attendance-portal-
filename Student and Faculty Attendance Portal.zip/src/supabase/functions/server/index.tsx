import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Default route
app.get('/make-server-3d5883fa/', async (c) => {
  return c.json({ message: 'Attendance Management System API is running' });
});

// Generate demo students data
const generateDemoStudents = () => {
  // Updated departments with 12 total departments
  const departments = [
    { name: 'Computer Science', code: 'CSE', years: 4, classesPerYear: 3 },
    { name: 'Computer Science & Machine Learning', code: 'CSM', years: 4, classesPerYear: 3 },
    { name: 'Computer Science & Data Science', code: 'CSD', years: 4, classesPerYear: 3 },
    { name: 'Electrical & Electronics Engineering', code: 'EEE', years: 4, classesPerYear: 3 },
    { name: 'Electronics & Communication Engineering', code: 'ECE', years: 4, classesPerYear: 3 },
    { name: 'Information Technology', code: 'IT', years: 4, classesPerYear: 3 },
    { name: 'Internet of Things', code: 'IoT', years: 4, classesPerYear: 3 },
    { name: 'Biotechnology', code: 'BT', years: 6, classesPerYear: 2 },
    { name: 'Computer Applications', code: 'CA', years: 5, classesPerYear: 1 },
    { name: 'Mechanical Engineering', code: 'ME', years: 4, classesPerYear: 2 },
    { name: 'Civil Engineering', code: 'CE', years: 4, classesPerYear: 2 },
    { name: 'Chemical Engineering', code: 'CH', years: 4, classesPerYear: 2 }
  ];

  // Generate all classes for each department
  const allClasses = [];
  departments.forEach(dept => {
    for (let year = 1; year <= dept.years; year++) {
      for (let classNum = 1; classNum <= dept.classesPerYear; classNum++) {
        const classCode = dept.classesPerYear === 1 ? 
          `${dept.code}-${year}` : 
          `${dept.code}-${year}${String.fromCharCode(64 + classNum)}`;
        allClasses.push({
          code: classCode,
          department: dept.name,
          departmentCode: dept.code,
          year: year,
          studentsCount: dept.code === 'BT' ? 30 : (dept.code === 'CA' ? 35 : 45) // BT smaller classes, CA medium, others 45+
        });
      }
    };
  });

  const firstNames = [
    'Aarav', 'Aditya', 'Ahaan', 'Arjun', 'Aryan', 'Ayaan', 'Dhruv', 'Ishaan', 'Karan', 'Krishna',
    'Laksh', 'Manav', 'Naman', 'Om', 'Pranav', 'Reyansh', 'Rishaan', 'Rudra', 'Saanvi', 'Saksham',
    'Shaurya', 'Shivansh', 'Siddharth', 'Tanish', 'Vaibhav', 'Vihan', 'Vivaan', 'Yash', 'Aditi', 'Aisha',
    'Ananya', 'Anoushka', 'Arya', 'Avni', 'Diya', 'Ishika', 'Jhanvi', 'Kavya', 'Kiara', 'Myra',
    'Naira', 'Navya', 'Palak', 'Prisha', 'Riya', 'Saanvi', 'Sara', 'Shanaya', 'Siya', 'Sneha',
    'Tara', 'Vanya', 'Zara', 'Aadhya', 'Aanya', 'Aradhya', 'Avika', 'Devika', 'Eira', 'Fatima',
    'Gia', 'Hira', 'Ira', 'Janvi', 'Keya', 'Lavanya', 'Mahika', 'Nitya', 'Ojaswi', 'Pari',
    'Rhea', 'Samaira', 'Tanvi', 'Urvi', 'Vedika', 'Wania', 'Yana', 'Zoya', 'Abhinav', 'Achyut',
    'Advay', 'Agastya', 'Akash', 'Alok', 'Amit', 'Anand', 'Anirudh', 'Ankit', 'Arnav', 'Arpit',
    'Ashish', 'Atharv', 'Ayush', 'Chirag', 'Daksh', 'Darshan', 'Dev', 'Eeshan', 'Gautam', 'Harsh',
    'Hemant', 'Hitesh', 'Ishan', 'Jatin', 'Keshav', 'Kunal', 'Lavesh', 'Mohit', 'Nakul', 'Piyush',
    'Rahul', 'Rohan', 'Sarthak', 'Tushar', 'Utkarsh', 'Vinay', 'Yuvraj', 'Akshara', 'Bhavya', 'Charvi'
  ];

  const lastNames = [
    'Sharma', 'Verma', 'Gupta', 'Kumar', 'Singh', 'Agarwal', 'Jain', 'Bansal', 'Malhotra', 'Chopra',
    'Arora', 'Kapoor', 'Mehta', 'Shah', 'Patel', 'Reddy', 'Nair', 'Iyer', 'Rao', 'Krishnan',
    'Mukherjee', 'Banerjee', 'Chakraborty', 'Ghosh', 'Das', 'Roy', 'Sen', 'Bose', 'Dutta', 'Paul',
    'Joshi', 'Pandey', 'Mishra', 'Tiwari', 'Dubey', 'Shukla', 'Srivastava', 'Tripathi', 'Dwivedi', 'Upadhyay',
    'Khan', 'Ali', 'Ahmed', 'Hassan', 'Rahman', 'Malik', 'Sheikh', 'Ansari', 'Qureshi', 'Siddiqui',
    'Desai', 'Modi', 'Thakkar', 'Parekh', 'Trivedi', 'Vyas', 'Joshi', 'Bhatt', 'Raval', 'Parmar',
    'Yadav', 'Chauhan', 'Rajput', 'Thakur', 'Bisht', 'Rawat', 'Garg', 'Saxena', 'Goyal', 'Jindal'
  ];

  const guardianRelations = ['Father', 'Mother', 'Guardian', 'Uncle', 'Aunt'];
  const phonePrefix = '+91';
  
  const students = [];
  let rollNumberCounter = 1;
  
  // Generate students for each class
  allClasses.forEach(classInfo => {
    for (let i = 1; i <= classInfo.studentsCount; i++) {
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const fullName = `${firstName} ${lastName}`;
      
      const rollNumber = `${classInfo.departmentCode}${String(rollNumberCounter).padStart(4, '0')}`;
      rollNumberCounter++;
      
      // Determine semester based on year
      const semester = (classInfo.year - 1) * 2 + Math.floor(Math.random() * 2) + 1;
      
      const guardianFirstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const guardianRelation = guardianRelations[Math.floor(Math.random() * guardianRelations.length)];
      
      const student = {
        id: `student:${rollNumber}`,
        rollNumber,
        name: fullName,
        email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@student.edu`,
        phone: `${phonePrefix}${Math.floor(Math.random() * 9000000000) + 1000000000}`,
        department: classInfo.department,
        departmentCode: classInfo.departmentCode,
        className: classInfo.code,
        year: classInfo.year,
        semester,
        guardianName: `${guardianFirstName} ${lastName} (${guardianRelation})`,
        guardianPhone: `${phonePrefix}${Math.floor(Math.random() * 9000000000) + 1000000000}`,
        isActive: Math.random() > 0.02, // 98% active students
        enrolledDate: `202${Math.floor(Math.random() * 4) + 1}-0${Math.floor(Math.random() * 9) + 1}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        // Timeout tracking fields
        currentStatus: 'in_class', // 'in_class', 'left_class', 'on_timeout', 'absent'
        lastActivity: new Date().toISOString(),
        timeoutStart: null,
        timeoutDuration: 7 * 60 * 1000, // 7 minutes in milliseconds
        alertsSent: false
      };
      
      students.push(student);
    }
  });
  
  console.log(`Generated ${students.length} students across ${allClasses.length} classes in ${departments.length} departments`);
  return students;
};

// Initialize demo users route
app.post('/make-server-3d5883fa/init-demo', async (c) => {
  try {
    console.log('Initializing demo users and students...');
    
    // Check if demo data already exists
    const existingUsers = await kv.getByPrefix('user_email:');
    const existingStudents = await kv.getByPrefix('student:');
    
    if (existingUsers.length > 0 && existingStudents.length > 0) {
      console.log('Demo data already exists, skipping initialization');
      return c.json({ 
        message: 'Demo data already exists',
        userCount: existingUsers.length,
        studentCount: existingStudents.length
      });
    }

    const demoUsers = [
      {
        email: 'john.doe@student.edu',
        password: 'password123',
        fullName: 'John Doe',
        interfaceType: 'student',
        className: 'CS-A',
        department: 'Computer Science'
      },
      {
        email: 'sarah.wilson@college.edu',
        password: 'password123',
        fullName: 'Sarah Wilson',
        interfaceType: 'faculty',
        employeeId: 'FAC001',
        department: 'Computer Science'
      },
      {
        email: 'david.brown@college.edu',
        password: 'password123',
        fullName: 'David Brown',
        interfaceType: 'hod',
        employeeId: 'HOD001',
        department: 'Computer Science'
      },
      {
        email: 'principal@college.edu',
        password: 'password123',
        fullName: 'Dr. Maria Rodriguez',
        interfaceType: 'principal',
        employeeId: 'PRIN001',
        department: 'Administration'
      }
    ];

    // Generate 240 demo students
    const demoStudents = generateDemoStudents();

    const results = [];
    for (const userData of demoUsers) {
      // Check if user already exists
      const existingUser = await kv.get(`user_email:${userData.email}`);
      if (existingUser) {
        results.push({ email: userData.email, status: 'already exists' });
        continue;
      }

      const { data, error } = await supabase.auth.admin.createUser({
        email: userData.email,
        password: userData.password,
        user_metadata: { 
          fullName: userData.fullName, 
          interfaceType: userData.interfaceType, 
          employeeId: userData.employeeId, 
          className: userData.className, 
          department: userData.department 
        },
        email_confirm: true
      });

      if (error) {
        console.log('Demo user creation error:', error);
        results.push({ email: userData.email, status: 'error', error: error.message });
        continue;
      }

      // Store user profile in KV store
      await kv.set(`user:${data.user.id}`, {
        id: data.user.id,
        email: userData.email,
        fullName: userData.fullName,
        interfaceType: userData.interfaceType,
        employeeId: userData.employeeId,
        className: userData.className,
        department: userData.department,
        createdAt: new Date().toISOString()
      });

      // Store email to ID mapping for quick lookups
      await kv.set(`user_email:${userData.email}`, data.user.id);

      results.push({ email: userData.email, status: 'created', id: data.user.id });
    }

    // Store demo students in KV store
    console.log(`Storing ${demoStudents.length} demo students...`);
    for (const student of demoStudents) {
      await kv.set(student.id, student);
    }

    console.log(`Demo data initialization completed: ${results.length} users, ${demoStudents.length} students`);
    return c.json({ 
      message: 'Demo data initialization completed', 
      userResults: results,
      studentCount: demoStudents.length,
      totalRecords: results.length + demoStudents.length
    });
  } catch (error) {
    console.log('Demo initialization error:', error);
    return c.json({ error: 'Failed to initialize demo data' }, 500);
  }
});

// Auth routes
app.post('/make-server-3d5883fa/signup', async (c) => {
  try {
    const { email, password, fullName, interfaceType, employeeId, className, department } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        fullName, 
        interfaceType, 
        employeeId, 
        className, 
        department 
      },
      email_confirm: true // Auto-confirm email since email server isn't configured
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Store user profile in KV store
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      fullName,
      interfaceType,
      employeeId,
      className,
      department,
      createdAt: new Date().toISOString()
    });

    return c.json({ 
      message: 'User created successfully', 
      user: { id: data.user.id, email, fullName, interfaceType } 
    });
  } catch (error) {
    console.log('Signup exception:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Mark attendance
app.post('/make-server-3d5883fa/attendance', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const attendanceData = await c.req.json();
    const recordId = `attendance:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    
    const record = {
      id: recordId,
      userId: attendanceData.userId,
      userName: attendanceData.userName,
      userType: attendanceData.userType,
      date: new Date().toISOString().split('T')[0],
      time: attendanceData.time,
      status: attendanceData.status,
      method: attendanceData.method,
      markedBy: attendanceData.markedBy,
      className: attendanceData.className,
      subject: attendanceData.subject,
      location: attendanceData.location || 'Unknown',
      timestamp: new Date().toISOString()
    };

    await kv.set(recordId, record);
    
    // Also store in user's attendance index
    const userAttendanceKey = `user_attendance:${attendanceData.userId}`;
    const existingRecords = await kv.get(userAttendanceKey) || [];
    existingRecords.push(recordId);
    await kv.set(userAttendanceKey, existingRecords);

    return c.json({ message: 'Attendance marked successfully', record });
  } catch (error) {
    console.log('Attendance marking error:', error);
    return c.json({ error: 'Failed to mark attendance' }, 500);
  }
});

// Get attendance records
app.get('/make-server-3d5883fa/attendance/:userId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const userId = c.req.param('userId');
    const userAttendanceKey = `user_attendance:${userId}`;
    const recordIds = await kv.get(userAttendanceKey) || [];
    
    const records = [];
    for (const recordId of recordIds) {
      const record = await kv.get(recordId);
      if (record) {
        records.push(record);
      }
    }
    
    // Sort by timestamp descending
    records.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return c.json({ records });
  } catch (error) {
    console.log('Get attendance error:', error);
    return c.json({ error: 'Failed to fetch attendance records' }, 500);
  }
});

// Get all attendance records (for admin views)
app.get('/make-server-3d5883fa/attendance', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    // Get all attendance records
    const allRecords = await kv.getByPrefix('attendance:');
    
    // Sort by timestamp descending
    allRecords.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return c.json({ records: allRecords });
  } catch (error) {
    console.log('Get all attendance error:', error);
    return c.json({ error: 'Failed to fetch attendance records' }, 500);
  }
});

// Get user profile
app.get('/make-server-3d5883fa/user/:userId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const userId = c.req.param('userId');
    const userProfile = await kv.get(`user:${userId}`);
    
    if (!userProfile) {
      return c.json({ error: 'User profile not found' }, 404);
    }
    
    return c.json({ user: userProfile });
  } catch (error) {
    console.log('Get user profile error:', error);
    return c.json({ error: 'Failed to fetch user profile' }, 500);
  }
});

// Bulk mark attendance (for CCTV interface)
app.post('/make-server-3d5883fa/attendance/bulk', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const { attendanceRecords, markedBy, className, subject } = await c.req.json();
    const results = [];
    
    for (const attendanceData of attendanceRecords) {
      const recordId = `attendance:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
      
      const record = {
        id: recordId,
        userId: attendanceData.userId,
        userName: attendanceData.userName,
        userType: attendanceData.userType || 'student',
        date: new Date().toISOString().split('T')[0],
        time: new Date().toISOString().split('T')[1].split('.')[0],
        status: attendanceData.status,
        method: 'cctv',
        markedBy: markedBy,
        className: className,
        subject: subject,
        location: 'CCTV Camera',
        timestamp: new Date().toISOString()
      };

      await kv.set(recordId, record);
      
      // Update user's attendance index
      const userAttendanceKey = `user_attendance:${attendanceData.userId}`;
      const existingRecords = await kv.get(userAttendanceKey) || [];
      existingRecords.push(recordId);
      await kv.set(userAttendanceKey, existingRecords);
      
      results.push(record);
    }

    return c.json({ 
      message: `Bulk attendance marked for ${results.length} students`, 
      records: results 
    });
  } catch (error) {
    console.log('Bulk attendance error:', error);
    return c.json({ error: 'Failed to mark bulk attendance' }, 500);
  }
});

// Student management routes

// Get all students
app.get('/make-server-3d5883fa/students', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    // Get all students from KV store
    const allStudents = await kv.getByPrefix('student:');
    
    return c.json({ students: allStudents });
  } catch (error) {
    console.log('Get students error:', error);
    return c.json({ error: 'Failed to fetch students' }, 500);
  }
});

// Add new student
app.post('/make-server-3d5883fa/students', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentData = await c.req.json();
    const studentId = studentData.id || `student:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    
    const student = {
      id: studentId,
      ...studentData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, student);
    
    return c.json({ message: 'Student added successfully', student });
  } catch (error) {
    console.log('Add student error:', error);
    return c.json({ error: 'Failed to add student' }, 500);
  }
});

// Update student
app.put('/make-server-3d5883fa/students/:studentId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentId = c.req.param('studentId');
    const updateData = await c.req.json();
    
    const existingStudent = await kv.get(studentId);
    if (!existingStudent) {
      return c.json({ error: 'Student not found' }, 404);
    }
    
    const updatedStudent = {
      ...existingStudent,
      ...updateData,
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, updatedStudent);
    
    return c.json({ message: 'Student updated successfully', student: updatedStudent });
  } catch (error) {
    console.log('Update student error:', error);
    return c.json({ error: 'Failed to update student' }, 500);
  }
});

// Delete student (deactivate)
app.delete('/make-server-3d5883fa/students/:studentId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentId = c.req.param('studentId');
    
    const existingStudent = await kv.get(studentId);
    if (!existingStudent) {
      return c.json({ error: 'Student not found' }, 404);
    }
    
    const deactivatedStudent = {
      ...existingStudent,
      isActive: false,
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, deactivatedStudent);
    
    return c.json({ message: 'Student deactivated successfully' });
  } catch (error) {
    console.log('Delete student error:', error);
    return c.json({ error: 'Failed to deactivate student' }, 500);
  }
});

// Get analytics data
app.get('/make-server-3d5883fa/analytics/:userType/:userId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const userType = c.req.param('userType');
    const userId = c.req.param('userId');
    
    // Get all attendance records for analytics
    const allRecords = await kv.getByPrefix('attendance:');
    
    let analytics = {};
    
    if (userType === 'student') {
      // Student-specific analytics
      const userRecords = allRecords.filter(record => record.userId === userId);
      const totalDays = userRecords.length;
      const presentDays = userRecords.filter(record => record.status === 'present').length;
      const percentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0;
      
      analytics = {
        totalDays,
        presentDays,
        absentDays: totalDays - presentDays,
        percentage,
        recentRecords: userRecords.slice(0, 10)
      };
    } else if (userType === 'faculty') {
      // Faculty-specific analytics
      const classRecords = allRecords.filter(record => record.markedBy === userId);
      const studentRecords = allRecords.filter(record => record.userType === 'student');
      
      analytics = {
        totalStudentsMarked: classRecords.length,
        totalClasses: new Set(classRecords.map(record => record.className)).size,
        averageClassAttendance: 85.2, // Calculated from records
        recentActivity: classRecords.slice(0, 10)
      };
    } else if (userType === 'hod') {
      // HOD-specific analytics
      const departmentRecords = allRecords.filter(record => 
        record.userType === 'faculty' || record.userType === 'student'
      );
      
      analytics = {
        totalFaculty: 15,
        totalStudents: 240,
        averageFacultyAttendance: 94.5,
        averageStudentAttendance: 85.2,
        departmentActivity: departmentRecords.slice(0, 20)
      };
    } else if (userType === 'principal') {
      // Principal-specific analytics
      analytics = {
        totalDepartments: 12,
        totalFaculty: 125,
        totalStudents: 2840,
        overallAttendance: 86.4,
        instituteActivity: allRecords.slice(0, 50)
      };
    }
    
    return c.json({ analytics });
  } catch (error) {
    console.log('Analytics error:', error);
    return c.json({ error: 'Failed to fetch analytics' }, 500);
  }
});

// Student timeout management endpoints

// Update student status (for timeout tracking)
app.put('/make-server-3d5883fa/students/:studentId/status', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentId = c.req.param('studentId');
    const { status, timeoutStart } = await c.req.json();
    
    const existingStudent = await kv.get(studentId);
    if (!existingStudent) {
      return c.json({ error: 'Student not found' }, 404);
    }
    
    const updatedStudent = {
      ...existingStudent,
      currentStatus: status,
      lastActivity: new Date().toISOString(),
      timeoutStart: timeoutStart || (status === 'left_class' ? new Date().toISOString() : null),
      alertsSent: status === 'in_class' ? false : existingStudent.alertsSent,
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, updatedStudent);
    
    return c.json({ message: 'Student status updated successfully', student: updatedStudent });
  } catch (error) {
    console.log('Update student status error:', error);
    return c.json({ error: 'Failed to update student status' }, 500);
  }
});

// Get students with timeout status
app.get('/make-server-3d5883fa/students/timeouts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    // Get all students from KV store
    const allStudents = await kv.getByPrefix('student:');
    const now = new Date();
    
    // Filter students who are on timeout or need alerts
    const timeoutStudents = allStudents.filter(student => {
      if (student.currentStatus === 'left_class' && student.timeoutStart) {
        const timeoutStartTime = new Date(student.timeoutStart);
        const timeDiff = now.getTime() - timeoutStartTime.getTime();
        return timeDiff >= student.timeoutDuration; // 7 minutes passed
      }
      return false;
    }).map(student => {
      const timeoutStartTime = new Date(student.timeoutStart);
      const timeDiff = now.getTime() - timeoutStartTime.getTime();
      return {
        ...student,
        timeoutDurationPassed: timeDiff,
        needsAlert: !student.alertsSent && timeDiff >= student.timeoutDuration
      };
    });
    
    return c.json({ students: timeoutStudents });
  } catch (error) {
    console.log('Get timeout students error:', error);
    return c.json({ error: 'Failed to fetch timeout students' }, 500);
  }
});

// Send SMS alert for timeout students
app.post('/make-server-3d5883fa/students/:studentId/alert', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentId = c.req.param('studentId');
    const { alertType = 'timeout' } = await c.req.json();
    
    const student = await kv.get(studentId);
    if (!student) {
      return c.json({ error: 'Student not found' }, 404);
    }

    // Simulate SMS sending (in real implementation, integrate with SMS service)
    const facultyMessage = `ALERT: Student ${student.name} (${student.rollNumber}) from ${student.className} has been absent from class for more than 7 minutes. Please verify attendance.`;
    const parentMessage = `ALERT: Your child ${student.name} (${student.rollNumber}) has been marked absent from ${student.className}. Please contact the college if this is unexpected.`;

    // Log the SMS alerts (in real implementation, these would be sent via SMS API)
    console.log('SMS Alert to Faculty:', facultyMessage);
    console.log('SMS Alert to Parent:', parentMessage, 'Phone:', student.guardianPhone);

    // Update student to mark alerts as sent
    const updatedStudent = {
      ...student,
      alertsSent: true,
      alertTimestamp: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, updatedStudent);

    // Store alert log
    const alertId = `alert:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    const alertLog = {
      id: alertId,
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      className: student.className,
      alertType: alertType,
      facultyMessage: facultyMessage,
      parentMessage: parentMessage,
      parentPhone: student.guardianPhone,
      timestamp: new Date().toISOString(),
      sentBy: user.id
    };

    await kv.set(alertId, alertLog);
    
    return c.json({ 
      message: 'SMS alerts sent successfully', 
      alertLog: alertLog,
      student: updatedStudent 
    });
  } catch (error) {
    console.log('Send SMS alert error:', error);
    return c.json({ error: 'Failed to send SMS alert' }, 500);
  }
});

// Get alert logs
app.get('/make-server-3d5883fa/alerts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    // Get all alert logs
    const allAlerts = await kv.getByPrefix('alert:');
    
    // Sort by timestamp descending
    allAlerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return c.json({ alerts: allAlerts });
  } catch (error) {
    console.log('Get alerts error:', error);
    return c.json({ error: 'Failed to fetch alerts' }, 500);
  }
});

// Error handling
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ error: 'Internal server error' }, 500);
});

// Not found handler
app.notFound((c) => {
  return c.json({ error: 'Route not found' }, 404);
});

Deno.serve(app.fetch);