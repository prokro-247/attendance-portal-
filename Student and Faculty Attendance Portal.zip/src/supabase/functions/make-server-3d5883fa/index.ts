import { Hono } from "https://deno.land/x/hono@v3.12.6/mod.ts";
import { cors } from "https://deno.land/x/hono@v3.12.6/middleware.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Simple KV store using Deno KV
let kvStore: Map<string, any> = new Map();

const kv = {
  set: async (key: string, value: any) => {
    kvStore.set(key, value);
    return value;
  },
  get: async (key: string) => {
    return kvStore.get(key) || null;
  },
  getByPrefix: async (prefix: string) => {
    const results: any[] = [];
    for (const [key, value] of kvStore.entries()) {
      if (key.startsWith(prefix)) {
        results.push(value);
      }
    }
    return results;
  }
};

// Default route
app.get('/', async (c) => {
  return c.json({ message: 'Attendance Management System API is running' });
});

// Generate demo students data
const generateDemoStudents = () => {
  // Updated departments with 12 total departments
  const departments = [
    { name: 'Computer Science', code: 'CSE', years: 4, classesPerYear: 3 },
    { name: 'Computer Science & Machine Learning', code: 'CSM', years: 4, classesPerYear: 3 },
    { name: 'Computer Science & Data Science', code: 'CSD', years: 4, classesPerYear: 3 },
    { name: 'Electrical & Electronics Engineering', code: 'EEE', years: 4, classesPerYear: 3 },
    { name: 'Electronics & Communication Engineering', code: 'ECE', years: 4, classesPerYear: 3 },
    { name: 'Information Technology', code: 'IT', years: 4, classesPerYear: 3 },
    { name: 'Internet of Things', code: 'IoT', years: 4, classesPerYear: 3 },
    { name: 'Biotechnology', code: 'BT', years: 6, classesPerYear: 2 },
    { name: 'Computer Applications', code: 'CA', years: 5, classesPerYear: 1 },
    { name: 'Mechanical Engineering', code: 'ME', years: 4, classesPerYear: 2 },
    { name: 'Civil Engineering', code: 'CE', years: 4, classesPerYear: 2 },
    { name: 'Chemical Engineering', code: 'CH', years: 4, classesPerYear: 2 }
  ];

  // Generate all classes for each department
  const allClasses: any[] = [];
  departments.forEach(dept => {
    for (let year = 1; year <= dept.years; year++) {
      for (let classNum = 1; classNum <= dept.classesPerYear; classNum++) {
        const classCode = dept.classesPerYear === 1 ? 
          `${dept.code}-${year}` : 
          `${dept.code}-${year}${String.fromCharCode(64 + classNum)}`;
        allClasses.push({
          code: classCode,
          department: dept.name,
          departmentCode: dept.code,
          year: year,
          studentsCount: dept.code === 'BT' ? 30 : (dept.code === 'CA' ? 35 : 45) // BT smaller classes, CA medium, others 45+
        });
      }
    }
  });

  const firstNames = [
    'Aarav', 'Aditya', 'Ahaan', 'Arjun', 'Aryan', 'Ayaan', 'Dhruv', 'Ishaan', 'Karan', 'Krishna',
    'Laksh', 'Manav', 'Naman', 'Om', 'Pranav', 'Reyansh', 'Rishaan', 'Rudra', 'Saanvi', 'Saksham',
    'Shaurya', 'Shivansh', 'Siddharth', 'Tanish', 'Vaibhav', 'Vihan', 'Vivaan', 'Yash', 'Aditi', 'Aisha',
    'Ananya', 'Anoushka', 'Arya', 'Avni', 'Diya', 'Ishika', 'Jhanvi', 'Kavya', 'Kiara', 'Myra',
    'Naira', 'Navya', 'Palak', 'Prisha', 'Riya', 'Saanvi', 'Sara', 'Shanaya', 'Siya', 'Sneha',
    'Tara', 'Vanya', 'Zara', 'Aadhya', 'Aanya', 'Aradhya', 'Avika', 'Devika', 'Eira', 'Fatima',
    'Gia', 'Hira', 'Ira', 'Janvi', 'Keya', 'Lavanya', 'Mahika', 'Nitya', 'Ojaswi', 'Pari',
    'Rhea', 'Samaira', 'Tanvi', 'Urvi', 'Vedika', 'Wania', 'Yana', 'Zoya', 'Abhinav', 'Achyut',
    'Advay', 'Agastya', 'Akash', 'Alok', 'Amit', 'Anand', 'Anirudh', 'Ankit', 'Arnav', 'Arpit',
    'Ashish', 'Atharv', 'Ayush', 'Chirag', 'Daksh', 'Darshan', 'Dev', 'Eeshan', 'Gautam', 'Harsh',
    'Hemant', 'Hitesh', 'Ishan', 'Jatin', 'Keshav', 'Kunal', 'Lavesh', 'Mohit', 'Nakul', 'Piyush',
    'Rahul', 'Rohan', 'Sarthak', 'Tushar', 'Utkarsh', 'Vinay', 'Yuvraj', 'Akshara', 'Bhavya', 'Charvi'
  ];

  const lastNames = [
    'Sharma', 'Verma', 'Gupta', 'Kumar', 'Singh', 'Agarwal', 'Jain', 'Bansal', 'Malhotra', 'Chopra',
    'Arora', 'Kapoor', 'Mehta', 'Shah', 'Patel', 'Reddy', 'Nair', 'Iyer', 'Rao', 'Krishnan',
    'Mukherjee', 'Banerjee', 'Chakraborty', 'Ghosh', 'Das', 'Roy', 'Sen', 'Bose', 'Dutta', 'Paul',
    'Joshi', 'Pandey', 'Mishra', 'Tiwari', 'Dubey', 'Shukla', 'Srivastava', 'Tripathi', 'Dwivedi', 'Upadhyay',
    'Khan', 'Ali', 'Ahmed', 'Hassan', 'Rahman', 'Malik', 'Sheikh', 'Ansari', 'Qureshi', 'Siddiqui',
    'Desai', 'Modi', 'Thakkar', 'Parekh', 'Trivedi', 'Vyas', 'Joshi', 'Bhatt', 'Raval', 'Parmar',
    'Yadav', 'Chauhan', 'Rajput', 'Thakur', 'Bisht', 'Rawat', 'Garg', 'Saxena', 'Goyal', 'Jindal'
  ];

  const guardianRelations = ['Father', 'Mother', 'Guardian', 'Uncle', 'Aunt'];
  const phonePrefix = '+91';
  
  const students: any[] = [];
  let rollNumberCounter = 1;
  
  // Generate students for each class
  allClasses.forEach(classInfo => {
    for (let i = 1; i <= classInfo.studentsCount; i++) {
      const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const fullName = `${firstName} ${lastName}`;
      
      const rollNumber = `${classInfo.departmentCode}${String(rollNumberCounter).padStart(4, '0')}`;
      rollNumberCounter++;
      
      // Determine semester based on year
      const semester = (classInfo.year - 1) * 2 + Math.floor(Math.random() * 2) + 1;
      
      const guardianFirstName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const guardianRelation = guardianRelations[Math.floor(Math.random() * guardianRelations.length)];
      
      const student = {
        id: `student:${rollNumber}`,
        rollNumber,
        name: fullName,
        email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@student.edu`,
        phone: `${phonePrefix}${Math.floor(Math.random() * 9000000000) + 1000000000}`,
        department: classInfo.department,
        departmentCode: classInfo.departmentCode,
        className: classInfo.code,
        year: classInfo.year,
        semester,
        guardianName: `${guardianFirstName} ${lastName} (${guardianRelation})`,
        guardianPhone: `${phonePrefix}${Math.floor(Math.random() * 9000000000) + 1000000000}`,
        isActive: Math.random() > 0.02, // 98% active students
        enrolledDate: `202${Math.floor(Math.random() * 4) + 1}-0${Math.floor(Math.random() * 9) + 1}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        // Timeout tracking fields
        currentStatus: 'in_class', // 'in_class', 'left_class', 'on_timeout', 'absent'
        lastActivity: new Date().toISOString(),
        timeoutStart: null,
        timeoutDuration: 7 * 60 * 1000, // 7 minutes in milliseconds
        alertsSent: false
      };
      
      students.push(student);
    }
  });
  
  console.log(`Generated ${students.length} students across ${allClasses.length} classes in ${departments.length} departments`);
  return students;
};

// Initialize demo users route
app.post('/init-demo', async (c) => {
  try {
    console.log('Initializing demo users and students...');
    
    // Check if demo data already exists
    const existingUsers = await kv.getByPrefix('user_email:');
    const existingStudents = await kv.getByPrefix('student:');
    
    if (existingUsers.length > 0 && existingStudents.length > 0) {
      console.log('Demo data already exists, skipping initialization');
      return c.json({ 
        message: 'Demo data already exists',
        userCount: existingUsers.length,
        studentCount: existingStudents.length
      });
    }

    const demoUsers = [
      {
        email: 'john.doe@student.edu',
        password: 'password123',
        fullName: 'John Doe',
        interfaceType: 'student',
        className: 'CS-A',
        department: 'Computer Science'
      },
      {
        email: 'sarah.wilson@college.edu',
        password: 'password123',
        fullName: 'Sarah Wilson',
        interfaceType: 'faculty',
        employeeId: 'FAC001',
        department: 'Computer Science'
      },
      {
        email: 'david.brown@college.edu',
        password: 'password123',
        fullName: 'David Brown',
        interfaceType: 'hod',
        employeeId: 'HOD001',
        department: 'Computer Science'
      },
      {
        email: 'principal@college.edu',
        password: 'password123',
        fullName: 'Dr. Maria Rodriguez',
        interfaceType: 'principal',
        employeeId: 'PRIN001',
        department: 'Administration'
      }
    ];

    // Generate demo students
    const demoStudents = generateDemoStudents();

    const results = [];
    for (const userData of demoUsers) {
      // Check if user already exists
      const existingUser = await kv.get(`user_email:${userData.email}`);
      if (existingUser) {
        results.push({ email: userData.email, status: 'already exists' });
        continue;
      }

      const { data, error } = await supabase.auth.admin.createUser({
        email: userData.email,
        password: userData.password,
        user_metadata: { 
          fullName: userData.fullName, 
          interfaceType: userData.interfaceType, 
          employeeId: userData.employeeId, 
          className: userData.className, 
          department: userData.department 
        },
        email_confirm: true
      });

      if (error) {
        console.log('Demo user creation error:', error);
        results.push({ email: userData.email, status: 'error', error: error.message });
        continue;
      }

      // Store user profile in KV store
      await kv.set(`user:${data.user.id}`, {
        id: data.user.id,
        email: userData.email,
        fullName: userData.fullName,
        interfaceType: userData.interfaceType,
        employeeId: userData.employeeId,
        className: userData.className,
        department: userData.department,
        createdAt: new Date().toISOString()
      });

      // Store email to ID mapping for quick lookups
      await kv.set(`user_email:${userData.email}`, data.user.id);

      results.push({ email: userData.email, status: 'created', id: data.user.id });
    }

    // Store demo students in KV store
    console.log(`Storing ${demoStudents.length} demo students...`);
    for (const student of demoStudents) {
      await kv.set(student.id, student);
    }

    console.log(`Demo data initialization completed: ${results.length} users, ${demoStudents.length} students`);
    return c.json({ 
      message: 'Demo data initialization completed', 
      userResults: results,
      studentCount: demoStudents.length,
      totalRecords: results.length + demoStudents.length
    });
  } catch (error) {
    console.log('Demo initialization error:', error);
    return c.json({ error: 'Failed to initialize demo data' }, 500);
  }
});

// Get all students
app.get('/students', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Get all students from KV store
    const allStudents = await kv.getByPrefix('student:');
    
    return c.json({ students: allStudents });
  } catch (error) {
    console.log('Get students error:', error);
    return c.json({ error: 'Failed to fetch students' }, 500);
  }
});

// Get timeout students
app.get('/students/timeouts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Get all students from KV store
    const allStudents = await kv.getByPrefix('student:');
    const now = new Date();
    
    // Filter students who are on timeout or need alerts
    const timeoutStudents = allStudents.filter(student => {
      if (student.currentStatus === 'left_class' && student.timeoutStart) {
        const timeoutStartTime = new Date(student.timeoutStart);
        const timeDiff = now.getTime() - timeoutStartTime.getTime();
        return timeDiff >= student.timeoutDuration; // 7 minutes passed
      }
      return false;
    }).map(student => {
      const timeoutStartTime = new Date(student.timeoutStart);
      const timeDiff = now.getTime() - timeoutStartTime.getTime();
      return {
        ...student,
        timeoutDurationPassed: timeDiff,
        needsAlert: !student.alertsSent && timeDiff >= student.timeoutDuration
      };
    });
    
    return c.json({ students: timeoutStudents });
  } catch (error) {
    console.log('Get timeout students error:', error);
    return c.json({ error: 'Failed to fetch timeout students' }, 500);
  }
});

// Send SMS alert for timeout students
app.post('/students/:studentId/alert', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) {
      return c.json({ error: 'Unauthorized - invalid token' }, 401);
    }

    const studentId = c.req.param('studentId');
    const body = await c.req.json();
    const { alertType = 'timeout' } = body;
    
    const student = await kv.get(studentId);
    if (!student) {
      return c.json({ error: 'Student not found' }, 404);
    }

    // Simulate SMS sending (in real implementation, integrate with SMS service)
    const facultyMessage = `ALERT: Student ${student.name} (${student.rollNumber}) from ${student.className} has been absent from class for more than 7 minutes. Please verify attendance.`;
    const parentMessage = `ALERT: Your child ${student.name} (${student.rollNumber}) has been marked absent from ${student.className}. Please contact the college if this is unexpected.`;

    // Log the SMS alerts (in real implementation, these would be sent via SMS API)
    console.log('SMS Alert to Faculty:', facultyMessage);
    console.log('SMS Alert to Parent:', parentMessage, 'Phone:', student.guardianPhone);

    // Update student to mark alerts as sent
    const updatedStudent = {
      ...student,
      alertsSent: true,
      alertTimestamp: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await kv.set(studentId, updatedStudent);

    // Store alert log
    const alertId = `alert:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    const alertLog = {
      id: alertId,
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      className: student.className,
      alertType: alertType,
      facultyMessage: facultyMessage,
      parentMessage: parentMessage,
      parentPhone: student.guardianPhone,
      timestamp: new Date().toISOString(),
      sentBy: user.id
    };

    await kv.set(alertId, alertLog);
    
    return c.json({ 
      message: 'SMS alerts sent successfully', 
      alertLog: alertLog,
      student: updatedStudent 
    });
  } catch (error) {
    console.log('Send SMS alert error:', error);
    return c.json({ error: 'Failed to send SMS alert' }, 500);
  }
});

// Get alert logs
app.get('/alerts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Get all alert logs
    const allAlerts = await kv.getByPrefix('alert:');
    
    // Sort by timestamp descending
    allAlerts.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return c.json({ alerts: allAlerts });
  } catch (error) {
    console.log('Get alerts error:', error);
    return c.json({ error: 'Failed to fetch alerts' }, 500);
  }
});

// Catch-all handler
app.all('*', (c) => {
  return c.json({ error: 'Route not found' }, 404);
});

// Serve the Hono app
Deno.serve(app.fetch);