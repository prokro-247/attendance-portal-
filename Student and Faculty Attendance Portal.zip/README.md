
  # Student and Faculty Attendance Portal

  This is a code bundle for Student and Faculty Attendance Portal. The original project is available at https://www.figma.com/design/kwq6BhkFxH6xNxRYbYT2B4/Student-and-Faculty-Attendance-Portal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  